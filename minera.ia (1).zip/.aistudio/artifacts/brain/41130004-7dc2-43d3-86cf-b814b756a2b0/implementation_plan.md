# Minera.ia — Radar de Leads sem Website em Moçambique

O **Minera.ia** é uma plataforma de prospecção B2B focada no mercado moçambicano que utiliza o Google Maps interativo e inteligência artificial para localizar empresas de diversos nichos que possuem contacto móvel (WhatsApp) ativo, mas ainda não contam com um website próprio.

### User Review & Critical Decisions

> [!IMPORTANT]
> As preferências abaixo foram confirmadas na etapa de alinhamento e orientam toda a arquitetura da solução:
> - **Motor de Descoberta**: Mapa interativo Google Maps com extração real de dados comerciais via Places API (New), centrado em Moçambique (`region: "MZ"`, `language: "pt"`).
> - **Persistência e Exportação**: Armazenamento no servidor da aplicação (Express + base local SQLite) para guardar campanhas, leads minerados e estado do funil, com exportação direta para CSV.
> - **Escopo de IA**: Foco exclusivo em **listagem filtrada e pontuação de oportunidade (0–100)** via Gemini (`gemini-4-hydrogen`), sem geração automática de mensagens ou chatbots.
> - **Identidade Visual**: **Tema escuro de prospecção intensiva** (`#0B1120` / `#0F172A`), otimizado para leitura prolongada de mapas, tabelas densas e métricas tabulares.
> - **Ativação do Google Maps**: Na fase de implementação, será solicitada a configuração segura da chave do Google Maps Platform através do fluxo oficial da plataforma.

---

### 1. Overview & Core Concept

- **What It Does**: Permite pesquisar nichos comerciais (ex.: clínicas dentárias, restaurantes, oficinas, salões de beleza, imobiliárias, escolas, hotéis, farmácias) por cidade ou província de Moçambique (Maputo, Matola, Beira, Nampula, Chimoio, Tete, Quelimane, Pemba, Xai-Xai, Inhambane, Lichinga). A ferramenta consulta os estabelecimentos na área do mapa, identifica automaticamente quais **não possuem website** (`websiteUri` ausente ou apenas link de rede social), valida se o número telefónico segue os prefixos móveis de Moçambique compatíveis com WhatsApp (`+258 82/83/84/85/86/87`), e calcula um **Score de Oportunidade** com IA.
- **Target Audience / Persona**: Agências digitais, desenvolvedores web freelancers, consultores de marketing e equipas comerciais B2B em Moçambique que procuram clientes locais com negócio estabelecido e presença digital incompleta.
- **Key Value**: Elimina a triagem manual no Google Maps ao cruzar automaticamente localização, ausência de site, validade de WhatsApp moçambicano e prioridade comercial numa única vista operacional.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Configuração de Radar (Barra Lateral + Filtros)**: O utilizador escolhe um nicho (ou escreve uma categoria livre), seleciona uma cidade/província moçambicana (ou navega livremente no mapa e usa *"Pesquisar nesta área"*), e define se deseja exibir apenas leads **Sem Website + WhatsApp válido** (ativo por padrão) ou comparar com o universo total pesquisado.
  2. **Mineração Visual no Mapa**: O mapa escuro do Google Maps centraliza-se na região selecionada e exibe marcadores avançados (`AdvancedMarkerElement`) diferenciados visualmente entre alvos prioritários (sem website + WhatsApp), alvos sem contacto móvel e empresas já com website. Clicar num marcador sincroniza imediatamente a tabela e abre o painel de detalhes do lead.
  3. **Pontuação de Oportunidade com IA**: Ao concluir uma extração, o servidor envia os metadados agregados dos candidatos para a API Gemini (`gemini-4-hydrogen`) calcular uma pontuação objetiva (0–100) baseada em volume de avaliações, nota média, completude do perfil e carência de website, acompanhada de uma justificação curta (1 frase).
  4. **Gestão de Funil & Exportação**: O utilizador pode guardar leads selecionados (ou todo o lote filtrado) na base do servidor, atualizar o estado de prospecção (`Novo`, `Em Análise`, `Contactado`, `Negociação`, `Convertido`, `Descartado`), abrir o contacto diretamente via `wa.me/258...` ou exportar a lista filtrada em formato `.csv`.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Radar comercial escuro de alta densidade ("Prospector Command Deck") — sóbrio, técnico e sem ornamentos supérfluos.
  - *Color Palette & Mood*:
    - **60% Canvas Neutro Escuro**: `#0B1120` (fundo principal) e `#0F172A` (superfície do workspace e mapa em tema escuro).
    - **30% Superfícies Estruturais**: `#162032` para painéis e linhas de tabela com bordas finas `1px solid #1E293B`; tipografia principal `#F1F5F9` com compensação ótica em dark mode e metadados secundários em `#94A3B8`.
    - **10% Acento de Alta Intenção**: `#10B981` (Esmeralda WhatsApp/Oportunidade) para ações primárias, botão de mineração e leads qualificados; `#F59E0B` (Âmbar) para oportunidades médias e `#64748B` para registos descartados ou com website.
  - *Typography & Hierarchy*:
    - Display e Títulos: `Plus Jakarta Sans` (pesos 600 e 700, `text-wrap: balance`).
    - Corpo e Tabelas: `DM Sans` (13px–14px para leitura densa).
    - Dados, Telefones e Scores: `JetBrains Mono` com `font-variant-numeric: tabular-nums` para alinhamento vertical perfeito de contactos `+258` e pontuações.
  - *Component Styling & Layout*:
    - Barra lateral fixa à esquerda (`260px`) com navegação de vistas (`Radar de Mapa`, `Leads Guardados`, `Histórico de Campanhas`) e seletores rápidos de províncias/nichos de Moçambique.
    - Cabeçalho superior limpo em linha única (`breadcrumbs` do alvo atual à esquerda, contadores resumidos e botão primário `Exportar CSV` à direita).
    - Área principal dividida (Split View responsivo em desktop 1440px): Mapa Google Maps interativo à esquerda/topo e grelha tabular de alta densidade (`38px–42px` por linha) à direita/base, com zero cartões aninhados e metadados limpos sem cápsulas/pills decorativas (separadores tipográficos `·`).

- **Interactive Feedback & Motion**:
  - Transições rápidas (`≤ 180ms`, `cubic-bezier(0.16, 1, 0.3, 1)`) usando apenas `opacity` e `transform`.
  - Esqueletos de carregamento (skeletons) alinhados exatamente à altura das linhas da tabela durante buscas no Places e pontuação via IA.
  - Estados completos: estado inicial guiado para Moçambique, estado vazio com sugestão de ampliar raio ou trocar nicho, e mensagens claras de erro ou limite de cota da API.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Filtragem Rigorosa para Moçambique (WhatsApp + Ausência de Website)**
  - *Chosen Approach*: Normalizar todos os números retornados pelo Google Places para o padrão E.164 moçambicano (`+258`), validando os prefixos móveis das operadoras locais (`82` e `83` Tmcel, `84` e `85` Vodacom, `86` e `87` Movitel) como indicadores de contacto WhatsApp ativo, e isolando estabelecimentos onde `websiteUri` esteja vazio ou aponte apenas para domínios sociais/diretórios (ex.: `facebook.com`, `instagram.com`), sinalizando claramente quando não há site institucional próprio.
  - *Why*: Em Moçambique, números fixos (`21`, `23`, `26`, etc.) raramente têm WhatsApp Business associado, enquanto prefixos `82–87` têm altíssima taxa de entrega no WhatsApp.
  - *Alternatives Considered*: Aceitar qualquer número telefónico sem distinção de operadora/móvel — descartado por gerar desperdício no contacto via WhatsApp.

- **Decision 2: Pontuação de Oportunidade via Gemini IA no Servidor**
  - *Chosen Approach*: Rota dedicada no servidor Express usando `@google/genai` (`gemini-4-hydrogen` com `responseSchema` estruturado em JSON) para pontuar lotes de leads com base em critérios comerciais reais (avaliação, número de reviews como proxy de fluxo de clientes, ausência de site, presença de telefone móvel e perfil incompleto).
  - *Why*: Mantém a chave da API Gemini protegida no servidor e produz critérios de priorização consistentes em segundos, sem inventar métricas fictícias.
  - *Alternatives Considered*: Fórmula estática apenas com matemática simples — descartado porque a IA consegue ponderar nuances do nicho local em Moçambique (ex.: uma clínica com 45 avaliações e sem site vale mais comercialmente do que um quiosque com 1 avaliação).

- **Decision 3: Persistência Local no Servidor (SQLite) + Conformidade Google Maps**
  - *Chosen Approach*: Banco SQLite gerido pelo backend Express (`leads`, `campaigns`, `notes/status`) armazenando `place_id`, estado do funil comercial, pontuação de oportunidade da IA e histórico de campanhas, complementado por atualizações em tempo real via Places SDK quando o utilizador inspeciona um lead no mapa, respeitando integralmente os Termos de Serviço do Google Maps Platform.
  - *Why*: Garante persistência fiável entre sessões, filtragem instantânea de leads guardados e exportação CSV sem exigir login externo ou infraestrutura complexa nesta primeira fase.
  - *Alternatives Considered*: `localStorage` no navegador — descartado a pedido do utilizador por ser volátil e preso a um único browser.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:
```text
┌───────────────────────────────────────────────────────────────────────────┐
│                      Cliente React + Vite (Tema Escuro)                   │
│                                                                           │
│  ┌───────────────────┐   ┌─────────────────────────────────────────────┐  │
│  │  Sidebar (260px)  │   │             Workspace Principal             │  │
│  │  - Radar / Lista  │   │  ┌───────────────────┐ ┌─────────────────┐  │  │
│  │  - Nichos MZ      │   │  │ Mapa Google Maps  │ │ Tabela de Leads │  │  │
│  │  - Províncias MZ  │   │  │ @vis.gl + Markers │ │ Score IA + CSV  │  │  │
│  │  - Filtros Ativos │   │  └─────────┬─────────┘ └────────┬────────┘  │  │
│  └───────────────────┘   └────────────┼────────────────────┼───────────┘  │
└───────────────────────────────────────┼────────────────────┼──────────────┘
                                        │ Places API (New)   │ REST /api/*
                                        ▼                    ▼
┌───────────────────────────┐   ┌───────────────────────────────────────────┐
│   Google Maps Platform    │   │          Servidor Express (Node.js)       │
│  - Maps JavaScript API    │   │                                           │
│  - Places API (New)       │◄──┤  - /api/leads (CRUD + Funil SQLite)       │
│    region=MZ, language=pt │   │  - /api/leads/export (Download CSV)       │
└───────────────────────────┘   │  - /api/campaigns (Histórico de buscas)   │
                                │  - /api/ai/score-leads (@google/genai)    │
                                └────────────────────────┬──────────────────┘
                                                         │
                                       ┌─────────────────┴─────────────────┐
                                       ▼                                   ▼
                           ┌───────────────────────┐           ┌───────────────────────┐
                           │   SQLite Local DB     │           │   Gemini API Server   │
                           │  (leads, campaigns)   │           │  (gemini-4-hydrogen)  │
                           └───────────────────────┘           └───────────────────────┘
```

- **Data Model & State**:
  - **Campaign (`campaigns`)**: `id`, `niche`, `city`, `province`, `totalFound`, `qualifiedCount` (sem website + WhatsApp), `createdAt`.
  - **Lead (`leads`)**: `id`, `placeId` (único), `campaignId`, `name`, `niche`, `address`, `city`, `province`, `lat`, `lng`, `phoneRaw`, `whatsappNumber` (E.164 `+2588...` ou nulo), `hasMobileWhatsApp` (booleano), `websiteUrl` (nulo ou domínio), `websiteStatus` (`none` | `social_only` | `has_website`), `rating`, `reviewCount`, `opportunityScore` (0–100), `scoreRationale` (texto curto da IA), `pipelineStatus` (`novo` | `em_analise` | `contactado` | `convertido` | `descartado`), `notes`, `updatedAt`.
  - **Estado da UI**: Zona geográfica selecionada (lat/lng + zoom), termo/nicho de busca, filtro ativo (`apenas_sem_site_whatsapp` | `todos_sem_site` | `todos`), lead selecionado (sincronizado entre marcador no mapa e linha da tabela), estado de carregamento da pesquisa e da pontuação IA.

- **Interactive Component & State Mapping**:
  - **Seletor de Cidade/Província & Nicho**: Atualiza o centro/zoom do mapa Google Maps para a cidade moçambicana escolhida e dispara `Place.searchByText` (Places API New) com `region: 'MZ'` e `language: 'pt'`.
  - **Botão "Minerar Área Atual"**: Captura os limites atuais (`bounds`) do mapa movido pelo utilizador para minerar exatamente o bairro ou avenida visível (ex.: Baixa de Maputo, Sommerschield, Ponta Gea na Beira).
  - **Classificador de Leads + Pontuador IA**: Filtra os resultados do Places API, aplica o validador de prefixos móveis de Moçambique (`82–87`) e envia os leads qualificados ao endpoint `/api/ai/score-leads` para atribuição de `opportunityScore` (0–100) e justificação.
  - **Tabela de Leads & Painel de Detalhe**: Permite ordenar por `opportunityScore`, avaliações ou cidade; guardar leads individuais ou em lote na base SQLite (`/api/leads/bulk`); alterar o `pipelineStatus` com atualização otimista; clicar em `Abrir WhatsApp` (`https://wa.me/258...`); e acionar `/api/leads/export` para descarregar o CSV compatível com Excel (UTF-8 BOM, separador `;` ou `,`).

- **Key Sequences & Integrations**:
  - **Google Maps Platform**: Integração via `@vis.gl/react-google-maps` (`<APIProvider>`, `<Map>`, `<AdvancedMarker>`), respeitando atribuição obrigatória (`internalUsageAttributionIds`), `mapId`, `language="pt"`, `region="MZ"`, e defesa de cota no cliente.
  - **Gemini API (`@google/genai`)**: Executado exclusivamente no backend (`server.ts`) utilizando `gemini-4-hydrogen` com `responseSchema` para retornar pontuações estruturadas e determinísticas sem expor chaves no navegador.
