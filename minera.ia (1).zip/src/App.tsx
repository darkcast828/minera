import {
  APILoadingStatus,
  APIProvider,
  useApiLoadingStatus,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import type { User } from 'firebase/auth';
import {
  AlertTriangle,
  Bell,
  BookmarkPlus,
  CalendarClock,
  ChevronDown,
  Compass,
  Database,
  Download,
  FileSpreadsheet,
  History,
  MapPin,
  Menu,
  RefreshCw,
  Search,
  Sparkles,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AutoProspectView } from './components/AutoProspectView.tsx';
import { CampaignsView } from './components/CampaignsView.tsx';
import { LeadDetailDrawer } from './components/LeadDetailDrawer.tsx';
import { MozambiqueRadarMap } from './components/MozambiqueRadarMap.tsx';
import { RadarResultsList } from './components/RadarResultsList.tsx';
import { SavedLeadsView } from './components/SavedLeadsView.tsx';
import {
  MOZAMBIQUE_CITIES,
  MOZAMBIQUE_PROVINCES,
  NICHE_PRESETS,
  type MozambiqueCity,
} from './data/mozambique.ts';
import type {
  AiScoreRequestItem,
  AiScoreResultItem,
  AutoProspectDigest,
  AutoProspectDigestLead,
  AutoProspectFrequency,
  AutoProspectRule,
  CampaignRecord,
  GoogleSheetsConfig,
  GoogleSheetTabInfo,
  LeadRecord,
  OutreachSettings,
  PipelineStatus,
} from './types/leads.ts';
import {
  GoogleGmailAuthError,
  sendGmailMessage,
} from './utils/gmailOutreachService.ts';
import {
  createLeadsSpreadsheet,
  fetchSpreadsheetMetadata,
  GoogleSheetsAuthError,
  syncLeadsToGoogleSheet,
} from './utils/googleSheetsService.ts';
import {
  getAccessToken,
  googleLogout,
  googleSignIn,
  initGoogleAuth,
  invalidateAccessToken,
} from './utils/googleWorkspaceAuth.ts';
import {
  classifyWebsite,
  parseMozambiquePhone,
  sanitizeExternalHttpUrl,
} from './utils/mozambiqueLeadParser.ts';

type WorkspaceTab = 'explore' | 'saved' | 'campaigns' | 'auto';
type PhoneFilter = 'all' | 'with_phone' | 'mobile_mz';
type WebsiteFilter = 'all' | 'no_website' | 'none_only' | 'social_only' | 'has_website';

const GOOGLE_MAPS_API_KEY = (import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined) ?? '';

function buildClientCsvAndDownload(leads: LeadRecord[], filename: string) {
  const escapeCell = (raw: string | number | null | undefined): string => {
    if (raw === null || raw === undefined) return '""';
    let text = String(raw);
    if (/^[=+\-@\t\r]/.test(text)) {
      text = `'${text}`;
    }
    return `"${text.replace(/"/g, '""')}"`;
  };

  const headers = [
    'Empresa',
    'Nicho',
    'Cidade',
    'Provincia',
    'Endereco',
    'Telefone_Publicado',
    'Movel_MZ_Elegivel_WhatsApp',
    'Operadora',
    'Website_Status',
    'Website_URL',
    'Avaliacao',
    'Avaliacoes_Qtd',
    'Score_Oportunidade_IA',
    'Justificacao_IA',
    'Link_WhatsApp',
    'Google_Maps_URL',
  ];

  const rows = leads.map((lead) => [
    escapeCell(lead.name),
    escapeCell(lead.niche),
    escapeCell(lead.city),
    escapeCell(lead.province),
    escapeCell(lead.address),
    escapeCell(lead.whatsappNumber || lead.phoneRaw || ''),
    escapeCell(lead.hasMobileWhatsApp ? 'Sim' : 'Nao'),
    escapeCell(lead.carrier),
    escapeCell(
      lead.websiteStatus === 'none'
        ? 'Sem website registado'
        : lead.websiteStatus === 'social_only'
        ? 'Apenas rede social'
        : 'Com website registado'
    ),
    escapeCell(lead.websiteUrl || ''),
    escapeCell(lead.rating !== null ? lead.rating.toFixed(1) : ''),
    escapeCell(lead.reviewCount),
    escapeCell(lead.opportunityScore !== null ? lead.opportunityScore : ''),
    escapeCell(lead.scoreRationale || ''),
    escapeCell(lead.waDigits ? `https://wa.me/${lead.waDigits}` : ''),
    escapeCell(lead.googleMapsUri || ''),
  ]);

  const csvContent = `\uFEFF${[headers.map(escapeCell).join(','), ...rows.map((r) => r.join(','))].join('\r\n')}`;
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function isQuotaError(error: unknown): boolean {
  const message = String(error instanceof Error ? error.message : error).toLowerCase();
  return (
    message.includes('resource_exhausted') ||
    message.includes('over_query_limit') ||
    message.includes('overquotamaperror') ||
    message.includes('quota') ||
    message.includes('429')
  );
}

interface WorkspaceShellProps {
  quotaExceeded: boolean;
}

function WorkspaceShell({ quotaExceeded }: WorkspaceShellProps) {
  const placesLib = useMapsLibrary('places');
  const mapsLoadingStatus = useApiLoadingStatus();

  const [activeTab, setActiveTab] = useState<WorkspaceTab>('explore');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Collapsible sidebar filter sections
  const [citiesSectionOpen, setCitiesSectionOpen] = useState(true);
  const [nichesSectionOpen, setNichesSectionOpen] = useState(true);

  // Geographic & niche search state
  const [selectedProvince, setSelectedProvince] = useState<string>('all');
  const [selectedCity, setSelectedCity] = useState<MozambiqueCity>(MOZAMBIQUE_CITIES[0]);
  const [mapCamera, setMapCamera] = useState({
    lat: MOZAMBIQUE_CITIES[0].lat,
    lng: MOZAMBIQUE_CITIES[0].lng,
    zoom: MOZAMBIQUE_CITIES[0].zoom,
  });
  const [nicheQuery, setNicheQuery] = useState<string>(NICHE_PRESETS[1].query);
  const [selectedPresetId, setSelectedPresetId] = useState<string>(NICHE_PRESETS[1].id);
  const [phoneFilter, setPhoneFilter] = useState<PhoneFilter>('all');
  const [websiteFilter, setWebsiteFilter] = useState<WebsiteFilter>('all');

  // Radar live mining state
  const [minedLeads, setMinedLeads] = useState<LeadRecord[]>([]);
  const [hasSearchedOnce, setHasSearchedOnce] = useState(false);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [isMining, setIsMining] = useState(false);
  const [isScoringAi, setIsScoringAi] = useState(false);
  const [isSavingBulk, setIsSavingBulk] = useState(false);
  const [isRefreshingId, setIsRefreshingId] = useState<string | null>(null);

  // Feedback & errors
  const [miningError, setMiningError] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Persisted SQLite data
  const [savedLeads, setSavedLeads] = useState<LeadRecord[]>([]);
  const [campaigns, setCampaigns] = useState<CampaignRecord[]>([]);
  const [autoRules, setAutoRules] = useState<AutoProspectRule[]>([]);
  const [autoDigests, setAutoDigests] = useState<AutoProspectDigest[]>([]);
  const [isLoadingSaved, setIsLoadingSaved] = useState(true);
  const [isLoadingCampaigns, setIsLoadingCampaigns] = useState(true);
  const [isLoadingAuto, setIsLoadingAuto] = useState(true);
  const [runningRuleId, setRunningRuleId] = useState<string | null>(null);
  const runningRuleIdsRef = useRef<Record<string, boolean>>({});
  const failedRuleCooldownRef = useRef<Record<string, number>>({});

  // Google Workspace Auth & Google Sheets Real-Time Sync state
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [needsGoogleAuth, setNeedsGoogleAuth] = useState(true);
  const [isGoogleLoggingIn, setIsGoogleLoggingIn] = useState(false);
  const [googleAuthError, setGoogleAuthError] = useState<string | null>(null);
  const [sheetsConfig, setSheetsConfig] = useState<GoogleSheetsConfig | null>(null);
  const [availableSheetTabs, setAvailableSheetTabs] = useState<GoogleSheetTabInfo[]>([]);
  const [realtimeSessionConfirmed, setRealtimeSessionConfirmed] = useState(false);
  const [isSyncingSheets, setIsSyncingSheets] = useState(false);
  const [isConnectingSheet, setIsConnectingSheet] = useState(false);
  const [sheetsSyncError, setSheetsSyncError] = useState<string | null>(null);
  const [savedMutationVersion, setSavedMutationVersion] = useState(0);
  const lastSyncedSnapshotKeyRef = useRef<string>('');
  const isSyncingSheetsRef = useRef(false);
  const [outreachSenderEmail, setOutreachSenderEmail] = useState('scottnaftal@gmail.com');

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3000);
  }, []);

  const savedByPlaceId = useMemo(() => {
    const dict: Record<string, LeadRecord> = {};
    for (const lead of savedLeads) {
      dict[lead.placeId] = lead;
    }
    return dict;
  }, [savedLeads]);

  const fetchSavedLeads = useCallback(async () => {
    setIsLoadingSaved(true);
    try {
      const res = await fetch('/api/leads');
      if (!res.ok) throw new Error('Falha ao carregar leads guardados.');
      const data = (await res.json()) as { leads?: LeadRecord[] };
      setSavedLeads(data.leads ?? []);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingSaved(false);
    }
  }, []);

  const fetchCampaigns = useCallback(async () => {
    setIsLoadingCampaigns(true);
    try {
      const res = await fetch('/api/campaigns');
      if (!res.ok) throw new Error('Falha ao carregar campanhas.');
      const data = (await res.json()) as { campaigns?: CampaignRecord[] };
      setCampaigns(data.campaigns ?? []);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingCampaigns(false);
    }
  }, []);

  const fetchAutoProspectData = useCallback(async () => {
    setIsLoadingAuto(true);
    try {
      const [rulesRes, digestsRes] = await Promise.all([
        fetch('/api/auto-prospect/rules'),
        fetch('/api/auto-prospect/digests'),
      ]);
      if (rulesRes.ok) {
        const rulesData = (await rulesRes.json()) as { rules?: AutoProspectRule[] };
        setAutoRules(rulesData.rules ?? []);
      }
      if (digestsRes.ok) {
        const digestsData = (await digestsRes.json()) as { digests?: AutoProspectDigest[] };
        setAutoDigests(digestsData.digests ?? []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingAuto(false);
    }
  }, []);

  const fetchSheetsConfig = useCallback(async () => {
    try {
      const res = await fetch('/api/integrations/sheets');
      if (!res.ok) return;
      const data = (await res.json()) as { config?: GoogleSheetsConfig | null };
      setSheetsConfig(data.config ?? null);
    } catch (err) {
      console.error(err);
    }
  }, []);

  const fetchOutreachSettings = useCallback(async () => {
    try {
      const res = await fetch('/api/settings/outreach');
      if (!res.ok) return;
      const data = (await res.json()) as { settings?: OutreachSettings };
      if (data.settings?.senderEmail) {
        setOutreachSenderEmail(data.settings.senderEmail);
      }
    } catch (err) {
      console.error(err);
    }
  }, []);

  useEffect(() => {
    void fetchSavedLeads();
    void fetchCampaigns();
    void fetchAutoProspectData();
    void fetchSheetsConfig();
    void fetchOutreachSettings();
  }, [
    fetchSavedLeads,
    fetchCampaigns,
    fetchAutoProspectData,
    fetchSheetsConfig,
    fetchOutreachSettings,
  ]);

  useEffect(() => {
    const unsubscribe = initGoogleAuth(
      (user) => {
        setGoogleUser(user);
        setNeedsGoogleAuth(false);
        setGoogleAuthError(null);
      },
      (user) => {
        setGoogleUser(user);
        setNeedsGoogleAuth(true);
      }
    );
    return unsubscribe;
  }, []);

  const buildLeadsSnapshotKey = useCallback((leadsList: LeadRecord[]) => {
    return leadsList
      .map(
        (l) =>
          `${l.placeId}:${l.updatedAt ?? ''}:${l.opportunityScore ?? ''}:${l.pipelineStatus}:${l.notes}:${l.phoneRaw ?? ''}:${l.websiteStatus}`
      )
      .join('|');
  }, []);

  const persistSheetsConfig = useCallback(
    async (payload: {
      spreadsheetId: string;
      spreadsheetTitle: string;
      spreadsheetUrl: string;
      sheetName: string;
      autoSyncEnabled?: boolean;
      lastSyncedAt?: string | null;
      lastSyncedCount?: number;
    }): Promise<GoogleSheetsConfig> => {
      const res = await fetch('/api/integrations/sheets', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { config?: GoogleSheetsConfig; error?: string };
      if (!res.ok || !data.config) {
        throw new Error(data.error || 'Falha ao guardar configuração do Google Sheets.');
      }
      setSheetsConfig(data.config);
      return data.config;
    },
    []
  );

  const performSheetsSync = useCallback(
    async (
      leadsToSync: LeadRecord[],
      targetConfig: GoogleSheetsConfig,
      isAuto = false
    ): Promise<boolean> => {
      const token = getAccessToken();
      if (!token) {
        setNeedsGoogleAuth(true);
        setRealtimeSessionConfirmed(false);
        setSheetsSyncError('Sessão Google expirada. Autentique-se novamente para sincronizar.');
        return false;
      }
      if (isSyncingSheetsRef.current) return false;

      isSyncingSheetsRef.current = true;
      setIsSyncingSheets(true);
      setSheetsSyncError(null);

      try {
        const result = await syncLeadsToGoogleSheet({
          spreadsheetId: targetConfig.spreadsheetId,
          sheetName: targetConfig.sheetName,
          leads: leadsToSync,
          accessToken: token,
        });

        lastSyncedSnapshotKeyRef.current = buildLeadsSnapshotKey(leadsToSync);

        await persistSheetsConfig({
          spreadsheetId: targetConfig.spreadsheetId,
          spreadsheetTitle: targetConfig.spreadsheetTitle,
          spreadsheetUrl: targetConfig.spreadsheetUrl,
          sheetName: targetConfig.sheetName,
          autoSyncEnabled: targetConfig.autoSyncEnabled,
          lastSyncedAt: result.syncedAt,
          lastSyncedCount: result.updatedRows,
        });

        if (!isAuto) {
          showToast(
            `${result.updatedRows} lead(s) sincronizados com "${targetConfig.spreadsheetTitle}".`
          );
        }
        return true;
      } catch (err) {
        if (err instanceof GoogleSheetsAuthError) {
          invalidateAccessToken();
          setNeedsGoogleAuth(true);
          setRealtimeSessionConfirmed(false);
        }
        setSheetsSyncError(
          err instanceof Error ? err.message : 'Erro ao sincronizar com Google Sheets.'
        );
        return false;
      } finally {
        isSyncingSheetsRef.current = false;
        setIsSyncingSheets(false);
      }
    },
    [buildLeadsSnapshotKey, persistSheetsConfig, showToast]
  );

  const handleGoogleLogin = useCallback(
    async (loginHint?: string) => {
      setIsGoogleLoggingIn(true);
      setGoogleAuthError(null);
      setSheetsSyncError(null);
      try {
        const result = await googleSignIn(loginHint);
        setGoogleUser(result.user);
        setNeedsGoogleAuth(false);
        showToast(
          `Conta Google ${result.user.email || ''} conectada ao Minera.ia.`.trim()
        );
      } catch (err) {
        setGoogleAuthError(
          err instanceof Error
            ? err.message
            : 'Não foi possível concluir o início de sessão com o Google.'
        );
      } finally {
        setIsGoogleLoggingIn(false);
      }
    },
    [showToast]
  );

  const handleSaveOutreachSenderEmail = useCallback(
    async (email: string) => {
      const res = await fetch('/api/settings/outreach', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ senderEmail: email }),
      });
      const data = (await res.json()) as { settings?: OutreachSettings; error?: string };
      if (!res.ok || !data.settings) {
        throw new Error(data.error || 'Não foi possível guardar o e-mail de envio.');
      }
      setOutreachSenderEmail(data.settings.senderEmail);
      showToast(`Conta de envio atualizada para ${data.settings.senderEmail}.`);
    },
    [showToast]
  );

  const handleSendGmail = useCallback(
    async (params: { to: string; subject: string; bodyText: string }) => {
      const token = getAccessToken();
      if (!token) {
        setNeedsGoogleAuth(true);
        throw new Error('Autentique-se com o Google antes de enviar e-mails.');
      }
      try {
        await sendGmailMessage({
          to: params.to,
          subject: params.subject,
          bodyText: params.bodyText,
          replyToEmail: outreachSenderEmail,
          accessToken: token,
        });
        showToast(`E-mail enviado via Gmail para ${params.to}.`);
      } catch (err) {
        if (err instanceof GoogleGmailAuthError) {
          invalidateAccessToken();
          setNeedsGoogleAuth(true);
        }
        throw err;
      }
    },
    [outreachSenderEmail, showToast]
  );

  const handleGoogleLogout = useCallback(async () => {
    await googleLogout();
    setGoogleUser(null);
    setNeedsGoogleAuth(true);
    setRealtimeSessionConfirmed(false);
    setAvailableSheetTabs([]);
    showToast('Sessão Google terminada.');
  }, [showToast]);

  const handleCreateSpreadsheet = useCallback(
    async (title: string): Promise<boolean> => {
      const token = getAccessToken();
      if (!token) {
        setNeedsGoogleAuth(true);
        return false;
      }
      setIsConnectingSheet(true);
      setSheetsSyncError(null);
      try {
        const meta = await createLeadsSpreadsheet(title, token);
        setAvailableSheetTabs(meta.tabs);
        const firstTab = meta.tabs[0]?.title || 'Leads_MZ';
        await persistSheetsConfig({
          spreadsheetId: meta.spreadsheetId,
          spreadsheetTitle: meta.spreadsheetTitle,
          spreadsheetUrl: meta.spreadsheetUrl,
          sheetName: firstTab,
          autoSyncEnabled: false,
          lastSyncedAt: null,
          lastSyncedCount: 0,
        });
        setRealtimeSessionConfirmed(false);
        showToast(`Planilha "${meta.spreadsheetTitle}" criada no Google Sheets.`);
        return true;
      } catch (err) {
        if (err instanceof GoogleSheetsAuthError) {
          invalidateAccessToken();
          setNeedsGoogleAuth(true);
        }
        setSheetsSyncError(
          err instanceof Error ? err.message : 'Não foi possível criar a planilha.'
        );
        return false;
      } finally {
        setIsConnectingSheet(false);
      }
    },
    [persistSheetsConfig, showToast]
  );

  const handleConnectExistingSpreadsheet = useCallback(
    async (spreadsheetId: string): Promise<boolean> => {
      const token = getAccessToken();
      if (!token) {
        setNeedsGoogleAuth(true);
        return false;
      }
      setIsConnectingSheet(true);
      setSheetsSyncError(null);
      try {
        const meta = await fetchSpreadsheetMetadata(spreadsheetId, token);
        setAvailableSheetTabs(meta.tabs);
        const firstTab = meta.tabs[0]?.title;
        if (!firstTab) {
          throw new Error('A planilha selecionada não possui nenhuma aba válida.');
        }
        await persistSheetsConfig({
          spreadsheetId: meta.spreadsheetId,
          spreadsheetTitle: meta.spreadsheetTitle,
          spreadsheetUrl: meta.spreadsheetUrl,
          sheetName: firstTab,
          autoSyncEnabled: false,
          lastSyncedAt: null,
          lastSyncedCount: 0,
        });
        setRealtimeSessionConfirmed(false);
        showToast(`Planilha "${meta.spreadsheetTitle}" ligada.`);
        return true;
      } catch (err) {
        if (err instanceof GoogleSheetsAuthError) {
          invalidateAccessToken();
          setNeedsGoogleAuth(true);
        }
        setSheetsSyncError(
          err instanceof Error ? err.message : 'Não foi possível ligar a planilha.'
        );
        return false;
      } finally {
        setIsConnectingSheet(false);
      }
    },
    [persistSheetsConfig, showToast]
  );

  const handleRefreshSheetTabs = useCallback(async () => {
    const token = getAccessToken();
    if (!token || !sheetsConfig) {
      setNeedsGoogleAuth(true);
      return;
    }
    setSheetsSyncError(null);
    try {
      const meta = await fetchSpreadsheetMetadata(sheetsConfig.spreadsheetId, token);
      setAvailableSheetTabs(meta.tabs);
    } catch (err) {
      if (err instanceof GoogleSheetsAuthError) {
        invalidateAccessToken();
        setNeedsGoogleAuth(true);
      }
      setSheetsSyncError(
        err instanceof Error ? err.message : 'Não foi possível carregar as abas da planilha.'
      );
    }
  }, [sheetsConfig]);

  const handleChangeSheetTab = useCallback(
    async (sheetName: string) => {
      if (!sheetsConfig) return;
      await persistSheetsConfig({
        spreadsheetId: sheetsConfig.spreadsheetId,
        spreadsheetTitle: sheetsConfig.spreadsheetTitle,
        spreadsheetUrl: sheetsConfig.spreadsheetUrl,
        sheetName,
        autoSyncEnabled: sheetsConfig.autoSyncEnabled,
      });
      lastSyncedSnapshotKeyRef.current = '';
    },
    [sheetsConfig, persistSheetsConfig]
  );

  const handleDisconnectSpreadsheet = useCallback(async () => {
    const res = await fetch('/api/integrations/sheets', { method: 'DELETE' });
    if (res.ok) {
      setSheetsConfig(null);
      setAvailableSheetTabs([]);
      setRealtimeSessionConfirmed(false);
      setSheetsSyncError(null);
      lastSyncedSnapshotKeyRef.current = '';
      showToast('Planilha desligada.');
    }
  }, [showToast]);

  const handleConfirmSyncNow = useCallback(async () => {
    if (!sheetsConfig) return;
    await performSheetsSync(savedLeads, sheetsConfig, false);
  }, [sheetsConfig, savedLeads, performSheetsSync]);

  const handleConfirmEnableRealtime = useCallback(async () => {
    if (!sheetsConfig) return;
    const updated = await persistSheetsConfig({
      spreadsheetId: sheetsConfig.spreadsheetId,
      spreadsheetTitle: sheetsConfig.spreadsheetTitle,
      spreadsheetUrl: sheetsConfig.spreadsheetUrl,
      sheetName: sheetsConfig.sheetName,
      autoSyncEnabled: true,
    });
    setRealtimeSessionConfirmed(true);
    const ok = await performSheetsSync(savedLeads, updated, false);
    if (ok) {
      showToast('Sincronização em tempo real com Google Sheets ativada.');
    }
  }, [sheetsConfig, persistSheetsConfig, performSheetsSync, savedLeads, showToast]);

  const handleDisableRealtime = useCallback(async () => {
    if (!sheetsConfig) return;
    await persistSheetsConfig({
      spreadsheetId: sheetsConfig.spreadsheetId,
      spreadsheetTitle: sheetsConfig.spreadsheetTitle,
      spreadsheetUrl: sheetsConfig.spreadsheetUrl,
      sheetName: sheetsConfig.sheetName,
      autoSyncEnabled: false,
    });
    setRealtimeSessionConfirmed(false);
    showToast('Sincronização em tempo real desativada.');
  }, [sheetsConfig, persistSheetsConfig, showToast]);

  // Debounced real-time sync whenever savedLeads mutate while session auto-sync is confirmed
  useEffect(() => {
    if (
      savedMutationVersion === 0 ||
      isLoadingSaved ||
      !sheetsConfig?.autoSyncEnabled ||
      !realtimeSessionConfirmed ||
      needsGoogleAuth
    ) {
      return;
    }

    const currentSnapshot = buildLeadsSnapshotKey(savedLeads);
    if (currentSnapshot === lastSyncedSnapshotKeyRef.current) {
      return;
    }

    const timer = window.setTimeout(() => {
      void performSheetsSync(savedLeads, sheetsConfig, true);
    }, 1200);

    return () => window.clearTimeout(timer);
  }, [
    savedMutationVersion,
    savedLeads,
    isLoadingSaved,
    sheetsConfig,
    realtimeSessionConfirmed,
    needsGoogleAuth,
    buildLeadsSnapshotKey,
    performSheetsSync,
  ]);

  useEffect(() => {
    if (mapsLoadingStatus === APILoadingStatus.AUTH_FAILURE) {
      window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
    }
  }, [mapsLoadingStatus]);

  const handleRunAutoRuleNow = useCallback(
    async (rule: AutoProspectRule) => {
      if (!placesLib) {
        showToast('Aguardar inicialização do Google Maps Places...');
        return;
      }
      if (runningRuleIdsRef.current[rule.id]) return;

      runningRuleIdsRef.current[rule.id] = true;
      setRunningRuleId(rule.id);

      try {
        const cityObj =
          MOZAMBIQUE_CITIES.find((c) => c.name.toLowerCase() === rule.city.toLowerCase()) ??
          MOZAMBIQUE_CITIES[0];

        const { places } = await placesLib.Place.searchByText({
          textQuery: `${rule.query} em ${rule.city}, Moçambique`,
          fields: [
            'id',
            'displayName',
            'formattedAddress',
            'shortFormattedAddress',
            'location',
            'nationalPhoneNumber',
            'internationalPhoneNumber',
            'websiteURI',
            'rating',
            'userRatingCount',
            'primaryTypeDisplayName',
            'primaryType',
            'businessStatus',
            'googleMapsURI',
          ],
          language: 'pt',
          region: 'MZ',
          maxResultCount: 20,
          locationBias: {
            center: { lat: cityObj.lat, lng: cityObj.lng },
            radius: 15000,
          },
        });

        const safePlaces = places ?? [];
        const scannedLeads: LeadRecord[] = safePlaces
          .filter((place) => Boolean(place.id && place.location))
          .map((place) => {
            const rawPhone =
              place.internationalPhoneNumber || place.nationalPhoneNumber || null;
            const phoneParsed = parseMozambiquePhone(rawPhone);
            const webParsed = classifyWebsite(place.websiteURI);
            return {
              placeId: place.id,
              campaignId: null,
              name: place.displayName || 'Estabelecimento sem nome',
              niche: rule.query,
              primaryType: place.primaryTypeDisplayName || place.primaryType || null,
              address:
                place.formattedAddress ||
                place.shortFormattedAddress ||
                `${rule.city}, Moçambique`,
              city: rule.city,
              province: rule.province,
              lat: place.location!.lat(),
              lng: place.location!.lng(),
              phoneRaw: rawPhone,
              whatsappNumber: phoneParsed.formattedE164,
              waDigits: phoneParsed.waDigits,
              carrier: phoneParsed.carrier,
              hasMobileWhatsApp: phoneParsed.isMobileWhatsApp,
              websiteUrl: webParsed.websiteUrl,
              websiteStatus: webParsed.websiteStatus,
              isQualifiedTarget:
                phoneParsed.isMobileWhatsApp && webParsed.websiteStatus !== 'has_website',
              rating: typeof place.rating === 'number' ? place.rating : null,
              reviewCount:
                typeof place.userRatingCount === 'number' ? place.userRatingCount : 0,
              businessStatus: place.businessStatus ? String(place.businessStatus) : null,
              googleMapsUri: sanitizeExternalHttpUrl(place.googleMapsURI),
              opportunityScore: null,
              scoreRationale: null,
              pipelineStatus: 'novo',
              notes: '',
            };
          });

        const res = await fetch(`/api/auto-prospect/rules/${encodeURIComponent(rule.id)}/complete-run`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ leads: scannedLeads }),
        });

        if (!res.ok) {
          throw new Error('Falha ao processar resumo da pesquisa recorrente.');
        }

        const outcome = (await res.json()) as {
          rule: AutoProspectRule;
          digest: AutoProspectDigest;
        };

        setAutoRules((prev) =>
          prev.map((r) => (r.id === outcome.rule.id ? outcome.rule : r))
        );
        setAutoDigests((prev) => [outcome.digest, ...prev]);

        const count = outcome.digest.newWithoutWebsiteCount;
        const msg =
          count > 0
            ? `Auto-Prospecção: ${count} novos negócios sem website em "${rule.query} em ${rule.city}".`
            : `Auto-Prospecção verificada para "${rule.query} em ${rule.city}" (sem novos leads).`;
        showToast(msg);

        if (
          typeof window !== 'undefined' &&
          'Notification' in window &&
          Notification.permission === 'granted'
        ) {
          new Notification('Minera.ia · Resumo de Auto-Prospecção', {
            body: msg,
          });
        }
        delete failedRuleCooldownRef.current[rule.id];
      } catch (err) {
        failedRuleCooldownRef.current[rule.id] = Date.now() + 10 * 60 * 1000;
        if (isQuotaError(err)) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        showToast('Erro ao executar pesquisa recorrente de Auto-Prospecção.');
      } finally {
        delete runningRuleIdsRef.current[rule.id];
        setRunningRuleId(null);
      }
    },
    [placesLib, showToast]
  );

  // Automatic due-schedule check on load and every 60s
  useEffect(() => {
    if (!placesLib || autoRules.length === 0) return;
    const checkDueRules = () => {
      const nowMs = Date.now();
      const dueRule = autoRules.find((r) => {
        if (!r.isActive || runningRuleIdsRef.current[r.id]) return false;
        const cooldownUntil = failedRuleCooldownRef.current[r.id] ?? 0;
        if (cooldownUntil > nowMs) return false;
        return new Date(r.nextRunAt).getTime() <= nowMs;
      });
      if (dueRule) {
        void handleRunAutoRuleNow(dueRule);
      }
    };
    checkDueRules();
    const timer = window.setInterval(checkDueRules, 60000);
    return () => window.clearInterval(timer);
  }, [placesLib, autoRules, handleRunAutoRuleNow]);

  const handleCreateAutoRule = useCallback(
    async (input: {
      query: string;
      city: MozambiqueCity;
      frequency: AutoProspectFrequency;
      dayOfWeek: number;
      recipientEmail: string;
      onlyWithoutWebsite: boolean;
    }) => {
      const res = await fetch('/api/auto-prospect/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: input.query,
          city: input.city.name,
          province: input.city.province,
          frequency: input.frequency,
          dayOfWeek: input.dayOfWeek,
          recipientEmail: input.recipientEmail,
          onlyWithoutWebsite: input.onlyWithoutWebsite,
        }),
      });
      const data = (await res.json()) as { rule?: AutoProspectRule; error?: string };
      if (!res.ok || !data.rule) {
        throw new Error(data.error || 'Erro ao guardar regra.');
      }
      setAutoRules((prev) => [data.rule!, ...prev]);
      showToast(`Auto-Prospecção criada para "${input.query} em ${input.city.name}".`);
    },
    [showToast]
  );

  const handleToggleAutoRule = useCallback(async (rule: AutoProspectRule) => {
    const res = await fetch(`/api/auto-prospect/rules/${encodeURIComponent(rule.id)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isActive: !rule.isActive }),
    });
    if (!res.ok) return;
    const data = (await res.json()) as { rule?: AutoProspectRule };
    if (data.rule) {
      setAutoRules((prev) => prev.map((r) => (r.id === rule.id ? data.rule! : r)));
    }
  }, []);

  const handleDeleteAutoRule = useCallback(
    async (ruleId: string) => {
      const res = await fetch(`/api/auto-prospect/rules/${encodeURIComponent(ruleId)}`, {
        method: 'DELETE',
      });
      if (!res.ok) return;
      setAutoRules((prev) => prev.filter((r) => r.id !== ruleId));
      setAutoDigests((prev) => prev.filter((d) => d.ruleId !== ruleId));
      showToast('Regra de Auto-Prospecção removida.');
    },
    [showToast]
  );

  const handleMarkDigestRead = useCallback(async (digestId: string) => {
    const res = await fetch(
      `/api/auto-prospect/digests/${encodeURIComponent(digestId)}/read`,
      { method: 'POST' }
    );
    if (!res.ok) return;
    setAutoDigests((prev) =>
      prev.map((d) => (d.id === digestId ? { ...d, isRead: true } : d))
    );
  }, []);

  const handleMarkAllDigestsRead = useCallback(async () => {
    const res = await fetch('/api/auto-prospect/digests/read-all', { method: 'POST' });
    if (!res.ok) return;
    setAutoDigests((prev) => prev.map((d) => ({ ...d, isRead: true })));
  }, []);

  const scoreLeadBatchWithAi = useCallback(async (leadsToScore: LeadRecord[]) => {
    if (leadsToScore.length === 0) return;
    setIsScoringAi(true);
    setAiError(null);
    try {
      const payload: AiScoreRequestItem[] = leadsToScore.slice(0, 20).map((l) => ({
        placeId: l.placeId,
        name: l.name,
        niche: l.niche,
        city: l.city,
        province: l.province,
        rating: l.rating,
        reviewCount: l.reviewCount,
        websiteStatus: l.websiteStatus,
        hasMobileWhatsApp: l.hasMobileWhatsApp,
        carrier: l.carrier,
        businessStatus: l.businessStatus,
      }));

      const res = await fetch('/api/ai/score-leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leads: payload }),
      });

      const data = (await res.json()) as { scores?: AiScoreResultItem[]; error?: string };
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao calcular pontuação de oportunidade.');
      }

      const scoreDict: Record<string, AiScoreResultItem> = {};
      for (const s of data.scores ?? []) {
        scoreDict[s.placeId] = s;
      }

      setMinedLeads((prev) =>
        prev.map((lead) =>
          scoreDict[lead.placeId]
            ? {
                ...lead,
                opportunityScore: scoreDict[lead.placeId].opportunityScore,
                scoreRationale: scoreDict[lead.placeId].scoreRationale,
              }
            : lead
        )
      );

      let hasSavedScoreUpdate = false;
      setSavedLeads((prev) =>
        prev.map((lead) => {
          if (!scoreDict[lead.placeId]) return lead;
          hasSavedScoreUpdate = true;
          return {
            ...lead,
            opportunityScore: scoreDict[lead.placeId].opportunityScore,
            scoreRationale: scoreDict[lead.placeId].scoreRationale,
          };
        })
      );
      if (hasSavedScoreUpdate) {
        setSavedMutationVersion((v) => v + 1);
      }
    } catch (err) {
      setAiError(
        err instanceof Error ? err.message : 'Não foi possível calcular a pontuação IA.'
      );
    } finally {
      setIsScoringAi(false);
    }
  }, []);

  const executePlacesMining = useCallback(
    async (options: {
      queryText: string;
      city: MozambiqueCity;
      bounds?: google.maps.LatLngBoundsLiteral;
      centerOverride?: { lat: number; lng: number };
      includedType?: string;
    }) => {
      if (!placesLib) {
        setMiningError('O serviço Google Maps Places ainda está a carregar. Tente dentro de instantes.');
        return;
      }

      const cleanQuery = options.queryText.trim();
      if (!cleanQuery) {
        setMiningError('Escreva o nome de um negócio ou actividade para pesquisar.');
        return;
      }

      setIsMining(true);
      setHasSearchedOnce(true);
      setMiningError(null);
      setAiError(null);
      setSelectedLeadId(null);

      try {
        const campaignId = `camp_${Date.now()}`;
        const textQuery = options.bounds
          ? cleanQuery
          : `${cleanQuery} em ${options.city.name}, Moçambique`;

        const request: google.maps.places.SearchByTextRequest = {
          textQuery,
          fields: [
            'id',
            'displayName',
            'formattedAddress',
            'shortFormattedAddress',
            'location',
            'nationalPhoneNumber',
            'internationalPhoneNumber',
            'websiteURI',
            'rating',
            'userRatingCount',
            'primaryTypeDisplayName',
            'primaryType',
            'businessStatus',
            'googleMapsURI',
          ],
          language: 'pt',
          region: 'MZ',
          maxResultCount: 20,
          ...(options.includedType && !options.bounds ? { includedType: options.includedType } : {}),
          locationBias: options.bounds
            ? options.bounds
            : {
                center: options.centerOverride ?? {
                  lat: options.city.lat,
                  lng: options.city.lng,
                },
                radius: 15000,
              },
        };

        const { places } = await placesLib.Place.searchByText(request);
        const safePlaces = places ?? [];

        const mappedLeads: LeadRecord[] = safePlaces
          .filter((place) => Boolean(place.id && place.location))
          .map((place) => {
            const placeId = place.id;
            const rawPhone =
              place.internationalPhoneNumber || place.nationalPhoneNumber || null;
            const phoneParsed = parseMozambiquePhone(rawPhone);
            const webParsed = classifyWebsite(place.websiteURI);
            const isQualifiedTarget =
              phoneParsed.isMobileWhatsApp && webParsed.websiteStatus !== 'has_website';

            const existing = savedByPlaceId[placeId];

            return {
              placeId,
              campaignId,
              name: place.displayName || 'Estabelecimento sem nome',
              niche: cleanQuery,
              primaryType: place.primaryTypeDisplayName || place.primaryType || null,
              address:
                place.formattedAddress ||
                place.shortFormattedAddress ||
                `${options.city.name}, Moçambique`,
              city: options.city.name,
              province: options.city.province,
              lat: place.location!.lat(),
              lng: place.location!.lng(),
              phoneRaw: rawPhone,
              whatsappNumber: phoneParsed.formattedE164,
              waDigits: phoneParsed.waDigits,
              carrier: phoneParsed.carrier,
              hasMobileWhatsApp: phoneParsed.isMobileWhatsApp,
              websiteUrl: webParsed.websiteUrl,
              websiteStatus: webParsed.websiteStatus,
              isQualifiedTarget,
              rating: typeof place.rating === 'number' ? place.rating : null,
              reviewCount:
                typeof place.userRatingCount === 'number' ? place.userRatingCount : 0,
              businessStatus: place.businessStatus ? String(place.businessStatus) : null,
              googleMapsUri: sanitizeExternalHttpUrl(place.googleMapsURI),
              opportunityScore: existing?.opportunityScore ?? null,
              scoreRationale: existing?.scoreRationale ?? null,
              pipelineStatus: existing?.pipelineStatus ?? 'novo',
              notes: existing?.notes ?? '',
              isSaved: Boolean(existing),
            };
          });

        // Sort so businesses without website + mobile phone appear first
        mappedLeads.sort((a, b) => {
          const rank = (l: LeadRecord) =>
            l.isQualifiedTarget ? 3 : l.websiteStatus !== 'has_website' ? 2 : 1;
          return rank(b) - rank(a);
        });

        setMinedLeads(mappedLeads);

        const qualified = mappedLeads.filter((l) => l.isQualifiedTarget);

        try {
          await fetch('/api/campaigns', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              id: campaignId,
              niche: cleanQuery,
              city: options.city.name,
              province: options.city.province,
              totalFound: mappedLeads.length,
              qualifiedCount: qualified.length,
              createdAt: new Date().toISOString(),
            }),
          });
          void fetchCampaigns();
        } catch (campErr) {
          console.error('Erro ao registar campanha:', campErr);
        }

        if (mappedLeads.length > 0) {
          void scoreLeadBatchWithAi(mappedLeads);
        }
      } catch (err) {
        if (isQuotaError(err)) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
          setMiningError(
            'Limite de consultas do Google Maps atingido. Verifique a cota do projeto.'
          );
        } else {
          setMiningError(
            err instanceof Error
              ? `Erro ao pesquisar estabelecimentos: ${err.message}`
              : 'Falha ao consultar estabelecimentos no Google Maps.'
          );
        }
      } finally {
        setIsMining(false);
      }
    },
    [placesLib, savedByPlaceId, fetchCampaigns, scoreLeadBatchWithAi]
  );

  const handleSaveLead = useCallback(
    async (lead: LeadRecord) => {
      try {
        const res = await fetch('/api/leads/bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ leads: [lead] }),
        });
        if (!res.ok) throw new Error('Erro ao guardar lead no servidor.');
        const data = (await res.json()) as { leads?: LeadRecord[] };
        const saved = data.leads?.[0];
        if (saved) {
          setMinedLeads((prev) =>
            prev.map((l) => (l.placeId === saved.placeId ? { ...saved, isSaved: true } : l))
          );
          await fetchSavedLeads();
          setSavedMutationVersion((v) => v + 1);
          showToast(`"${lead.name}" guardado nos seus leads.`);
        }
      } catch (err) {
        console.error(err);
        showToast('Erro ao guardar lead no servidor.');
        throw err instanceof Error ? err : new Error('Erro ao guardar lead no servidor.');
      }
    },
    [fetchSavedLeads, showToast]
  );

  const handleSaveBatch = useCallback(
    async (targets: LeadRecord[]) => {
      if (targets.length === 0) return;
      setIsSavingBulk(true);
      try {
        const res = await fetch('/api/leads/bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ leads: targets }),
        });
        if (!res.ok) throw new Error('Falha ao guardar lote de leads.');
        const data = (await res.json()) as { leads?: LeadRecord[]; count?: number };
        const savedDict: Record<string, LeadRecord> = {};
        for (const s of data.leads ?? []) {
          savedDict[s.placeId] = s;
        }
        setMinedLeads((prev) =>
          prev.map((l) =>
            savedDict[l.placeId] ? { ...savedDict[l.placeId], isSaved: true } : l
          )
        );
        await fetchSavedLeads();
        setSavedMutationVersion((v) => v + 1);
        showToast(`${data.count ?? targets.length} negócios guardados.`);
      } catch (err) {
        console.error(err);
        showToast('Não foi possível guardar os negócios selecionados.');
      } finally {
        setIsSavingBulk(false);
      }
    },
    [fetchSavedLeads, showToast]
  );

  const handleUpdateLead = useCallback(
    async (
      placeId: string,
      updates: { pipelineStatus?: PipelineStatus; notes?: string }
    ) => {
      const res = await fetch(`/api/leads/${encodeURIComponent(placeId)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (!res.ok) {
        throw new Error('Falha ao atualizar lead.');
      }
      const data = (await res.json()) as { lead?: LeadRecord };
      if (data.lead) {
        const updated = { ...data.lead, isSaved: true };
        setSavedLeads((prev) =>
          prev.map((l) => (l.placeId === placeId ? updated : l))
        );
        setMinedLeads((prev) =>
          prev.map((l) => (l.placeId === placeId ? updated : l))
        );
        setSavedMutationVersion((v) => v + 1);
      }
    },
    []
  );

  const handleDeleteLead = useCallback(
    async (placeId: string) => {
      const res = await fetch(`/api/leads/${encodeURIComponent(placeId)}`, {
        method: 'DELETE',
      });
      if (!res.ok) return;
      setSavedLeads((prev) => prev.filter((l) => l.placeId !== placeId));
      setMinedLeads((prev) =>
        prev.map((l) => (l.placeId === placeId ? { ...l, isSaved: false } : l))
      );
      setSavedMutationVersion((v) => v + 1);
      showToast('Lead removido da lista guardada.');
    },
    [showToast]
  );

  const handleRefreshFromMaps = useCallback(
    async (placeId: string) => {
      if (!placesLib) return;
      const existing = savedByPlaceId[placeId];
      if (!existing) return;

      setIsRefreshingId(placeId);
      try {
        const place = new placesLib.Place({ id: placeId });
        await place.fetchFields({
          fields: [
            'displayName',
            'formattedAddress',
            'nationalPhoneNumber',
            'internationalPhoneNumber',
            'websiteURI',
            'rating',
            'userRatingCount',
            'businessStatus',
            'googleMapsURI',
          ],
        });

        const rawPhone =
          place.internationalPhoneNumber || place.nationalPhoneNumber || null;
        const phoneParsed = parseMozambiquePhone(rawPhone);
        const webParsed = classifyWebsite(place.websiteURI);

        const refreshed: LeadRecord = {
          ...existing,
          name: place.displayName || existing.name,
          address: place.formattedAddress || existing.address,
          phoneRaw: rawPhone,
          whatsappNumber: phoneParsed.formattedE164,
          waDigits: phoneParsed.waDigits,
          carrier: phoneParsed.carrier,
          hasMobileWhatsApp: phoneParsed.isMobileWhatsApp,
          websiteUrl: webParsed.websiteUrl,
          websiteStatus: webParsed.websiteStatus,
          isQualifiedTarget:
            phoneParsed.isMobileWhatsApp && webParsed.websiteStatus !== 'has_website',
          rating: typeof place.rating === 'number' ? place.rating : existing.rating,
          reviewCount:
            typeof place.userRatingCount === 'number'
              ? place.userRatingCount
              : existing.reviewCount,
          businessStatus: place.businessStatus
            ? String(place.businessStatus)
            : existing.businessStatus,
          googleMapsUri:
            sanitizeExternalHttpUrl(place.googleMapsURI) ?? existing.googleMapsUri,
        };

        const bulkRes = await fetch('/api/leads/bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ leads: [refreshed] }),
        });
        if (!bulkRes.ok) {
          throw new Error('Falha ao atualizar lead no servidor.');
        }

        setMinedLeads((prev) =>
          prev.map((l) => (l.placeId === placeId ? { ...refreshed, isSaved: true } : l))
        );
        await fetchSavedLeads();
        setSavedMutationVersion((v) => v + 1);
        showToast('Dados atualizados a partir do Google Maps.');
      } catch (err) {
        if (isQuotaError(err)) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        showToast('Não foi possível atualizar os dados deste estabelecimento.');
      } finally {
        setIsRefreshingId(null);
      }
    },
    [placesLib, savedByPlaceId, fetchSavedLeads, showToast]
  );

  const citiesForSelectedProvince = useMemo(() => {
    if (selectedProvince === 'all') return MOZAMBIQUE_CITIES;
    return MOZAMBIQUE_CITIES.filter((c) => c.province === selectedProvince);
  }, [selectedProvince]);

  const visibleRadarLeads = useMemo(() => {
    return minedLeads.filter((lead) => {
      if (phoneFilter === 'with_phone' && !lead.phoneRaw) return false;
      if (phoneFilter === 'mobile_mz' && !lead.hasMobileWhatsApp) return false;

      if (websiteFilter === 'no_website' && lead.websiteStatus === 'has_website') return false;
      if (websiteFilter === 'none_only' && lead.websiteStatus !== 'none') return false;
      if (websiteFilter === 'social_only' && lead.websiteStatus !== 'social_only') return false;
      if (websiteFilter === 'has_website' && lead.websiteStatus !== 'has_website') return false;

      return true;
    });
  }, [minedLeads, phoneFilter, websiteFilter]);

  const radarStats = useMemo(() => {
    const total = minedLeads.length;
    const noWebsite = minedLeads.filter((l) => l.websiteStatus !== 'has_website').length;
    const withPhone = minedLeads.filter((l) => Boolean(l.phoneRaw)).length;
    const mobileEligible = minedLeads.filter((l) => l.hasMobileWhatsApp).length;
    return { total, noWebsite, withPhone, mobileEligible };
  }, [minedLeads]);

  const unsavedWithoutWebsite = useMemo(
    () =>
      visibleRadarLeads.filter(
        (l) => l.websiteStatus !== 'has_website' && !l.isSaved
      ),
    [visibleRadarLeads]
  );

  const selectedRadarLead =
    visibleRadarLeads.find((l) => l.placeId === selectedLeadId) ??
    minedLeads.find((l) => l.placeId === selectedLeadId) ??
    null;

  const handleSelectCity = (city: MozambiqueCity) => {
    setSelectedCity(city);
    setSelectedProvince(city.province);
    setMapCamera({ lat: city.lat, lng: city.lng, zoom: city.zoom });
  };

  const handleSelectProvince = (province: string) => {
    setSelectedProvince(province);
    if (province !== 'all') {
      const cityInProvince = MOZAMBIQUE_CITIES.find((c) => c.province === province);
      if (cityInProvince && selectedCity.province !== province) {
        setSelectedCity(cityInProvince);
        setMapCamera({
          lat: cityInProvince.lat,
          lng: cityInProvince.lng,
          zoom: cityInProvince.zoom,
        });
      }
    }
  };

  const handleSelectPreset = (presetId: string) => {
    const preset = NICHE_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    setSelectedPresetId(preset.id);
    setNicheQuery(preset.query);
  };

  const triggerExploreSearch = () => {
    const presetMatch = NICHE_PRESETS.find(
      (p) => p.id === selectedPresetId && p.query === nicheQuery
    );
    void executePlacesMining({
      queryText: nicheQuery,
      city: selectedCity,
      includedType: presetMatch?.includedType,
    });
  };

  const handleRelaunchCampaign = (camp: CampaignRecord) => {
    const matchedCity =
      MOZAMBIQUE_CITIES.find(
        (c) => c.name.toLowerCase() === camp.city.toLowerCase()
      ) ?? MOZAMBIQUE_CITIES[0];
    setSelectedCity(matchedCity);
    setSelectedProvince(matchedCity.province);
    setMapCamera({ lat: matchedCity.lat, lng: matchedCity.lng, zoom: matchedCity.zoom });
    setNicheQuery(camp.niche);
    setSelectedPresetId('');
    setActiveTab('explore');
    void executePlacesMining({ queryText: camp.niche, city: matchedCity });
  };

  const handleTopBarExport = () => {
    if (activeTab === 'saved') {
      if (savedLeads.length === 0) {
        showToast('Ainda não tem leads guardados para exportar.');
        return;
      }
      window.location.href = '/api/leads/export';
      return;
    }
    if (activeTab === 'explore') {
      if (visibleRadarLeads.length > 0) {
        buildClientCsvAndDownload(
          visibleRadarLeads,
          `minera-ia-${selectedCity.id}-${Date.now()}.csv`
        );
        return;
      }
      if (minedLeads.length > 0) {
        showToast('Nenhum resultado visível com os filtros atuais para exportar.');
        return;
      }
    }
    if (savedLeads.length === 0) {
      showToast('Pesquise negócios no mapa ou guarde leads antes de exportar CSV.');
      return;
    }
    window.location.href = '/api/leads/export';
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex flex-col">
      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      <div className="flex flex-1 min-h-0 relative">
        {/* Mobile backdrop */}
        {mobileMenuOpen && (
          <div
            onClick={() => setMobileMenuOpen(false)}
            className="fixed inset-0 bg-slate-900/30 z-30 lg:hidden"
            aria-hidden="true"
          />
        )}

        {/* Compact Left Sidebar */}
        <aside
          className={`${
            mobileMenuOpen ? 'fixed inset-y-0 left-0 z-40 flex' : 'hidden'
          } lg:flex lg:static w-[256px] shrink-0 flex-col bg-white border-r border-slate-200`}
        >
          <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200 shrink-0">
            <div>
              <span className="font-display text-lg font-bold tracking-tight text-slate-900 block leading-none">
                Minera.ia
              </span>
              <span className="text-xs text-slate-500 mt-1 block">Moçambique</span>
            </div>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              aria-label="Fechar menu"
              className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-4 space-y-5 overflow-y-auto flex-1">
            {/* Primary Navigation */}
            <nav aria-label="Navegação principal" className="space-y-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('explore');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${
                  activeTab === 'explore'
                    ? 'bg-emerald-50 text-emerald-800 font-semibold'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Compass className="w-4 h-4 shrink-0" />
                <span>Explorar</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('saved');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${
                  activeTab === 'saved'
                    ? 'bg-emerald-50 text-emerald-800 font-semibold'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <span className="inline-flex items-center gap-2.5">
                  <Database className="w-4 h-4 shrink-0" />
                  <span>Leads guardados</span>
                </span>
                <span className="font-mono tabular-nums text-xs text-slate-500">
                  {savedLeads.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('campaigns');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${
                  activeTab === 'campaigns'
                    ? 'bg-emerald-50 text-emerald-800 font-semibold'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <span className="inline-flex items-center gap-2.5">
                  <History className="w-4 h-4 shrink-0" />
                  <span>Campanhas</span>
                </span>
                <span className="font-mono tabular-nums text-xs text-slate-500">
                  {campaigns.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('auto');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${
                  activeTab === 'auto'
                    ? 'bg-emerald-50 text-emerald-800 font-semibold'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <span className="inline-flex items-center gap-2.5">
                  <Bell className="w-4 h-4 shrink-0" />
                  <span>Auto-Prospecção</span>
                </span>
                {autoDigests.filter((d) => !d.isRead).length > 0 ? (
                  <span className="font-mono tabular-nums text-xs font-semibold text-emerald-700">
                    {autoDigests.filter((d) => !d.isRead).length}
                  </span>
                ) : (
                  <span className="font-mono tabular-nums text-xs text-slate-500">
                    {autoRules.length}
                  </span>
                )}
              </button>
            </nav>

            {/* Collapsible Cities / Provinces Filter */}
            <div className="pt-4 border-t border-slate-200">
              <button
                type="button"
                aria-expanded={citiesSectionOpen}
                onClick={() => setCitiesSectionOpen((prev) => !prev)}
                className="w-full flex items-center justify-between px-1 py-1 text-xs font-semibold text-slate-800 hover:text-slate-950 cursor-pointer"
              >
                <span>Cidades e províncias</span>
                <ChevronDown
                  className={`w-4 h-4 text-slate-500 transition-transform ${
                    citiesSectionOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {citiesSectionOpen && (
                <div className="mt-2 space-y-1">
                  {MOZAMBIQUE_CITIES.map((city) => {
                    const active = selectedCity.id === city.id;
                    return (
                      <button
                        key={city.id}
                        type="button"
                        onClick={() => {
                          handleSelectCity(city);
                          setActiveTab('explore');
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-between gap-2 ${
                          active
                            ? 'bg-emerald-50 text-emerald-800 font-semibold'
                            : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                        }`}
                      >
                        <span className="truncate">{city.name}</span>
                        <span className="text-slate-500 text-xs truncate shrink-0">
                          {city.province.replace('Cidade de ', '').replace(' Província', '')}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Collapsible Niches Filter */}
            <div className="pt-4 border-t border-slate-200">
              <button
                type="button"
                aria-expanded={nichesSectionOpen}
                onClick={() => setNichesSectionOpen((prev) => !prev)}
                className="w-full flex items-center justify-between px-1 py-1 text-xs font-semibold text-slate-800 hover:text-slate-950 cursor-pointer"
              >
                <span>Nichos</span>
                <ChevronDown
                  className={`w-4 h-4 text-slate-500 transition-transform ${
                    nichesSectionOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {nichesSectionOpen && (
                <div className="mt-2 space-y-1">
                  {NICHE_PRESETS.map((preset) => {
                    const active = selectedPresetId === preset.id && nicheQuery === preset.query;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => {
                          handleSelectPreset(preset.id);
                          setActiveTab('explore');
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer truncate ${
                          active
                            ? 'bg-emerald-50 text-emerald-800 font-semibold'
                            : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                        }`}
                      >
                        {preset.label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="p-4 border-t border-slate-200 text-xs text-slate-500 leading-relaxed">
            Cobertura Moçambique (+258) · números móveis 82–87 elegíveis para WhatsApp.
          </div>
        </aside>

        {/* Main Workspace */}
        <div className="flex-1 min-w-0 flex flex-col">
          {/* Mobile menu bar & Desktop Page Header */}
          <header className="bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 py-4 shrink-0">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex items-start gap-3 min-w-0">
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(true)}
                  aria-label="Abrir navegação"
                  className="lg:hidden mt-0.5 p-2 rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                >
                  <Menu className="w-4 h-4" />
                </button>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 mb-1">
                    <span className="inline-flex items-center gap-1 font-medium text-emerald-700">
                      <MapPin className="w-3.5 h-3.5" />
                      {selectedCity.name} · {selectedCity.province}, Moçambique
                    </span>
                  </div>
                  <h1 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                    {activeTab === 'explore'
                      ? 'Encontre negócios que precisam de um website'
                      : activeTab === 'saved'
                      ? 'Leads guardados'
                      : activeTab === 'campaigns'
                      ? 'Histórico de campanhas'
                      : 'Auto-Prospecção'}
                  </h1>
                  <p className="text-xs sm:text-sm text-slate-600 mt-1">
                    {activeTab === 'explore'
                      ? 'Pesquise empresas por área e consulte telefones públicos. “Sem website” indica que não há website próprio registado na fonte de dados.'
                      : activeTab === 'saved'
                      ? 'Organize contactos guardados, registe notas e prepare abordagens pelo Web WhatsApp.'
                      : activeTab === 'campaigns'
                      ? 'Consulte as pesquisas anteriores por cidade e nicho para retomar rapidamente.'
                      : 'Agende pesquisas recorrentes e receba resumos semanais com novos negócios sem website.'}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setActiveTab('saved')}
                  className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-lg border text-xs sm:text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    sheetsConfig?.autoSyncEnabled && realtimeSessionConfirmed && !needsGoogleAuth
                      ? 'border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                      : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  {isSyncingSheets
                    ? 'A sincronizar Sheets...'
                    : sheetsConfig?.autoSyncEnabled &&
                      realtimeSessionConfirmed &&
                      !needsGoogleAuth
                    ? 'Sheets · Tempo real'
                    : 'Google Sheets'}
                </button>

                <button
                  type="button"
                  onClick={handleTopBarExport}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 text-xs sm:text-sm font-semibold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Download className="w-4 h-4" />
                  Exportar CSV
                </button>
              </div>
            </div>
          </header>

          {/* Main Scrollable Content */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-5 overflow-y-auto">
            {toastMessage && (
              <div
                role="status"
                className="px-4 py-3 rounded-xl border border-emerald-200 bg-emerald-50 text-sm text-emerald-900 flex items-center justify-between gap-3"
              >
                <span>{toastMessage}</span>
                <button
                  type="button"
                  onClick={() => setToastMessage(null)}
                  aria-label="Fechar aviso"
                  className="text-emerald-700 hover:text-emerald-950 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {activeTab === 'explore' && (
              <>
                {/* Search & Filter Bar */}
                <section
                  aria-label="Pesquisa e filtros"
                  className="p-4 sm:p-5 rounded-xl border border-slate-200 bg-white shadow-xs space-y-4"
                >
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      triggerExploreSearch();
                    }}
                    className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3"
                  >
                    <div className="flex-1 relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={nicheQuery}
                        onChange={(e) => {
                          setNicheQuery(e.target.value);
                          setSelectedPresetId('');
                        }}
                        placeholder="Pesquisar por nome do negócio ou actividade (ex.: clínica dentária, restaurante, oficina)..."
                        className="w-full rounded-lg bg-white border border-slate-300 pl-10 pr-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isMining || !placesLib}
                      className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 text-sm font-semibold text-white transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                    >
                      <Search className="w-4 h-4" />
                      {isMining ? 'A pesquisar...' : 'Pesquisar no mapa'}
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveTab('auto')}
                      title="Configurar pesquisa recorrente semanal"
                      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 text-sm font-medium text-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <CalendarClock className="w-4 h-4 text-emerald-600" />
                      Auto-Prospecção
                    </button>
                  </form>

                  {/* Filter Controls: Província, Cidade, Nicho, Telefone/WhatsApp, Website */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-3 border-t border-slate-100">
                    <div>
                      <label
                        htmlFor="filter-province"
                        className="block text-xs font-medium text-slate-600 mb-1"
                      >
                        Província
                      </label>
                      <select
                        id="filter-province"
                        value={selectedProvince}
                        onChange={(e) => handleSelectProvince(e.target.value)}
                        className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                      >
                        <option value="all">Todas as províncias</option>
                        {MOZAMBIQUE_PROVINCES.map((prov) => (
                          <option key={prov} value={prov}>
                            {prov}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="filter-city"
                        className="block text-xs font-medium text-slate-600 mb-1"
                      >
                        Cidade
                      </label>
                      <select
                        id="filter-city"
                        value={selectedCity.id}
                        onChange={(e) => {
                          const found = MOZAMBIQUE_CITIES.find((c) => c.id === e.target.value);
                          if (found) handleSelectCity(found);
                        }}
                        className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                      >
                        {citiesForSelectedProvince.map((city) => (
                          <option key={city.id} value={city.id}>
                            {city.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="filter-niche"
                        className="block text-xs font-medium text-slate-600 mb-1"
                      >
                        Nicho
                      </label>
                      <select
                        id="filter-niche"
                        value={selectedPresetId || 'custom'}
                        onChange={(e) => {
                          if (e.target.value !== 'custom') {
                            handleSelectPreset(e.target.value);
                          }
                        }}
                        className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                      >
                        {NICHE_PRESETS.map((preset) => (
                          <option key={preset.id} value={preset.id}>
                            {preset.label}
                          </option>
                        ))}
                        {!selectedPresetId && (
                          <option value="custom">Pesquisa personalizada</option>
                        )}
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="filter-phone"
                        className="block text-xs font-medium text-slate-600 mb-1"
                      >
                        Telefone / WhatsApp
                      </label>
                      <select
                        id="filter-phone"
                        value={phoneFilter}
                        onChange={(e) => setPhoneFilter(e.target.value as PhoneFilter)}
                        className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                      >
                        <option value="all">Todos os contactos</option>
                        <option value="with_phone">Com telefone publicado</option>
                        <option value="mobile_mz">Móvel +258 (elegível WhatsApp)</option>
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="filter-website"
                        className="block text-xs font-medium text-slate-600 mb-1"
                      >
                        Website
                      </label>
                      <select
                        id="filter-website"
                        value={websiteFilter}
                        onChange={(e) => setWebsiteFilter(e.target.value as WebsiteFilter)}
                        className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                      >
                        <option value="all">Todos os estados</option>
                        <option value="no_website">Sem website próprio</option>
                        <option value="none_only">Sem website registado</option>
                        <option value="social_only">Apenas rede social</option>
                        <option value="has_website">Com website registado</option>
                      </select>
                    </div>
                  </div>
                </section>

                {/* Maps status or Error Alerts */}
                {mapsLoadingStatus === APILoadingStatus.LOADING && (
                  <div className="px-4 py-3 rounded-xl border border-slate-200 bg-white text-xs text-slate-600">
                    A carregar mapa interativo de Moçambique...
                  </div>
                )}

                {miningError && (
                  <div
                    role="alert"
                    className="p-4 rounded-xl border border-rose-200 bg-rose-50 text-sm text-rose-900 flex flex-wrap items-center justify-between gap-3"
                  >
                    <span className="inline-flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                      {miningError}
                    </span>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={triggerExploreSearch}
                        className="text-xs font-semibold text-rose-800 hover:text-rose-950 underline cursor-pointer"
                      >
                        Tentar novamente
                      </button>
                      <button
                        type="button"
                        onClick={() => setMiningError(null)}
                        aria-label="Fechar erro"
                        className="text-rose-600 hover:text-rose-900 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}

                {aiError && (
                  <div
                    role="alert"
                    className="p-4 rounded-xl border border-amber-200 bg-amber-50 text-sm text-amber-900 flex flex-wrap items-center justify-between gap-3"
                  >
                    <span className="inline-flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      Pontuação IA indisponível: {aiError}
                    </span>
                    <button
                      type="button"
                      onClick={() => void scoreLeadBatchWithAi(minedLeads)}
                      disabled={isScoringAi}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-900 hover:text-amber-950 underline cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Tentar novamente
                    </button>
                  </div>
                )}

                {/* 4 Compact KPI Cards */}
                <section
                  aria-label="Indicadores da pesquisa"
                  className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
                >
                  <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-xs">
                    <p className="text-xs font-medium text-slate-600">Negócios encontrados</p>
                    <p className="text-2xl font-display font-bold text-slate-900 tabular-nums mt-1">
                      {radarStats.total}
                    </p>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-xs">
                    <p className="text-xs font-medium text-slate-600">Sem website</p>
                    <p className="text-2xl font-display font-bold text-emerald-700 tabular-nums mt-1">
                      {radarStats.noWebsite}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">Sem site registado</p>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-xs">
                    <p className="text-xs font-medium text-slate-600">Com telefone público</p>
                    <p className="text-2xl font-display font-bold text-slate-900 tabular-nums mt-1">
                      {radarStats.withPhone}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {radarStats.mobileEligible} móvel +258
                    </p>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-xs">
                    <p className="text-xs font-medium text-slate-600">Leads guardados</p>
                    <p className="text-2xl font-display font-bold text-slate-900 tabular-nums mt-1">
                      {savedLeads.length}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">Na sua lista CRM</p>
                  </div>
                </section>

                {/* Batch Action Strip (only shown when results exist) */}
                {minedLeads.length > 0 && (
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="text-xs sm:text-sm text-slate-600 tabular-nums">
                      A mostrar <strong className="text-slate-900">{visibleRadarLeads.length}</strong> de{' '}
                      <strong className="text-slate-900">{minedLeads.length}</strong> negócios em{' '}
                      {selectedCity.name}
                    </p>

                    <div className="flex flex-wrap items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => void scoreLeadBatchWithAi(minedLeads)}
                        disabled={isScoringAi}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                        {isScoringAi ? 'A pontuar...' : 'Pontuar com IA'}
                      </button>

                      {unsavedWithoutWebsite.length > 0 && (
                        <button
                          type="button"
                          onClick={() => void handleSaveBatch(unsavedWithoutWebsite)}
                          disabled={isSavingBulk}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-emerald-600 bg-emerald-50 hover:bg-emerald-100 text-xs font-semibold text-emerald-800 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                        >
                          <BookmarkPlus className="w-3.5 h-3.5" />
                          {isSavingBulk
                            ? 'A guardar...'
                            : `Guardar sem website (${unsavedWithoutWebsite.length})`}
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* Map-First Split: Map left/top + Results or Detail Drawer right/bottom */}
                <section
                  aria-label="Mapa e resultados"
                  className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start"
                >
                  <div className="lg:col-span-7 min-w-0">
                    <MozambiqueRadarMap
                      center={{ lat: mapCamera.lat, lng: mapCamera.lng }}
                      zoom={mapCamera.zoom}
                      leads={visibleRadarLeads}
                      selectedLeadId={selectedLeadId}
                      onSelectLead={(id) => setSelectedLeadId(id)}
                      isMining={isMining}
                      onSearchBounds={(bounds, center) => {
                        void executePlacesMining({
                          queryText: nicheQuery,
                          city: selectedCity,
                          bounds,
                          centerOverride: center,
                        });
                      }}
                    />
                  </div>

                  <div className="lg:col-span-5 min-w-0">
                    {selectedRadarLead ? (
                      <LeadDetailDrawer
                        lead={selectedRadarLead}
                        backLabel="Voltar aos resultados"
                        onClose={() => setSelectedLeadId(null)}
                        onSaveLead={handleSaveLead}
                        onUpdateLead={handleUpdateLead}
                        onScoreSingleLead={(lead) => scoreLeadBatchWithAi([lead])}
                        isScoring={isScoringAi}
                        senderEmail={outreachSenderEmail}
                        googleUser={googleUser}
                        needsGoogleAuth={needsGoogleAuth}
                        isGoogleLoggingIn={isGoogleLoggingIn}
                        onGoogleLogin={handleGoogleLogin}
                        onSendGmail={handleSendGmail}
                      />
                    ) : (
                      <RadarResultsList
                        leads={visibleRadarLeads}
                        totalUnfilteredCount={minedLeads.length}
                        selectedLeadId={selectedLeadId}
                        onSelectLead={(id) => setSelectedLeadId(id)}
                        onSaveLead={handleSaveLead}
                        isLoading={isMining}
                        cityName={selectedCity.name}
                        hasSearchedOnce={hasSearchedOnce}
                        onQuickSearch={triggerExploreSearch}
                        onResetFilters={() => {
                          setPhoneFilter('all');
                          setWebsiteFilter('all');
                        }}
                      />
                    )}
                  </div>
                </section>
              </>
            )}

            {activeTab === 'saved' && (
              <SavedLeadsView
                leads={savedLeads}
                isLoading={isLoadingSaved}
                isScoring={isScoringAi}
                onUpdateLead={handleUpdateLead}
                onDeleteLead={handleDeleteLead}
                onScoreLeads={scoreLeadBatchWithAi}
                onRefreshFromMaps={handleRefreshFromMaps}
                onSwitchToRadar={() => setActiveTab('explore')}
                isRefreshingId={isRefreshingId}
                googleSheetsProps={{
                  googleUser,
                  needsAuth: needsGoogleAuth,
                  isLoggingIn: isGoogleLoggingIn,
                  authError: googleAuthError,
                  config: sheetsConfig,
                  availableTabs: availableSheetTabs,
                  realtimeSessionConfirmed,
                  isSyncing: isSyncingSheets,
                  isConnectingSheet,
                  syncError: sheetsSyncError,
                  onGoogleLogin: () => handleGoogleLogin(outreachSenderEmail),
                  onGoogleLogout: handleGoogleLogout,
                  onCreateSpreadsheet: handleCreateSpreadsheet,
                  onConnectExistingSpreadsheet: handleConnectExistingSpreadsheet,
                  onRefreshTabs: handleRefreshSheetTabs,
                  onChangeTab: handleChangeSheetTab,
                  onDisconnectSpreadsheet: handleDisconnectSpreadsheet,
                  onConfirmSyncNow: handleConfirmSyncNow,
                  onConfirmEnableRealtime: handleConfirmEnableRealtime,
                  onDisableRealtime: handleDisableRealtime,
                }}
                gmailOutreachProps={{
                  senderEmail: outreachSenderEmail,
                  googleUser,
                  needsGoogleAuth,
                  isGoogleLoggingIn,
                  onGoogleLogin: handleGoogleLogin,
                  onSendGmail: handleSendGmail,
                }}
              />
            )}

            {activeTab === 'campaigns' && (
              <CampaignsView
                campaigns={campaigns}
                isLoading={isLoadingCampaigns}
                onRelaunchCampaign={handleRelaunchCampaign}
                onGoToRadar={() => setActiveTab('explore')}
              />
            )}

            {activeTab === 'auto' && (
              <AutoProspectView
                rules={autoRules}
                digests={autoDigests}
                isLoading={isLoadingAuto}
                runningRuleId={runningRuleId}
                defaultQuery={nicheQuery}
                defaultCity={selectedCity}
                onCreateRule={handleCreateAutoRule}
                onToggleRuleActive={handleToggleAutoRule}
                onDeleteRule={handleDeleteAutoRule}
                onRunRuleNow={handleRunAutoRuleNow}
                onMarkDigestRead={handleMarkDigestRead}
                onMarkAllDigestsRead={handleMarkAllDigestsRead}
                savedPlaceIds={Object.fromEntries(
                  Object.keys(savedByPlaceId).map((k) => [k, true])
                )}
                senderEmail={outreachSenderEmail}
                onSaveSenderEmail={handleSaveOutreachSenderEmail}
                googleUser={googleUser}
                needsGoogleAuth={needsGoogleAuth}
                isGoogleLoggingIn={isGoogleLoggingIn}
                onGoogleLogin={handleGoogleLogin}
                onSendGmail={handleSendGmail}
                onSaveDigestLead={async (
                  item: AutoProspectDigestLead,
                  ruleLabel: string,
                  cityName: string
                ) => {
                  const matchedCity =
                    MOZAMBIQUE_CITIES.find(
                      (c) => c.name.toLowerCase() === cityName.toLowerCase()
                    ) ?? selectedCity;
                  await handleSaveLead({
                    placeId: item.placeId,
                    name: item.name,
                    niche: ruleLabel,
                    primaryType: item.primaryType ?? null,
                    address: item.address,
                    city: item.city || matchedCity.name,
                    province: item.province || matchedCity.province,
                    lat: Number.isFinite(item.lat) ? item.lat : matchedCity.lat,
                    lng: Number.isFinite(item.lng) ? item.lng : matchedCity.lng,
                    phoneRaw: item.phoneRaw,
                    whatsappNumber: item.whatsappNumber,
                    waDigits: item.waDigits,
                    carrier: item.carrier,
                    hasMobileWhatsApp: item.hasMobileWhatsApp,
                    websiteUrl: item.websiteUrl ?? null,
                    websiteStatus: item.websiteStatus,
                    isQualifiedTarget:
                      item.hasMobileWhatsApp && item.websiteStatus !== 'has_website',
                    rating: item.rating,
                    reviewCount: item.reviewCount,
                    googleMapsUri: item.googleMapsUri,
                    opportunityScore: null,
                    scoreRationale: null,
                    pipelineStatus: 'novo',
                    notes: '',
                  });
                }}
              />
            )}

            <footer className="pt-5 border-t border-slate-200 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-2">
              <span>Minera.ia · Prospecção de negócios em Moçambique</span>
              <span>
                Contactos públicos e localização obtidos via Google Maps Platform (Places API)
              </span>
            </footer>
          </main>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [quotaExceeded, setQuotaExceeded] = useState(false);

  useEffect(() => {
    const handler = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handler);
    return () => window.removeEventListener('gmp-quota-exceeded', handler);
  }, []);

  if (!GOOGLE_MAPS_API_KEY) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex items-center justify-center p-6">
        <div className="max-w-md w-full rounded-xl border border-slate-200 bg-white p-6 space-y-3 shadow-xs">
          <h1 className="text-lg font-display font-bold text-slate-900">Minera.ia</h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            A chave do Google Maps Platform ainda não está configurada no cliente (
            <code className="font-mono text-emerald-700">VITE_GOOGLE_MAPS_API_KEY</code>).
            Ative o Google Maps nas definições da aplicação para carregar o mapa de Moçambique.
          </p>
        </div>
      </div>
    );
  }

  return (
    <APIProvider
      apiKey={GOOGLE_MAPS_API_KEY}
      language="pt"
      region="MZ"
      libraries={['places', 'marker']}
    >
      <WorkspaceShell quotaExceeded={quotaExceeded} />
    </APIProvider>
  );
}
