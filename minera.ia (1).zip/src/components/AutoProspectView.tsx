import type { User } from 'firebase/auth';
import {
  Bell,
  BellRing,
  BookmarkPlus,
  CalendarClock,
  Check,
  Copy,
  ExternalLink,
  Mail,
  Pause,
  Play,
  Plus,
  Send,
  Trash2,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { MOZAMBIQUE_CITIES, type MozambiqueCity } from '../data/mozambique.ts';
import type {
  AutoProspectDigest,
  AutoProspectDigestLead,
  AutoProspectFrequency,
  AutoProspectRule,
} from '../types/leads.ts';
import { GmailSendConfirmModal } from './GmailSendConfirmModal.tsx';

interface AutoProspectViewProps {
  rules: AutoProspectRule[];
  digests: AutoProspectDigest[];
  isLoading: boolean;
  runningRuleId: string | null;
  defaultQuery: string;
  defaultCity: MozambiqueCity;
  onCreateRule: (input: {
    query: string;
    city: MozambiqueCity;
    frequency: AutoProspectFrequency;
    dayOfWeek: number;
    recipientEmail: string;
    onlyWithoutWebsite: boolean;
  }) => Promise<void>;
  onToggleRuleActive: (rule: AutoProspectRule) => Promise<void>;
  onDeleteRule: (ruleId: string) => Promise<void>;
  onRunRuleNow: (rule: AutoProspectRule) => Promise<void>;
  onMarkDigestRead: (digestId: string) => Promise<void>;
  onMarkAllDigestsRead: () => Promise<void>;
  onSaveDigestLead: (
    lead: AutoProspectDigestLead,
    ruleLabel: string,
    cityName: string
  ) => Promise<void>;
  savedPlaceIds: Record<string, boolean>;
  senderEmail: string;
  onSaveSenderEmail: (email: string) => Promise<void>;
  googleUser: User | null;
  needsGoogleAuth: boolean;
  isGoogleLoggingIn: boolean;
  onGoogleLogin: (loginHint?: string) => Promise<void>;
  onSendGmail: (params: { to: string; subject: string; bodyText: string }) => Promise<void>;
}

const WEEKDAYS_PT = [
  { value: 1, label: 'Segunda-feira' },
  { value: 2, label: 'Terça-feira' },
  { value: 3, label: 'Quarta-feira' },
  { value: 4, label: 'Quinta-feira' },
  { value: 5, label: 'Sexta-feira' },
  { value: 6, label: 'Sábado' },
  { value: 0, label: 'Domingo' },
];

export function AutoProspectView({
  rules,
  digests,
  isLoading,
  runningRuleId,
  defaultQuery,
  defaultCity,
  onCreateRule,
  onToggleRuleActive,
  onDeleteRule,
  onRunRuleNow,
  onMarkDigestRead,
  onMarkAllDigestsRead,
  onSaveDigestLead,
  savedPlaceIds,
  senderEmail,
  onSaveSenderEmail,
  googleUser,
  needsGoogleAuth,
  isGoogleLoggingIn,
  onGoogleLogin,
  onSendGmail,
}: AutoProspectViewProps) {
  const [query, setQuery] = useState(defaultQuery || 'restaurantes');
  const [cityId, setCityId] = useState(defaultCity.id);
  const [frequency, setFrequency] = useState<AutoProspectFrequency>('weekly');
  const [dayOfWeek, setDayOfWeek] = useState<number>(1);
  const [recipientEmail, setRecipientEmail] = useState(senderEmail);
  const [onlyWithoutWebsite, setOnlyWithoutWebsite] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [senderInput, setSenderInput] = useState(senderEmail);
  const [isSavingSender, setIsSavingSender] = useState(false);
  const [senderSavedFlag, setSenderSavedFlag] = useState(false);
  const [senderError, setSenderError] = useState<string | null>(null);
  const [gmailDigestTarget, setGmailDigestTarget] = useState<AutoProspectDigest | null>(null);

  const [copiedDigestId, setCopiedDigestId] = useState<string | null>(null);
  const [notificationPermission, setNotificationPermission] = useState<
    NotificationPermission | 'unsupported'
  >(() =>
    typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'unsupported'
  );

  useEffect(() => {
    if (defaultQuery.trim()) {
      setQuery(defaultQuery);
    }
    setCityId(defaultCity.id);
  }, [defaultQuery, defaultCity.id]);

  useEffect(() => {
    setSenderInput(senderEmail);
    setRecipientEmail((prev) => (prev.trim() ? prev : senderEmail));
  }, [senderEmail]);

  const handleRequestBrowserNotifications = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    const result = await Notification.requestPermission();
    setNotificationPermission(result);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanQuery = query.trim();
    if (!cleanQuery) {
      setFormError('Indique a actividade ou nicho para a pesquisa recorrente.');
      return;
    }
    const cityObj = MOZAMBIQUE_CITIES.find((c) => c.id === cityId) ?? MOZAMBIQUE_CITIES[0];
    setFormError(null);
    setIsSubmitting(true);
    try {
      await onCreateRule({
        query: cleanQuery,
        city: cityObj,
        frequency,
        dayOfWeek,
        recipientEmail: recipientEmail.trim(),
        onlyWithoutWebsite,
      });
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : 'Erro ao criar regra de Auto-Prospecção.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyDigest = async (digest: AutoProspectDigest) => {
    try {
      await navigator.clipboard.writeText(`${digest.emailSubject}\n\n${digest.emailBody}`);
      setCopiedDigestId(digest.id);
      setTimeout(() => {
        setCopiedDigestId((prev) => (prev === digest.id ? null : prev));
      }, 1800);
    } catch {
      // Clipboard blocked
    }
  };

  const handleSaveSenderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSenderError(null);
    setIsSavingSender(true);
    try {
      await onSaveSenderEmail(senderInput.trim());
      setSenderSavedFlag(true);
      setTimeout(() => setSenderSavedFlag(false), 1800);
    } catch (err) {
      setSenderError(
        err instanceof Error ? err.message : 'Não foi possível guardar o e-mail de envio.'
      );
    } finally {
      setIsSavingSender(false);
    }
  };

  const unreadCount = digests.filter((d) => !d.isRead).length;

  return (
    <div className="space-y-6">
      {/* Prospecting Dispatch Account Card */}
      <section
        aria-label="Conta de envio das prospecções"
        className="p-4 sm:p-5 rounded-xl border border-slate-200 bg-white shadow-xs space-y-3"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              Conta de envio das prospecções (Gmail)
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Define o endereço responsável pelo envio dos resumos e abordagens comerciais.
            </p>
          </div>

          {needsGoogleAuth || !googleUser ? (
            <button
              type="button"
              onClick={() => void onGoogleLogin(senderEmail)}
              disabled={isGoogleLoggingIn}
              className="gsi-material-button inline-flex items-center gap-2.5 rounded-md border border-[#747775] bg-white hover:bg-[#f8faff] px-3.5 py-2 text-xs font-medium text-[#1f1f1f] shadow-xs transition-colors cursor-pointer disabled:opacity-60 shrink-0"
              style={{ fontFamily: 'Roboto, system-ui, sans-serif' }}
            >
              <div className="gsi-material-button-icon w-4 h-4 shrink-0">
                <svg
                  version="1.1"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 48 48"
                  style={{ display: 'block' }}
                >
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                  <path fill="none" d="M0 0h48v48H0z" />
                </svg>
              </div>
              <span>
                {isGoogleLoggingIn ? 'A autenticar...' : 'Sign in with Google'}
              </span>
            </button>
          ) : (
            <span className="text-xs text-slate-600">
              Sessão Gmail ativa:{' '}
              <strong className="text-slate-900">{googleUser.email || 'Conectada'}</strong>
            </span>
          )}
        </div>

        <form
          onSubmit={(e) => void handleSaveSenderSubmit(e)}
          className="flex flex-col sm:flex-row sm:items-center gap-2.5"
        >
          <input
            type="email"
            aria-label="E-mail que envia as prospecções"
            value={senderInput}
            onChange={(e) => setSenderInput(e.target.value)}
            placeholder="scottnaftal@gmail.com"
            className="flex-1 sm:max-w-sm rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
          />
          <button
            type="submit"
            disabled={isSavingSender}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            {senderSavedFlag ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                Guardado
              </>
            ) : isSavingSender ? (
              'A guardar...'
            ) : (
              'Guardar conta de envio'
            )}
          </button>
        </form>
        {senderError && (
          <p role="alert" className="text-xs text-rose-700">
            {senderError}
          </p>
        )}
      </section>

      {/* Configuration Form Card */}
      <section
        aria-label="Configurar Auto-Prospecção"
        className="p-5 rounded-xl border border-slate-200 bg-white shadow-xs space-y-4"
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Nova pesquisa recorrente
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
              Configure nicho, cidade e periodicidade para receber um resumo automático apenas
              com novos negócios sem website registado.
            </p>
          </div>

          {notificationPermission !== 'unsupported' && (
            <button
              type="button"
              onClick={() => void handleRequestBrowserNotifications()}
              disabled={notificationPermission === 'granted'}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                notificationPermission === 'granted'
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-800 cursor-default'
                  : 'border-slate-300 bg-white hover:bg-slate-50 text-slate-800 cursor-pointer'
              }`}
            >
              <BellRing className="w-3.5 h-3.5 text-emerald-600" />
              {notificationPermission === 'granted'
                ? 'Alertas do navegador ativos'
                : notificationPermission === 'denied'
                ? 'Alertas bloqueados no navegador'
                : 'Ativar alertas no navegador'}
            </button>
          )}
        </div>

        <form onSubmit={(e) => void handleSubmit(e)} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label
                htmlFor="auto-query"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Actividade / Nicho
              </label>
              <input
                id="auto-query"
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ex.: restaurantes, clínicas dentárias..."
                className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
              />
            </div>

            <div>
              <label
                htmlFor="auto-city"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Cidade em Moçambique
              </label>
              <select
                id="auto-city"
                value={cityId}
                onChange={(e) => setCityId(e.target.value)}
                className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
              >
                {MOZAMBIQUE_CITIES.map((city) => (
                  <option key={city.id} value={city.id}>
                    {city.name} · {city.province}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="auto-frequency"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Frequência do resumo
              </label>
              <select
                id="auto-frequency"
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as AutoProspectFrequency)}
                className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
              >
                <option value="weekly">Semanal (resumo a cada semana)</option>
                <option value="daily">Diária</option>
              </select>
            </div>

            {frequency === 'weekly' ? (
              <div>
                <label
                  htmlFor="auto-weekday"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Dia do resumo semanal
                </label>
                <select
                  id="auto-weekday"
                  value={dayOfWeek}
                  onChange={(e) => setDayOfWeek(Number(e.target.value))}
                  className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                >
                  {WEEKDAYS_PT.map((d) => (
                    <option key={d.value} value={d.value}>
                      {d.label}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label
                  htmlFor="auto-email-daily"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  E-mail para resumo (opcional)
                </label>
                <input
                  id="auto-email-daily"
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="exemplo@empresa.co.mz"
                  className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                />
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pt-1">
            <div className="flex-1 flex flex-col sm:flex-row sm:items-center gap-4">
              {frequency === 'weekly' && (
                <div className="sm:w-[280px]">
                  <label
                    htmlFor="auto-email"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    E-mail para envio do resumo semanal (opcional)
                  </label>
                  <input
                    id="auto-email"
                    type="email"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    placeholder="exemplo@empresa.co.mz"
                    className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                  />
                </div>
              )}

              <label className="inline-flex items-center gap-2 text-xs sm:text-sm text-slate-700 cursor-pointer pt-2 sm:pt-5">
                <input
                  type="checkbox"
                  checked={onlyWithoutWebsite}
                  onChange={(e) => setOnlyWithoutWebsite(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600"
                />
                Incluir apenas negócios sem website próprio registado
              </label>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 text-sm font-semibold text-white transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              {isSubmitting ? 'A guardar...' : 'Criar Auto-Prospecção'}
            </button>
          </div>

          {formError && (
            <p role="alert" className="text-xs text-rose-700">
              {formError}
            </p>
          )}
        </form>
      </section>

      {/* Configured Recurring Rules */}
      <section aria-label="Regras configuradas" className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-900">
            Pesquisas recorrentes configuradas ({rules.length})
          </h2>
        </div>

        {isLoading ? (
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <div className="h-5 w-64 bg-slate-200 rounded animate-pulse" />
            <div className="h-4 w-48 bg-slate-100 rounded animate-pulse" />
          </div>
        ) : rules.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white px-6 py-8 text-center shadow-xs">
            <CalendarClock className="w-6 h-6 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-900">
              Nenhuma pesquisa recorrente configurada
            </p>
            <p className="text-xs text-slate-600 max-w-md mx-auto mt-1">
              Crie uma regra acima (por exemplo, &ldquo;restaurantes em Maputo&rdquo;) para
              acompanhar novos negócios sem website automaticamente.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rules.map((rule) => {
              const isRunning = runningRuleId === rule.id;
              const weekdayLabel =
                WEEKDAYS_PT.find((d) => d.value === rule.dayOfWeek)?.label ?? 'Segunda-feira';
              const nextDateStr = new Date(rule.nextRunAt).toLocaleDateString('pt-MZ', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
              });
              const lastDateStr = rule.lastRunAt
                ? new Date(rule.lastRunAt).toLocaleString('pt-MZ', {
                    day: '2-digit',
                    month: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                  })
                : 'Nunca executada';

              return (
                <article
                  key={rule.id}
                  className="p-4 rounded-xl border border-slate-200 bg-white shadow-xs flex flex-col justify-between gap-4"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <h3 className="text-sm font-semibold text-slate-900 truncate">
                          {rule.query} em {rule.city}
                        </h3>
                        <p className="text-xs text-slate-600 mt-0.5">
                          {rule.province} ·{' '}
                          {rule.frequency === 'weekly'
                            ? `Semanal (${weekdayLabel})`
                            : 'Diária'}
                        </p>
                      </div>
                      <span
                        className={`text-xs font-semibold shrink-0 ${
                          rule.isActive ? 'text-emerald-700' : 'text-slate-500'
                        }`}
                      >
                        {rule.isActive ? 'Ativa' : 'Pausada'}
                      </span>
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs text-slate-600">
                      <div>
                        <span className="text-slate-500 block">Última verificação</span>
                        <span className="font-mono tabular-nums text-slate-800">
                          {lastDateStr}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Próxima prevista</span>
                        <span className="font-mono tabular-nums text-slate-800">
                          {nextDateStr}
                        </span>
                      </div>
                    </div>

                    {rule.recipientEmail && (
                      <p className="mt-2 text-xs text-slate-600 truncate">
                        Resumo para: <span className="font-medium text-slate-800">{rule.recipientEmail}</span>
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => void onRunRuleNow(rule)}
                      disabled={isRunning}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                    >
                      <Play className="w-3.5 h-3.5" />
                      {isRunning ? 'A verificar...' : 'Executar agora'}
                    </button>

                    <button
                      type="button"
                      onClick={() => void onToggleRuleActive(rule)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      {rule.isActive ? (
                        <>
                          <Pause className="w-3.5 h-3.5" />
                          Pausar
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5" />
                          Ativar
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => void onDeleteRule(rule.id)}
                      aria-label={`Remover regra ${rule.query} em ${rule.city}`}
                      className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-rose-600 hover:border-rose-300 transition-colors cursor-pointer ml-auto shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Weekly Digests & In-App Notifications */}
      <section aria-label="Notificações e resumos semanais" className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-semibold text-slate-900">
              Notificações e resumos semanais ({digests.length})
            </h2>
            {unreadCount > 0 && (
              <span className="text-xs font-semibold text-emerald-700 tabular-nums">
                · {unreadCount} por ler
              </span>
            )}
          </div>

          {unreadCount > 0 && (
            <button
              type="button"
              onClick={() => void onMarkAllDigestsRead()}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer"
            >
              Marcar todas como lidas
            </button>
          )}
        </div>

        {digests.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white px-6 py-10 text-center shadow-xs">
            <Mail className="w-6 h-6 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-900">
              Ainda não existem resumos gerados
            </p>
            <p className="text-xs text-slate-600 max-w-md mx-auto mt-1">
              Quando uma regra for executada (automaticamente na data prevista ou clicando em
              &ldquo;Executar agora&rdquo;), a notificação com os novos negócios sem website
              aparecerá aqui.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {digests.map((digest) => {
              const createdLabel = new Date(digest.createdAt).toLocaleString('pt-MZ', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });
              const mailBody =
                digest.emailBody.length > 1500
                  ? `${digest.emailBody.slice(0, 1450)}\n\n(...lista completa disponível no painel Minera.ia)`
                  : digest.emailBody;
              const mailtoHref = `mailto:${encodeURIComponent(
                digest.recipientEmail || ''
              )}?subject=${encodeURIComponent(digest.emailSubject)}&body=${encodeURIComponent(
                mailBody
              )}`;

              return (
                <article
                  key={digest.id}
                  className={`p-5 rounded-xl border shadow-xs space-y-4 ${
                    digest.isRead
                      ? 'border-slate-200 bg-white'
                      : 'border-emerald-300 bg-emerald-50/40'
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono tabular-nums">{createdLabel}</span>
                        <span>·</span>
                        <span>{digest.totalScanned} analisados no mapa</span>
                        {!digest.isRead && (
                          <span className="font-semibold text-emerald-700">· Nova notificação</span>
                        )}
                      </div>
                      <h3 className="text-sm sm:text-base font-semibold text-slate-900 mt-1">
                        {digest.emailSubject}
                      </h3>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setGmailDigestTarget(digest)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        <Send className="w-3.5 h-3.5" />
                        Enviar via Gmail
                      </button>

                      <a
                        href={mailtoHref}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors whitespace-nowrap shrink-0"
                      >
                        <Mail className="w-3.5 h-3.5 text-emerald-600" />
                        Abrir no E-mail
                      </a>

                      <button
                        type="button"
                        onClick={() => void handleCopyDigest(digest)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        {copiedDigestId === digest.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            Copiado
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            Copiar resumo
                          </>
                        )}
                      </button>

                      {!digest.isRead && (
                        <button
                          type="button"
                          onClick={() => void onMarkDigestRead(digest.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-white cursor-pointer whitespace-nowrap shrink-0"
                        >
                          Marcar lida
                        </button>
                      )}
                    </div>
                  </div>

                  {digest.leads.length > 0 ? (
                    <div className="divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white overflow-hidden">
                      {digest.leads.map((item) => {
                        const alreadySaved = Boolean(savedPlaceIds[item.placeId]);
                        return (
                          <div
                            key={item.placeId}
                            className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                          >
                            <div className="min-w-0 space-y-0.5">
                              <p className="text-sm font-semibold text-slate-900 truncate">
                                {item.name}
                              </p>
                              <p className="text-slate-600 truncate">{item.address}</p>
                              <p className="text-slate-700 font-mono tabular-nums">
                                {item.whatsappNumber || item.phoneRaw || 'Sem telefone publicado'}
                                {item.hasMobileWhatsApp ? ` · Móvel ${item.carrier}` : ''}
                                {' · '}
                                <span className="font-sans text-emerald-700 font-medium">
                                  {item.websiteStatus === 'social_only'
                                    ? 'Apenas rede social'
                                    : 'Sem website registado'}
                                </span>
                              </p>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                type="button"
                                disabled={alreadySaved}
                                onClick={() =>
                                  void onSaveDigestLead(item, digest.ruleLabel, item.city || 'Maputo')
                                }
                                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                                  alreadySaved
                                    ? 'border-emerald-200 bg-emerald-50 text-emerald-700 cursor-default'
                                    : 'border-slate-300 bg-white hover:bg-slate-50 text-slate-800 cursor-pointer'
                                }`}
                              >
                                {alreadySaved ? (
                                  <>
                                    <Check className="w-3.5 h-3.5" />
                                    Guardado
                                  </>
                                ) : (
                                  <>
                                    <BookmarkPlus className="w-3.5 h-3.5 text-emerald-600" />
                                    Guardar lead
                                  </>
                                )}
                              </button>

                              {item.googleMapsUri && (
                                <a
                                  href={item.googleMapsUri}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 whitespace-nowrap shrink-0"
                                >
                                  Maps
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-600 bg-white border border-slate-200 rounded-lg px-3.5 py-2.5">
                      Nenhum novo negócio sem website foi encontrado em comparação com as
                      execuções anteriores desta regra.
                    </p>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </section>

      <GmailSendConfirmModal
        isOpen={Boolean(gmailDigestTarget)}
        onClose={() => setGmailDigestTarget(null)}
        configuredSenderEmail={senderEmail}
        googleUser={googleUser}
        needsAuth={needsGoogleAuth}
        isLoggingIn={isGoogleLoggingIn}
        onGoogleLogin={onGoogleLogin}
        initialToEmail={gmailDigestTarget?.recipientEmail || senderEmail}
        subject={gmailDigestTarget?.emailSubject || ''}
        bodyText={gmailDigestTarget?.emailBody || ''}
        onSendConfirmed={async (toEmail) => {
          if (!gmailDigestTarget) return;
          await onSendGmail({
            to: toEmail,
            subject: gmailDigestTarget.emailSubject,
            bodyText: gmailDigestTarget.emailBody,
          });
        }}
      />
    </div>
  );
}
