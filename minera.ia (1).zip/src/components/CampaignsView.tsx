import { Compass, RotateCcw } from 'lucide-react';
import type { CampaignRecord } from '../types/leads.ts';

interface CampaignsViewProps {
  campaigns: CampaignRecord[];
  isLoading: boolean;
  onRelaunchCampaign: (campaign: CampaignRecord) => void;
  onGoToRadar: () => void;
}

export function CampaignsView({
  campaigns,
  isLoading,
  onRelaunchCampaign,
  onGoToRadar,
}: CampaignsViewProps) {
  if (isLoading) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-200 shadow-xs">
        {Array.from({ length: 4 }).map((_, idx) => (
          <div key={idx} className="h-14 px-5 flex items-center justify-between">
            <div className="h-4 w-56 bg-slate-200 rounded animate-pulse" />
            <div className="h-4 w-24 bg-slate-100 rounded animate-pulse" />
          </div>
        ))}
      </div>
    );
  }

  if (campaigns.length === 0) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white px-6 py-12 text-center shadow-xs">
        <div className="w-11 h-11 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3">
          <Compass className="w-5 h-5 text-slate-500" />
        </div>
        <h3 className="text-base font-semibold text-slate-900">
          Nenhuma campanha registada ainda
        </h3>
        <p className="text-sm text-slate-600 max-w-md mx-auto mt-1.5 leading-relaxed">
          Cada pesquisa executada em Explorar fica registada aqui com o total de empresas
          encontradas e alvos sem website registado.
        </p>
        <button
          type="button"
          onClick={onGoToRadar}
          className="mt-5 inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 text-sm font-semibold text-white transition-colors cursor-pointer"
        >
          Iniciar primeira pesquisa
        </button>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
              <th className="py-3 pl-5 pr-3">Atividade / Nicho</th>
              <th className="py-3 px-3">Cidade · Província</th>
              <th className="py-3 px-3 text-right">Analisadas</th>
              <th className="py-3 px-3 text-right">Sem website + móvel +258</th>
              <th className="py-3 px-3 text-right">Aproveitamento</th>
              <th className="py-3 px-3 text-right">Data</th>
              <th className="py-3 pl-3 pr-5 text-right">Ação</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 text-xs">
            {campaigns.map((camp) => {
              const rate =
                camp.totalFound > 0
                  ? Math.round((camp.qualifiedCount / camp.totalFound) * 100)
                  : 0;
              const dateText = new Date(camp.createdAt).toLocaleString('pt-MZ', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <tr key={camp.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 pl-5 pr-3 font-semibold text-sm text-slate-900">
                    {camp.niche}
                  </td>
                  <td className="py-3 px-3 text-slate-700">
                    {camp.city} · {camp.province}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                    {camp.totalFound}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700 font-semibold">
                    {camp.qualifiedCount}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                    {rate}%
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-500">
                    {dateText}
                  </td>
                  <td className="py-3 pl-3 pr-5 text-right">
                    <button
                      type="button"
                      onClick={() => onRelaunchCampaign(camp)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />
                      Reabrir no Explorar
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
