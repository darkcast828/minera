import type { User } from 'firebase/auth';
import { AlertTriangle, Loader2, Mail, Send, X } from 'lucide-react';
import { useEffect, useState } from 'react';

interface GmailSendConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  configuredSenderEmail: string;
  googleUser: User | null;
  needsAuth: boolean;
  isLoggingIn: boolean;
  onGoogleLogin: (loginHint?: string) => Promise<void>;
  initialToEmail: string;
  subject: string;
  bodyText: string;
  onSendConfirmed: (toEmail: string) => Promise<void>;
}

export function GmailSendConfirmModal({
  isOpen,
  onClose,
  configuredSenderEmail,
  googleUser,
  needsAuth,
  isLoggingIn,
  onGoogleLogin,
  initialToEmail,
  subject,
  bodyText,
  onSendConfirmed,
}: GmailSendConfirmModalProps) {
  const [toEmail, setToEmail] = useState(initialToEmail);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setToEmail(initialToEmail || configuredSenderEmail);
      setError(null);
      setIsSending(false);
    }
  }, [isOpen, initialToEmail, configuredSenderEmail]);

  if (!isOpen) return null;

  const activeAccountEmail = googleUser?.email || '';
  const accountMatchesConfigured =
    Boolean(activeAccountEmail) &&
    activeAccountEmail.toLowerCase() === configuredSenderEmail.toLowerCase();

  const handleConfirmSend = async () => {
    const cleanTo = toEmail.trim();
    if (!cleanTo || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanTo)) {
      setError('Indique um endereço de e-mail de destino válido.');
      return;
    }
    setError(null);
    setIsSending(true);
    try {
      await onSendConfirmed(cleanTo);
      onClose();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Não foi possível enviar o e-mail pelo Gmail.'
      );
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="gmail-confirm-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-5 shadow-lg space-y-4 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <Mail className="w-4 h-4 text-emerald-700" />
            </div>
            <div>
              <h3 id="gmail-confirm-title" className="text-sm font-semibold text-slate-900">
                Confirmar envio de prospecção por Gmail
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Reveja o remetente, destinatário e conteúdo antes de enviar o e-mail.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar confirmação"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {needsAuth || !googleUser ? (
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 space-y-3">
            <p className="text-xs text-slate-700 leading-relaxed">
              Inicie sessão com a conta Google{' '}
              <strong className="text-slate-900">{configuredSenderEmail}</strong> para autorizar o
              envio direto através do Gmail.
            </p>
            <button
              type="button"
              onClick={() => void onGoogleLogin(configuredSenderEmail)}
              disabled={isLoggingIn}
              className="gsi-material-button inline-flex items-center gap-3 rounded-md border border-[#747775] bg-white hover:bg-[#f8faff] px-4 py-2 text-sm font-medium text-[#1f1f1f] shadow-xs transition-colors cursor-pointer disabled:opacity-60"
              style={{ fontFamily: 'Roboto, system-ui, sans-serif' }}
            >
              <div className="gsi-material-button-icon w-[18px] h-[18px] shrink-0">
                <svg
                  version="1.1"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 48 48"
                  style={{ display: 'block' }}
                >
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                  <path fill="none" d="M0 0h48v48H0z" />
                </svg>
              </div>
              <span className="gsi-material-button-contents">
                {isLoggingIn ? 'A autenticar...' : 'Sign in with Google'}
              </span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {!accountMatchesConfigured && (
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900 space-y-2">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>
                    Sessão atual: <strong>{activeAccountEmail}</strong>. A conta definida para envio
                    das prospecções é <strong>{configuredSenderEmail}</strong> (definida também
                    como Reply-To).
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => void onGoogleLogin(configuredSenderEmail)}
                  disabled={isLoggingIn}
                  className="text-xs font-semibold text-amber-950 underline hover:text-amber-800 cursor-pointer"
                >
                  {isLoggingIn
                    ? 'A trocar conta...'
                    : `Trocar para ${configuredSenderEmail}`}
                </button>
              </div>
            )}

            <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs space-y-1">
              <div>
                <span className="text-slate-500">Remetente Gmail ativo:</span>{' '}
                <strong className="text-slate-900">{activeAccountEmail}</strong>
              </div>
              <div>
                <span className="text-slate-500">Responder para (Reply-To):</span>{' '}
                <strong className="text-slate-900">{configuredSenderEmail}</strong>
              </div>
            </div>
          </div>
        )}

        <div>
          <label htmlFor="gmail-confirm-to" className="block text-xs font-medium text-slate-700 mb-1">
            Enviar para (destinatário)
          </label>
          <input
            id="gmail-confirm-to"
            type="email"
            value={toEmail}
            onChange={(e) => setToEmail(e.target.value)}
            placeholder={configuredSenderEmail}
            className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
          />
        </div>

        <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-1.5 text-xs">
          <p className="font-semibold text-slate-900">{subject}</p>
          <pre className="whitespace-pre-wrap font-sans text-slate-700 max-h-40 overflow-y-auto leading-relaxed">
            {bodyText}
          </pre>
        </div>

        {error && (
          <p
            role="alert"
            className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2"
          >
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-2.5 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={() => void handleConfirmSend()}
            disabled={isSending || needsAuth || !googleUser}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors cursor-pointer disabled:opacity-50"
          >
            {isSending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            {isSending ? 'A enviar...' : 'Confirmar e enviar via Gmail'}
          </button>
        </div>
      </div>
    </div>
  );
}
