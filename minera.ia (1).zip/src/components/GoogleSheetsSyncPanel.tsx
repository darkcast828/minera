import type { User } from 'firebase/auth';
import {
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  FileSpreadsheet,
  Link2,
  Loader2,
  LogOut,
  Plus,
  RefreshCw,
  Unlink,
} from 'lucide-react';
import { useState } from 'react';
import type { GoogleSheetsConfig, GoogleSheetTabInfo } from '../types/leads.ts';
import { extractSpreadsheetId } from '../utils/googleSheetsService.ts';

type ConfirmActionKind = 'sync_now' | 'enable_realtime';

interface GoogleSheetsSyncPanelProps {
  googleUser: User | null;
  needsAuth: boolean;
  isLoggingIn: boolean;
  authError: string | null;
  config: GoogleSheetsConfig | null;
  availableTabs: GoogleSheetTabInfo[];
  realtimeSessionConfirmed: boolean;
  isSyncing: boolean;
  isConnectingSheet: boolean;
  syncError: string | null;
  savedLeadsCount: number;
  onGoogleLogin: () => Promise<void>;
  onGoogleLogout: () => Promise<void>;
  onCreateSpreadsheet: (title: string) => Promise<boolean>;
  onConnectExistingSpreadsheet: (spreadsheetId: string) => Promise<boolean>;
  onRefreshTabs: () => Promise<void>;
  onChangeTab: (sheetName: string) => Promise<void>;
  onDisconnectSpreadsheet: () => Promise<void>;
  onConfirmSyncNow: () => Promise<void>;
  onConfirmEnableRealtime: () => Promise<void>;
  onDisableRealtime: () => Promise<void>;
}

export function GoogleSheetsSyncPanel({
  googleUser,
  needsAuth,
  isLoggingIn,
  authError,
  config,
  availableTabs,
  realtimeSessionConfirmed,
  isSyncing,
  isConnectingSheet,
  syncError,
  savedLeadsCount,
  onGoogleLogin,
  onGoogleLogout,
  onCreateSpreadsheet,
  onConnectExistingSpreadsheet,
  onRefreshTabs,
  onChangeTab,
  onDisconnectSpreadsheet,
  onConfirmSyncNow,
  onConfirmEnableRealtime,
  onDisableRealtime,
}: GoogleSheetsSyncPanelProps) {
  const [newSheetTitle, setNewSheetTitle] = useState('Minera.ia — Leads Moçambique');
  const [existingUrlInput, setExistingUrlInput] = useState('');
  const [localInputError, setLocalInputError] = useState<string | null>(null);
  const [pendingConfirm, setPendingConfirm] = useState<ConfirmActionKind | null>(null);

  const handleConnectExisting = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalInputError(null);
    const id = extractSpreadsheetId(existingUrlInput);
    if (!id) {
      setLocalInputError(
        'Cole um link válido do Google Sheets (docs.google.com/spreadsheets/d/...) ou o ID da planilha.'
      );
      return;
    }
    const ok = await onConnectExistingSpreadsheet(id);
    if (ok) {
      setExistingUrlInput('');
    }
  };

  const handleCreateNew = async () => {
    setLocalInputError(null);
    const ok = await onCreateSpreadsheet(newSheetTitle);
    if (ok) {
      // Explicit user confirmation required before writing rows to the spreadsheet
      setPendingConfirm('sync_now');
    }
  };

  const handleConfirmModalProceed = async () => {
    const action = pendingConfirm;
    setPendingConfirm(null);
    if (action === 'sync_now') {
      await onConfirmSyncNow();
    } else if (action === 'enable_realtime') {
      await onConfirmEnableRealtime();
    }
  };

  const lastSyncFormatted = config?.lastSyncedAt
    ? new Date(config.lastSyncedAt).toLocaleString('pt-MZ', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : null;

  const tabsToRender: GoogleSheetTabInfo[] =
    availableTabs.length > 0
      ? availableTabs
      : config
      ? [{ sheetId: 0, title: config.sheetName }]
      : [];

  return (
    <>
      <section
        aria-label="Sincronização com Google Sheets"
        className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5 shadow-xs space-y-4"
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-900">
                Sincronização com Google Sheets
              </h2>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Exporte e sincronize os seus {savedLeadsCount} leads guardados diretamente numa
                planilha Google Sheets em tempo real.
              </p>
            </div>
          </div>

          {googleUser && !needsAuth ? (
            <div className="flex items-center gap-2.5 text-xs">
              <span className="text-slate-600">
                Conta Google:{' '}
                <strong className="text-slate-900">
                  {googleUser.email || googleUser.displayName || 'Conectada'}
                </strong>
              </span>
              <button
                type="button"
                onClick={() => void onGoogleLogout()}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-medium cursor-pointer transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sair
              </button>
            </div>
          ) : null}
        </div>

        {(authError || syncError || localInputError) && (
          <div
            role="alert"
            className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-800"
          >
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
            <span>{authError || syncError || localInputError}</span>
          </div>
        )}

        {/* Auth Gate: Official "Sign in with Google" button when token is unavailable */}
        {needsAuth || !googleUser ? (
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1 max-w-xl">
              <p className="text-xs font-semibold text-slate-900">
                {config
                  ? `Planilha "${config.spreadsheetTitle}" ligada — autentique-se para sincronizar`
                  : 'Conecte a sua conta Google para criar ou ligar uma planilha'}
              </p>
              <p className="text-xs text-slate-600">
                A autorização fica ativa apenas nesta sessão no navegador para proteger os seus
                dados no Google Sheets.
              </p>
            </div>

            <button
              type="button"
              onClick={() => void onGoogleLogin()}
              disabled={isLoggingIn}
              className="gsi-material-button inline-flex items-center gap-3 rounded-md border border-[#747775] bg-white hover:bg-[#f8faff] active:bg-[#e8f0fe] px-4 py-2 text-sm font-medium text-[#1f1f1f] shadow-xs transition-colors cursor-pointer disabled:opacity-60 shrink-0"
              style={{ fontFamily: 'Roboto, system-ui, sans-serif' }}
            >
              <div className="gsi-material-button-icon w-[18px] h-[18px] shrink-0">
                <svg
                  version="1.1"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 48 48"
                  style={{ display: 'block' }}
                >
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                  <path fill="none" d="M0 0h48v48H0z" />
                </svg>
              </div>
              <span className="gsi-material-button-contents">
                {isLoggingIn ? 'A autenticar...' : 'Sign in with Google'}
              </span>
            </button>
          </div>
        ) : !config ? (
          /* Authenticated but no spreadsheet selected yet */
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-1">
            <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-4 space-y-3">
              <p className="text-xs font-semibold text-slate-900">
                1. Criar nova planilha automaticamente
              </p>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={newSheetTitle}
                  onChange={(e) => setNewSheetTitle(e.target.value)}
                  placeholder="Nome da planilha"
                  aria-label="Nome da nova planilha Google Sheets"
                  className="flex-1 rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                />
                <button
                  type="button"
                  onClick={() => void handleCreateNew()}
                  disabled={isConnectingSheet}
                  className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  {isConnectingSheet ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Plus className="w-3.5 h-3.5" />
                  )}
                  Criar planilha
                </button>
              </div>
            </div>

            <form
              onSubmit={(e) => void handleConnectExisting(e)}
              className="rounded-lg border border-slate-200 bg-slate-50/60 p-4 space-y-3"
            >
              <p className="text-xs font-semibold text-slate-900">
                2. Ou ligar uma planilha existente
              </p>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={existingUrlInput}
                  onChange={(e) => setExistingUrlInput(e.target.value)}
                  placeholder="Cole o link ou ID do Google Sheets..."
                  aria-label="Link ou ID da planilha Google Sheets"
                  className="flex-1 rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                />
                <button
                  type="submit"
                  disabled={isConnectingSheet || !existingUrlInput.trim()}
                  className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <Link2 className="w-3.5 h-3.5 text-emerald-600" />
                  Ligar planilha
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Authenticated + Spreadsheet connected */
          <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4 space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-slate-900 truncate">
                    {config.spreadsheetTitle}
                  </span>
                  <a
                    href={config.spreadsheetUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 hover:text-emerald-800 underline"
                  >
                    Abrir no Google Sheets
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                  {isSyncing ? (
                    <span className="inline-flex items-center gap-1.5 text-emerald-700 font-medium">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      A sincronizar {savedLeadsCount} leads...
                    </span>
                  ) : lastSyncFormatted ? (
                    <span className="inline-flex items-center gap-1.5 text-slate-700">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      Última sincronização: {lastSyncFormatted} ({config.lastSyncedCount} leads)
                    </span>
                  ) : (
                    <span>Planilha ligada — pronta para primeira sincronização</span>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <label htmlFor="sheets-tab-select" className="text-xs text-slate-600">
                    Aba:
                  </label>
                  <select
                    id="sheets-tab-select"
                    value={config.sheetName}
                    onChange={(e) => void onChangeTab(e.target.value)}
                    disabled={isSyncing}
                    className="rounded-lg bg-white border border-slate-300 px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-emerald-600"
                  >
                    {tabsToRender.map((tab) => (
                      <option key={`${tab.sheetId}-${tab.title}`} value={tab.title}>
                        {tab.title}
                      </option>
                    ))}
                  </select>
                  {availableTabs.length === 0 && (
                    <button
                      type="button"
                      onClick={() => void onRefreshTabs()}
                      title="Carregar lista de abas da planilha"
                      className="p-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-600 cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => setPendingConfirm('sync_now')}
                  disabled={isSyncing}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  Sincronizar agora ({savedLeadsCount})
                </button>

                <button
                  type="button"
                  onClick={() => void onDisconnectSpreadsheet()}
                  disabled={isSyncing}
                  title="Desligar esta planilha"
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Unlink className="w-3.5 h-3.5" />
                  Desligar
                </button>
              </div>
            </div>

            {/* Real-time auto-sync control */}
            <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-slate-900">
                  Sincronização automática em tempo real
                </p>
                <p className="text-xs text-slate-600">
                  {config.autoSyncEnabled && realtimeSessionConfirmed
                    ? `Ativa nesta sessão — alterações em Leads guardados atualizam "${config.sheetName}" automaticamente.`
                    : config.autoSyncEnabled && !realtimeSessionConfirmed
                    ? 'Ativada nas preferências — confirme para retomar atualizações automáticas nesta sessão.'
                    : 'Quando ativa, cada novo lead guardado, nota ou mudança no funil atualiza a planilha automaticamente.'}
                </p>
              </div>

              {config.autoSyncEnabled && realtimeSessionConfirmed ? (
                <button
                  type="button"
                  onClick={() => void onDisableRealtime()}
                  className="px-3 py-1.5 rounded-lg border border-emerald-600 bg-emerald-50 hover:bg-emerald-100 text-xs font-semibold text-emerald-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Tempo real ativo (Desativar)
                </button>
              ) : config.autoSyncEnabled && !realtimeSessionConfirmed ? (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setPendingConfirm('enable_realtime')}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    Confirmar e retomar tempo real
                  </button>
                  <button
                    type="button"
                    onClick={() => void onDisableRealtime()}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    Desativar
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setPendingConfirm('enable_realtime')}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Ativar tempo real
                </button>
              )}
            </div>
          </div>
        )}
      </section>

      {/* Explicit Confirmation Modal before modifying Google Sheets data */}
      {pendingConfirm && config && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="sheets-confirm-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4"
          onClick={() => setPendingConfirm(null)}
        >
          <div
            className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-5 shadow-lg space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center shrink-0">
                <FileSpreadsheet className="w-4 h-4 text-amber-700" />
              </div>
              <div>
                <h3 id="sheets-confirm-title" className="text-sm font-semibold text-slate-900">
                  {pendingConfirm === 'enable_realtime'
                    ? 'Confirmar sincronização em tempo real'
                    : 'Confirmar atualização no Google Sheets'}
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {pendingConfirm === 'enable_realtime'
                    ? `Ao confirmar, a aba "${config.sheetName}" da planilha "${config.spreadsheetTitle}" será atualizada agora com ${savedLeadsCount} lead(s) guardado(s) e sempre que guardar, editar ou remover contactos durante esta sessão.`
                    : `Esta ação irá substituir o conteúdo das colunas A até R na aba "${config.sheetName}" da planilha "${config.spreadsheetTitle}" pelos ${savedLeadsCount} lead(s) atualmente guardados no Minera.ia.`}
                </p>
              </div>
            </div>

            <div className="rounded-lg bg-slate-50 border border-slate-200 px-3 py-2.5 text-xs text-slate-700 space-y-1">
              <div>
                <span className="text-slate-500">Planilha:</span>{' '}
                <strong className="text-slate-900">{config.spreadsheetTitle}</strong>
              </div>
              <div>
                <span className="text-slate-500">Aba de destino:</span>{' '}
                <strong className="text-slate-900">{config.sheetName}</strong>
              </div>
              <div>
                <span className="text-slate-500">Registos a exportar:</span>{' '}
                <strong className="text-slate-900">{savedLeadsCount} leads</strong>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setPendingConfirm(null)}
                className="px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => void handleConfirmModalProceed()}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors cursor-pointer"
              >
                {pendingConfirm === 'enable_realtime'
                  ? 'Confirmar e ativar tempo real'
                  : 'Confirmar sincronização'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
