import type { User } from 'firebase/auth';
import {
  ArrowLeft,
  BookmarkCheck,
  BookmarkPlus,
  CalendarClock,
  Check,
  Copy,
  ExternalLink,
  Globe,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  RefreshCw,
  RotateCcw,
  Search,
  Send,
  Star,
  Trash2,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { PIPELINE_STATUS_LABELS } from '../data/mozambique.ts';
import type {
  LeadRecord,
  PipelineStatus,
  WebSearchGroundingResult,
} from '../types/leads.ts';
import {
  buildOutreachTemplateByNiche,
  buildWebWhatsAppUrl,
} from '../utils/whatsappTemplates.ts';
import { GmailSendConfirmModal } from './GmailSendConfirmModal.tsx';

interface LeadDetailDrawerProps {
  lead: LeadRecord | null;
  onClose: () => void;
  onSaveLead: (lead: LeadRecord) => Promise<void>;
  onUpdateLead: (
    placeId: string,
    updates: { pipelineStatus?: PipelineStatus; notes?: string }
  ) => Promise<void>;
  onDeleteLead?: (placeId: string) => Promise<void>;
  onRefreshFromMaps?: (placeId: string) => Promise<void>;
  onScoreSingleLead?: (lead: LeadRecord) => Promise<void>;
  isScoring?: boolean;
  isRefreshing?: boolean;
  backLabel?: string;
  senderEmail?: string;
  googleUser?: User | null;
  needsGoogleAuth?: boolean;
  isGoogleLoggingIn?: boolean;
  onGoogleLogin?: (loginHint?: string) => Promise<void>;
  onSendGmail?: (params: { to: string; subject: string; bodyText: string }) => Promise<void>;
}

export function LeadDetailDrawer({
  lead,
  onClose,
  onSaveLead,
  onUpdateLead,
  onDeleteLead,
  onRefreshFromMaps,
  onScoreSingleLead,
  isScoring = false,
  isRefreshing = false,
  backLabel,
  senderEmail = 'scottnaftal@gmail.com',
  googleUser = null,
  needsGoogleAuth = true,
  isGoogleLoggingIn = false,
  onGoogleLogin,
  onSendGmail,
}: LeadDetailDrawerProps) {
  const [notes, setNotes] = useState('');
  const [savingNotes, setSavingNotes] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  const [schedulerOpen, setSchedulerOpen] = useState(false);
  const [scheduledAt, setScheduledAt] = useState('');
  const [draftMessage, setDraftMessage] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [scheduleSavedNotice, setScheduleSavedNotice] = useState(false);
  const [crmError, setCrmError] = useState<string | null>(null);

  const [webChecksByPlaceId, setWebChecksByPlaceId] = useState<
    Record<string, WebSearchGroundingResult>
  >({});
  const [isCheckingWeb, setIsCheckingWeb] = useState(false);
  const [webCheckError, setWebCheckError] = useState<string | null>(null);

  const [emailComposerOpen, setEmailComposerOpen] = useState(false);
  const [emailRecipient, setEmailRecipient] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');
  const [gmailConfirmOpen, setGmailConfirmOpen] = useState(false);
  const [emailSentNotice, setEmailSentNotice] = useState(false);

  const templateInfo = useMemo(() => {
    if (!lead) return { nicheLabel: '', message: '' };
    return buildOutreachTemplateByNiche(lead);
  }, [lead]);

  useEffect(() => {
    setNotes(lead?.notes ?? '');
    setSavedNotice(false);
    setSchedulerOpen(false);
    setScheduledAt('');
    setCopiedLink(false);
    setScheduleSavedNotice(false);
    setCrmError(null);
    setWebCheckError(null);
    setEmailComposerOpen(false);
    setGmailConfirmOpen(false);
    setEmailSentNotice(false);
    const tpl = lead ? buildOutreachTemplateByNiche(lead).message : '';
    setDraftMessage(tpl);
    setEmailRecipient('');
    setEmailSubject(
      lead ? `Proposta de presença digital para ${lead.name} (${lead.city})` : ''
    );
    setEmailBody(
      lead ? `${tpl}\n\nCumprimentos,\n${senderEmail}` : ''
    );
  }, [lead?.placeId, senderEmail]);

  if (!lead) return null;

  const currentWebCheck = webChecksByPlaceId[lead.placeId] ?? null;

  const handleRunWebSearchCheck = async () => {
    setIsCheckingWeb(true);
    setWebCheckError(null);
    try {
      const res = await fetch('/api/ai/web-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: lead.name,
          niche: lead.primaryType || lead.niche,
          city: lead.city,
          province: lead.province,
          address: lead.address,
          phoneRaw: lead.phoneRaw,
          websiteStatus: lead.websiteStatus,
          websiteUrl: lead.websiteUrl,
        }),
      });
      const data = (await res.json()) as Partial<WebSearchGroundingResult> & { error?: string };
      if (!res.ok || !data.summary) {
        throw new Error(data.error || 'Falha ao consultar a Pesquisa Google.');
      }
      setWebChecksByPlaceId((prev) => ({
        ...prev,
        [lead.placeId]: {
          summary: data.summary!,
          sources: Array.isArray(data.sources) ? data.sources : [],
          searchQueries: Array.isArray(data.searchQueries) ? data.searchQueries : [],
          checkedAt: data.checkedAt || new Date().toISOString(),
        },
      }));
    } catch (err) {
      setWebCheckError(
        err instanceof Error
          ? err.message
          : 'Não foi possível concluir a verificação na Pesquisa Google.'
      );
    } finally {
      setIsCheckingWeb(false);
    }
  };

  const websiteLabel =
    lead.websiteStatus === 'none'
      ? 'Sem website registado na fonte de dados'
      : lead.websiteStatus === 'social_only'
      ? 'Apenas rede social (sem website próprio)'
      : 'Possui website próprio registado';

  const phoneDescription = lead.hasMobileWhatsApp
    ? `Telefone publicado em formato móvel moçambicano (${lead.carrier}) — elegível para WhatsApp (não confirmado externamente)`
    : lead.carrier === 'Fixo'
    ? 'Telefone fixo publicado'
    : lead.phoneRaw
    ? 'Telefone publicado'
    : 'Sem telefone publicado na ficha';

  const webWhatsAppUrl =
    lead.waDigits && draftMessage.trim().length > 0
      ? buildWebWhatsAppUrl(lead.waDigits, draftMessage)
      : lead.waDigits
      ? buildWebWhatsAppUrl(lead.waDigits, templateInfo.message)
      : null;

  const handleSaveNotes = async () => {
    setSavingNotes(true);
    setCrmError(null);
    try {
      if (lead.isSaved) {
        await onUpdateLead(lead.placeId, { notes });
      } else {
        await onSaveLead({ ...lead, notes });
      }
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 1800);
    } catch (err) {
      setCrmError(
        err instanceof Error ? err.message : 'Não foi possível guardar a nota no servidor.'
      );
    } finally {
      setSavingNotes(false);
    }
  };

  const handleOpenScheduler = () => {
    if (!draftMessage.trim()) {
      setDraftMessage(templateInfo.message);
    }
    setSchedulerOpen((prev) => !prev);
  };

  const handleCopyWebLink = async () => {
    if (!webWhatsAppUrl) return;
    try {
      await navigator.clipboard.writeText(webWhatsAppUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 1800);
    } catch {
      // Clipboard fallback
    }
  };

  const handleConfirmSchedule = async () => {
    if (!webWhatsAppUrl) return;
    setSavingSchedule(true);
    setCrmError(null);
    try {
      const scheduleStamp = scheduledAt
        ? new Date(scheduledAt).toLocaleString('pt-MZ', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          })
        : 'Envio imediato';
      const logEntry = `[WhatsApp Agendado · ${scheduleStamp}]\nLink: ${webWhatsAppUrl}`;
      const nextNotes = notes.trim() ? `${notes.trim()}\n\n${logEntry}` : logEntry;
      setNotes(nextNotes);

      const nextStatus: PipelineStatus =
        lead.pipelineStatus === 'novo' ? 'em_analise' : lead.pipelineStatus;

      if (lead.isSaved) {
        await onUpdateLead(lead.placeId, {
          notes: nextNotes,
          pipelineStatus: nextStatus,
        });
      } else {
        await onSaveLead({
          ...lead,
          notes: nextNotes,
          pipelineStatus: nextStatus,
        });
      }
      setScheduleSavedNotice(true);
      setTimeout(() => setScheduleSavedNotice(false), 2000);
    } catch (err) {
      setCrmError(
        err instanceof Error
          ? err.message
          : 'Não foi possível registar o agendamento no CRM.'
      );
    } finally {
      setSavingSchedule(false);
    }
  };

  return (
    <aside
      aria-label="Detalhes do negócio"
      className="w-full bg-white border border-slate-200 rounded-xl flex flex-col overflow-hidden shadow-xs"
    >
      <div className="flex items-start justify-between gap-3 px-5 py-4 border-b border-slate-200 bg-slate-50/70">
        <div className="min-w-0">
          {backLabel && (
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 hover:text-emerald-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 rounded mb-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              {backLabel}
            </button>
          )}
          <p className="text-xs text-slate-600 truncate">
            {lead.primaryType || lead.niche} · {lead.city}, {lead.province}
          </p>
          <h3 className="text-base font-semibold text-slate-900 mt-0.5 leading-snug">
            {lead.name}
          </h3>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Fechar detalhes"
          className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-200/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 transition-colors cursor-pointer shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-5 space-y-5 overflow-y-auto flex-1">
        {/* Contact & Digital Presence */}
        <div className="space-y-3.5 text-sm">
          <div className="flex items-start gap-3">
            <Phone className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-500">Telefone publicado</p>
              <p className="font-mono tabular-nums text-sm font-medium text-slate-900 mt-0.5">
                {lead.whatsappNumber || lead.phoneRaw || 'Sem telefone publicado'}
              </p>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                {phoneDescription}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Globe className="w-4 h-4 text-slate-500 mt-0.5 shrink-0" />
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-500">Estado do website</p>
              <p
                className={`text-sm font-medium mt-0.5 ${
                  lead.websiteStatus === 'has_website'
                    ? 'text-slate-700'
                    : 'text-emerald-700'
                }`}
              >
                {websiteLabel}
              </p>
              {lead.websiteUrl && (
                <a
                  href={lead.websiteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-slate-600 hover:text-slate-900 underline break-all inline-flex items-center gap-1 mt-0.5"
                >
                  {lead.websiteUrl}
                  <ExternalLink className="w-3 h-3 shrink-0" />
                </a>
              )}
            </div>
          </div>

          <div className="flex items-start gap-3">
            <MapPin className="w-4 h-4 text-slate-500 mt-0.5 shrink-0" />
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-500">Localização</p>
              <p className="text-xs text-slate-700 mt-0.5 leading-relaxed">
                {lead.address || `${lead.city}, Moçambique`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Star className="w-4 h-4 text-amber-500 shrink-0" />
            <div className="text-xs text-slate-700 tabular-nums font-mono">
              {lead.rating !== null ? `${lead.rating.toFixed(1)} ★` : 'Sem avaliação'} ·{' '}
              {lead.reviewCount} avaliações no Google Maps
            </div>
          </div>
        </div>

        {/* Opportunity Score Block */}
        <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
          <div className="flex items-center justify-between gap-3">
            <span className="text-xs font-medium text-slate-600">
              Score de Oportunidade IA
            </span>
            {lead.opportunityScore !== null ? (
              <span
                className={`font-mono tabular-nums text-base font-semibold ${
                  lead.opportunityScore >= 75
                    ? 'text-emerald-700'
                    : lead.opportunityScore >= 50
                    ? 'text-amber-700'
                    : 'text-slate-600'
                }`}
              >
                {lead.opportunityScore}/100
              </span>
            ) : (
              <span className="text-xs text-slate-500">Não avaliado</span>
            )}
          </div>

          {lead.scoreRationale ? (
            <p className="text-xs text-slate-700 mt-1.5 leading-relaxed">
              {lead.scoreRationale}
            </p>
          ) : (
            <p className="text-xs text-slate-500 mt-1.5">
              Calcule o score IA para estimar a prioridade comercial deste negócio.
            </p>
          )}

          {onScoreSingleLead && (
            <button
              type="button"
              onClick={() => onScoreSingleLead(lead)}
              disabled={isScoring}
              className="mt-2.5 text-xs font-semibold text-emerald-700 hover:text-emerald-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 rounded transition-colors cursor-pointer disabled:opacity-50"
            >
              {isScoring
                ? 'A calcular score com IA...'
                : lead.opportunityScore !== null
                ? 'Recalcular score IA'
                : 'Calcular score IA'}
            </button>
          )}
        </div>

        {/* Google Search Grounding: Live Web Presence Verification */}
        <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-xs font-semibold text-slate-800">
                Pesquisa Google (Presença na Web)
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                Confirma resultados indexados, redes sociais ou websites públicos
              </p>
            </div>
            <button
              type="button"
              onClick={() => void handleRunWebSearchCheck()}
              disabled={isCheckingWeb}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 text-xs font-semibold text-slate-800 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <Search className="w-3.5 h-3.5 text-emerald-600" />
              {isCheckingWeb
                ? 'A pesquisar...'
                : currentWebCheck
                ? 'Atualizar busca'
                : 'Verificar no Google'}
            </button>
          </div>

          {webCheckError && (
            <p role="alert" className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-md px-3 py-2">
              {webCheckError}
            </p>
          )}

          {currentWebCheck && (
            <div className="pt-2 border-t border-slate-200 space-y-2.5">
              <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                {currentWebCheck.summary}
              </div>

              {currentWebCheck.sources.length > 0 && (
                <div className="space-y-1">
                  <p className="text-xs font-medium text-slate-600">
                    Fontes encontradas na Pesquisa Google:
                  </p>
                  <ul className="space-y-1">
                    {currentWebCheck.sources.map((src) => (
                      <li key={src.uri} className="truncate">
                        <a
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-emerald-700 hover:text-emerald-800 underline max-w-full truncate"
                        >
                          <ExternalLink className="w-3 h-3 shrink-0" />
                          <span className="truncate">{src.title}</span>
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {currentWebCheck.sources.length === 0 && (
                <p className="text-xs text-slate-500">
                  Nenhuma página web externa listada nas fontes desta pesquisa.
                </p>
              )}
            </div>
          )}
        </div>

        {/* Qualified Lead: Schedule & Personalized Web WhatsApp Outreach */}
        {lead.isQualifiedTarget && lead.waDigits && (
          <div className="p-4 rounded-lg bg-emerald-50/70 border border-emerald-200 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-slate-900">
                  Abordagem · {templateInfo.nicheLabel}
                </p>
                <p className="text-xs text-slate-600 mt-0.5">
                  Modelo personalizado para Web WhatsApp
                </p>
              </div>
              <button
                type="button"
                onClick={handleOpenScheduler}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 text-xs font-semibold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <CalendarClock className="w-3.5 h-3.5" />
                Agendar Mensagem
              </button>
            </div>

            {schedulerOpen && webWhatsAppUrl && (
              <div className="pt-3 border-t border-emerald-200 space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label
                      htmlFor="outreach-message-draft"
                      className="text-xs font-medium text-slate-700"
                    >
                      Mensagem personalizada para o nicho
                    </label>
                    <button
                      type="button"
                      onClick={() => setDraftMessage(templateInfo.message)}
                      className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      Repor modelo
                    </button>
                  </div>
                  <textarea
                    id="outreach-message-draft"
                    rows={6}
                    value={draftMessage}
                    onChange={(e) => setDraftMessage(e.target.value)}
                    className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 leading-relaxed focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 resize-y"
                  />
                </div>

                <div>
                  <label
                    htmlFor="outreach-schedule-time"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    Data e hora prevista de envio (opcional)
                  </label>
                  <input
                    id="outreach-schedule-time"
                    type="datetime-local"
                    value={scheduledAt}
                    onChange={(e) => setScheduledAt(e.target.value)}
                    className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                  />
                </div>

                <div className="rounded-lg bg-white border border-slate-200 p-3 space-y-2">
                  <p className="text-xs font-medium text-slate-600">
                    Link pré-preenchido (Web WhatsApp)
                  </p>
                  <p className="text-xs font-mono text-emerald-700 break-all line-clamp-2">
                    {webWhatsAppUrl}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <a
                      href={webWhatsAppUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Abrir Web WhatsApp
                    </a>
                    <button
                      type="button"
                      onClick={() => void handleCopyWebLink()}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      {copiedLink ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          Copiado
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          Copiar link
                        </>
                      )}
                    </button>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => void handleConfirmSchedule()}
                  disabled={savingSchedule}
                  className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-emerald-600 bg-white hover:bg-emerald-50 text-xs font-semibold text-emerald-700 transition-colors cursor-pointer disabled:opacity-50"
                >
                  {scheduleSavedNotice ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      Agendamento registado nas notas e CRM
                    </>
                  ) : savingSchedule ? (
                    'A guardar agendamento...'
                  ) : (
                    'Registar agendamento no CRM'
                  )}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Gmail Prospecting Email Dispatch */}
        {onSendGmail && (
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-slate-900">
                  Prospecção por E-mail (Gmail)
                </p>
                <p className="text-xs text-slate-600 mt-0.5 truncate">
                  Envio configurado: <strong className="text-slate-800">{senderEmail}</strong>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEmailComposerOpen((prev) => !prev)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Mail className="w-3.5 h-3.5 text-emerald-600" />
                {emailComposerOpen ? 'Fechar rascunho' : 'Enviar E-mail'}
              </button>
            </div>

            {emailSentNotice && (
              <p className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700">
                <Check className="w-3.5 h-3.5" />
                Prospecção enviada por Gmail e registada no CRM.
              </p>
            )}

            {emailComposerOpen && (
              <div className="pt-3 border-t border-slate-200 space-y-2.5">
                <div>
                  <label
                    htmlFor="lead-gmail-to"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    E-mail de destino (contacto da empresa ou sua caixa)
                  </label>
                  <input
                    id="lead-gmail-to"
                    type="email"
                    value={emailRecipient}
                    onChange={(e) => setEmailRecipient(e.target.value)}
                    placeholder={`contacto@empresa.co.mz ou ${senderEmail}`}
                    className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label
                    htmlFor="lead-gmail-subject"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    Assunto
                  </label>
                  <input
                    id="lead-gmail-subject"
                    type="text"
                    value={emailSubject}
                    onChange={(e) => setEmailSubject(e.target.value)}
                    className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label
                    htmlFor="lead-gmail-body"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    Mensagem
                  </label>
                  <textarea
                    id="lead-gmail-body"
                    rows={5}
                    value={emailBody}
                    onChange={(e) => setEmailBody(e.target.value)}
                    className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 leading-relaxed focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 resize-y"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => setGmailConfirmOpen(true)}
                  className="w-full inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  Preparar envio via Gmail
                </button>
              </div>
            )}
          </div>
        )}

        {/* CRM Pipeline Status */}
        <div className="pt-4 border-t border-slate-200 space-y-3">
          <div>
            <label
              htmlFor="pipeline-status-select"
              className="block text-xs font-medium text-slate-700 mb-1.5"
            >
              Estado no Funil
            </label>
            <select
              id="pipeline-status-select"
              value={lead.pipelineStatus}
              onChange={(e) => {
                const nextStatus = e.target.value as PipelineStatus;
                setCrmError(null);
                const run = lead.isSaved
                  ? onUpdateLead(lead.placeId, { pipelineStatus: nextStatus })
                  : onSaveLead({ ...lead, pipelineStatus: nextStatus });
                void run.catch((err) => {
                  setCrmError(
                    err instanceof Error
                      ? err.message
                      : 'Não foi possível atualizar o estado no funil.'
                  );
                });
              }}
              className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
            >
              {(Object.keys(PIPELINE_STATUS_LABELS) as PipelineStatus[]).map((statusKey) => (
                <option key={statusKey} value={statusKey}>
                  {PIPELINE_STATUS_LABELS[statusKey]}
                </option>
              ))}
            </select>
            {crmError && (
              <p
                role="alert"
                className="mt-2 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-md px-3 py-2"
              >
                {crmError}
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="lead-notes-textarea"
              className="block text-xs font-medium text-slate-700 mb-1.5"
            >
              Notas de Prospecção
            </label>
            <textarea
              id="lead-notes-textarea"
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Registar retorno de chamada, decisor ou interesse em website..."
              className="w-full rounded-lg bg-white border border-slate-300 px-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 resize-none"
            />
            <div className="mt-2 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={handleSaveNotes}
                disabled={savingNotes}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                {savedNotice ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    Guardado
                  </>
                ) : (
                  'Guardar nota'
                )}
              </button>

              {onRefreshFromMaps && lead.isSaved && (
                <button
                  type="button"
                  onClick={() => onRefreshFromMaps(lead.placeId)}
                  disabled={isRefreshing}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                  Atualizar dados Maps
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Footer Actions */}
      <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center gap-2">
        {lead.waDigits ? (
          <a
            href={webWhatsAppUrl ?? `https://wa.me/${lead.waDigits}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0"
          >
            <MessageCircle className="w-4 h-4" />
            Abrir WhatsApp
          </a>
        ) : lead.phoneRaw ? (
          <a
            href={`tel:${lead.phoneRaw.replace(/\s+/g, '')}`}
            className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0"
          >
            <Phone className="w-4 h-4" />
            Ligar para contacto
          </a>
        ) : (
          <span className="flex-1 text-center text-xs text-slate-500 py-2">
            Sem contacto telefónico
          </span>
        )}

        {!lead.isSaved ? (
          <button
            type="button"
            onClick={() => void onSaveLead(lead)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <BookmarkPlus className="w-4 h-4 text-emerald-600" />
            Guardar
          </button>
        ) : (
          <>
            <span className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-medium text-emerald-700">
              <BookmarkCheck className="w-4 h-4" />
              Guardado
            </span>
            {onDeleteLead && (
              <button
                type="button"
                onClick={() => void onDeleteLead(lead.placeId)}
                aria-label="Remover lead"
                className="p-2.5 rounded-lg border border-slate-200 bg-white text-slate-500 hover:text-rose-600 hover:border-rose-300 transition-colors cursor-pointer shrink-0"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </>
        )}

        {lead.googleMapsUri && (
          <a
            href={lead.googleMapsUri}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Abrir no Google Maps"
            title="Ver ficha no Google Maps"
            className="p-2.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors shrink-0"
          >
            <ExternalLink className="w-4 h-4" />
          </a>
        )}
      </div>

      {onSendGmail && onGoogleLogin && (
        <GmailSendConfirmModal
          isOpen={gmailConfirmOpen}
          onClose={() => setGmailConfirmOpen(false)}
          configuredSenderEmail={senderEmail}
          googleUser={googleUser}
          needsAuth={needsGoogleAuth}
          isLoggingIn={isGoogleLoggingIn}
          onGoogleLogin={onGoogleLogin}
          initialToEmail={emailRecipient.trim() || senderEmail}
          subject={emailSubject}
          bodyText={emailBody}
          onSendConfirmed={async (toEmail) => {
            await onSendGmail({
              to: toEmail,
              subject: emailSubject,
              bodyText: emailBody,
            });
            const sentStamp = new Date().toLocaleString('pt-MZ', {
              day: '2-digit',
              month: '2-digit',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            });
            const entry = `[E-mail Gmail Enviado · ${sentStamp}]\nPara: ${toEmail}\nDe/Reply-To: ${senderEmail}\nAssunto: ${emailSubject}`;
            const nextNotes = notes.trim() ? `${notes.trim()}\n\n${entry}` : entry;
            setNotes(nextNotes);
            const nextStatus: PipelineStatus =
              lead.pipelineStatus === 'novo' || lead.pipelineStatus === 'em_analise'
                ? 'contactado'
                : lead.pipelineStatus;
            if (lead.isSaved) {
              await onUpdateLead(lead.placeId, {
                notes: nextNotes,
                pipelineStatus: nextStatus,
              });
            } else {
              await onSaveLead({
                ...lead,
                notes: nextNotes,
                pipelineStatus: nextStatus,
              });
            }
            setEmailSentNotice(true);
            setEmailComposerOpen(false);
            setTimeout(() => setEmailSentNotice(false), 3000);
          }}
        />
      )}
    </aside>
  );
}
