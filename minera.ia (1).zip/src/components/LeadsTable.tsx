import {
  ArrowUpDown,
  BookmarkCheck,
  BookmarkPlus,
  ExternalLink,
  MessageCircle,
  Phone,
  Search,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import { PIPELINE_STATUS_LABELS } from '../data/mozambique.ts';
import type { LeadRecord } from '../types/leads.ts';

type SortField = 'score' | 'reviews' | 'rating' | 'name';

interface LeadsTableProps {
  leads: LeadRecord[];
  selectedLeadId: string | null;
  onSelectLead: (placeId: string) => void;
  onSaveLead?: (lead: LeadRecord) => Promise<void>;
  isLoading: boolean;
  emptyTitle?: string;
  emptyDescription?: string;
  onEmptyAction?: () => void;
  emptyActionLabel?: string;
  showPipelineColumn?: boolean;
}

export function LeadsTable({
  leads,
  selectedLeadId,
  onSelectLead,
  onSaveLead,
  isLoading,
  emptyTitle = 'Nenhum negócio encontrado para os filtros selecionados',
  emptyDescription = 'Selecione um nicho e uma cidade em Moçambique para pesquisar empresas no mapa.',
  onEmptyAction,
  emptyActionLabel = 'Pesquisar em Maputo',
  showPipelineColumn = false,
}: LeadsTableProps) {
  const [sortField, setSortField] = useState<SortField>('score');
  const [sortAsc, setSortAsc] = useState(false);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc((prev) => !prev);
    } else {
      setSortField(field);
      setSortAsc(field === 'name');
    }
  };

  const sortedLeads = useMemo(() => {
    const copy = [...leads];
    copy.sort((a, b) => {
      let diff = 0;
      if (sortField === 'score') {
        diff = (a.opportunityScore ?? -1) - (b.opportunityScore ?? -1);
      } else if (sortField === 'reviews') {
        diff = a.reviewCount - b.reviewCount;
      } else if (sortField === 'rating') {
        diff = (a.rating ?? 0) - (b.rating ?? 0);
      } else {
        diff = a.name.localeCompare(b.name, 'pt');
      }
      return sortAsc ? diff : -diff;
    });
    return copy;
  }, [leads, sortField, sortAsc]);

  if (isLoading) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
        <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="h-4 w-44 bg-slate-200 rounded animate-pulse" />
          <div className="h-4 w-28 bg-slate-200 rounded animate-pulse" />
        </div>
        <div className="divide-y divide-slate-200">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div key={idx} className="h-[52px] px-4 flex items-center gap-4">
              <div className="h-3.5 w-48 bg-slate-200 rounded animate-pulse" />
              <div className="h-3.5 w-32 bg-slate-100 rounded animate-pulse" />
              <div className="h-3.5 w-24 bg-slate-100 rounded ml-auto animate-pulse" />
              <div className="h-3.5 w-14 bg-slate-200 rounded animate-pulse" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (leads.length === 0) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white px-6 py-12 text-center shadow-xs">
        <div className="w-11 h-11 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3">
          <Search className="w-5 h-5 text-slate-500" />
        </div>
        <h3 className="text-base font-semibold text-slate-900">{emptyTitle}</h3>
        <p className="text-sm text-slate-600 max-w-md mx-auto mt-1.5 leading-relaxed">
          {emptyDescription}
        </p>
        {onEmptyAction && (
          <button
            type="button"
            onClick={onEmptyAction}
            className="mt-5 inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 text-sm font-semibold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            {emptyActionLabel}
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
              <th className="py-3 pl-4 pr-3">
                <button
                  type="button"
                  onClick={() => toggleSort('name')}
                  className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer whitespace-nowrap"
                >
                  Empresa
                  <ArrowUpDown className="w-3.5 h-3.5" />
                </button>
              </th>
              <th className="py-3 px-3 whitespace-nowrap">Telefone publicado</th>
              <th className="py-3 px-3 whitespace-nowrap">Website</th>
              <th className="py-3 px-3 text-right">
                <button
                  type="button"
                  onClick={() => toggleSort('reviews')}
                  className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer whitespace-nowrap ml-auto"
                >
                  Avaliações
                  <ArrowUpDown className="w-3.5 h-3.5" />
                </button>
              </th>
              <th className="py-3 px-3 text-right">
                <button
                  type="button"
                  onClick={() => toggleSort('score')}
                  className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer whitespace-nowrap ml-auto"
                >
                  Score IA
                  <ArrowUpDown className="w-3.5 h-3.5" />
                </button>
              </th>
              {showPipelineColumn && (
                <th className="py-3 px-3 whitespace-nowrap">Estado no funil</th>
              )}
              <th className="py-3 pl-3 pr-4 text-right whitespace-nowrap">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 text-xs">
            {sortedLeads.map((lead) => {
              const isSelected = lead.placeId === selectedLeadId;
              const websiteLabel =
                lead.websiteStatus === 'none'
                  ? 'Sem website registado'
                  : lead.websiteStatus === 'social_only'
                  ? 'Apenas rede social'
                  : 'Com website';

              return (
                <tr
                  key={lead.placeId}
                  onClick={() => onSelectLead(lead.placeId)}
                  className={`transition-colors cursor-pointer ${
                    isSelected ? 'bg-emerald-50/70' : 'hover:bg-slate-50'
                  }`}
                >
                  <td className="py-3 pl-4 pr-3 max-w-[260px]">
                    <div className="font-semibold text-sm text-slate-900 truncate">
                      {lead.name}
                    </div>
                    <div className="text-xs text-slate-600 truncate mt-0.5">
                      {lead.primaryType || lead.niche} · {lead.city}
                    </div>
                  </td>

                  <td className="py-3 px-3 whitespace-nowrap">
                    {lead.whatsappNumber ? (
                      <div>
                        <span className="font-mono tabular-nums text-slate-900 font-medium">
                          {lead.whatsappNumber}
                        </span>
                        <span className="block text-xs text-emerald-700 mt-0.5">
                          Móvel {lead.carrier} · elegível WhatsApp
                        </span>
                      </div>
                    ) : lead.phoneRaw ? (
                      <div>
                        <span className="font-mono tabular-nums text-slate-800">
                          {lead.phoneRaw}
                        </span>
                        <span className="block text-xs text-slate-500 mt-0.5">
                          {lead.carrier === 'Fixo' ? 'Telefone fixo' : 'Telefone publicado'}
                        </span>
                      </div>
                    ) : (
                      <span className="text-slate-500">Sem telefone publicado</span>
                    )}
                  </td>

                  <td className="py-3 px-3 whitespace-nowrap">
                    <span
                      className={
                        lead.websiteStatus === 'has_website'
                          ? 'text-slate-600'
                          : lead.websiteStatus === 'social_only'
                          ? 'text-amber-700 font-medium'
                          : 'text-emerald-700 font-medium'
                      }
                    >
                      {websiteLabel}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap text-slate-700">
                    {lead.rating !== null ? `${lead.rating.toFixed(1)} ★` : '—'}{' '}
                    <span className="text-slate-500">({lead.reviewCount})</span>
                  </td>

                  <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                    {lead.opportunityScore !== null ? (
                      <span
                        className={`font-semibold ${
                          lead.opportunityScore >= 75
                            ? 'text-emerald-700'
                            : lead.opportunityScore >= 50
                            ? 'text-amber-700'
                            : 'text-slate-600'
                        }`}
                      >
                        {lead.opportunityScore}
                      </span>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </td>

                  {showPipelineColumn && (
                    <td className="py-3 px-3 whitespace-nowrap text-slate-700 font-medium">
                      {PIPELINE_STATUS_LABELS[lead.pipelineStatus]}
                    </td>
                  )}

                  <td
                    className="py-3 pl-3 pr-4 text-right whitespace-nowrap"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="inline-flex items-center gap-1.5">
                      {lead.waDigits ? (
                        <a
                          href={`https://wa.me/${lead.waDigits}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          title="Abrir no Web WhatsApp"
                          aria-label={`Abrir WhatsApp de ${lead.name}`}
                          className="p-2 rounded-lg text-emerald-700 hover:bg-emerald-50 transition-colors"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </a>
                      ) : lead.phoneRaw ? (
                        <a
                          href={`tel:${lead.phoneRaw.replace(/\s+/g, '')}`}
                          title="Ligar para telefone publicado"
                          aria-label={`Ligar para ${lead.name}`}
                          className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                        >
                          <Phone className="w-4 h-4" />
                        </a>
                      ) : null}

                      {onSaveLead && (
                        <button
                          type="button"
                          onClick={() => void onSaveLead(lead)}
                          disabled={lead.isSaved}
                          title={lead.isSaved ? 'Lead guardado' : 'Guardar lead'}
                          aria-label={lead.isSaved ? 'Lead já guardado' : `Guardar ${lead.name}`}
                          className={`p-2 rounded-lg transition-colors cursor-pointer ${
                            lead.isSaved
                              ? 'text-emerald-700 cursor-default'
                              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                          }`}
                        >
                          {lead.isSaved ? (
                            <BookmarkCheck className="w-4 h-4" />
                          ) : (
                            <BookmarkPlus className="w-4 h-4" />
                          )}
                        </button>
                      )}

                      {lead.googleMapsUri && (
                        <a
                          href={lead.googleMapsUri}
                          target="_blank"
                          rel="noopener noreferrer"
                          title="Ver ficha no Google Maps"
                          aria-label={`Ver ${lead.name} no Google Maps`}
                          className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
