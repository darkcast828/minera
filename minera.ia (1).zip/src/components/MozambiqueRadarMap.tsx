import {
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
  useMap,
} from '@vis.gl/react-google-maps';
import { Compass, ExternalLink, MessageCircle, Search } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import type { LeadRecord } from '../types/leads.ts';

interface MozambiqueRadarMapProps {
  center: { lat: number; lng: number };
  zoom: number;
  leads: LeadRecord[];
  selectedLeadId: string | null;
  onSelectLead: (placeId: string | null) => void;
  onSearchBounds: (bounds: google.maps.LatLngBoundsLiteral, center: { lat: number; lng: number }) => void;
  isMining: boolean;
}

function getMarkerPalette(lead: LeadRecord, isSelected: boolean) {
  if (isSelected) {
    return {
      background: '#047857',
      borderColor: '#022C22',
      glyphColor: '#FFFFFF',
    };
  }
  if (lead.isQualifiedTarget) {
    return {
      background: '#16A34A',
      borderColor: '#14532D',
      glyphColor: '#FFFFFF',
    };
  }
  if (lead.websiteStatus !== 'has_website') {
    return {
      background: '#D97706',
      borderColor: '#78350F',
      glyphColor: '#FFFFFF',
    };
  }
  return {
    background: '#64748B',
    borderColor: '#334155',
    glyphColor: '#FFFFFF',
  };
}

interface LeadMarkerItemProps {
  lead: LeadRecord;
  isSelected: boolean;
  onSelect: (placeId: string) => void;
  onCloseInfo: () => void;
}

function LeadMarkerItem({ lead, isSelected, onSelect, onCloseInfo }: LeadMarkerItemProps) {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const palette = getMarkerPalette(lead, isSelected);

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: lead.lat, lng: lead.lng }}
        title={lead.name}
        zIndex={isSelected ? 50 : lead.isQualifiedTarget ? 20 : 5}
        onClick={() => onSelect(lead.placeId)}
      >
        <Pin
          background={palette.background}
          borderColor={palette.borderColor}
          glyphColor={palette.glyphColor}
          scale={isSelected ? 1.2 : lead.isQualifiedTarget ? 1.0 : 0.85}
        />
      </AdvancedMarker>

      {isSelected && marker && (
        <InfoWindow anchor={marker} onCloseClick={onCloseInfo}>
          <div className="min-w-[220px] max-w-[270px] bg-white text-slate-900 p-1">
            <p className="text-sm font-semibold text-slate-900 leading-snug">{lead.name}</p>
            <p className="text-xs text-slate-600 mt-0.5 truncate">
              {lead.primaryType || lead.niche} · {lead.city}
            </p>
            <div className="mt-2 pt-2 border-t border-slate-200 flex items-center justify-between gap-2 text-xs">
              <span className="font-mono tabular-nums text-slate-800">
                {lead.whatsappNumber || lead.phoneRaw || 'Sem telefone publicado'}
              </span>
              {lead.opportunityScore !== null && (
                <span className="font-mono tabular-nums text-emerald-700 font-semibold">
                  Score {lead.opportunityScore}
                </span>
              )}
            </div>
            <div className="mt-2 flex items-center gap-3">
              {lead.waDigits && (
                <a
                  href={`https://wa.me/${lead.waDigits}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  WhatsApp
                </a>
              )}
              {lead.googleMapsUri && (
                <a
                  href={lead.googleMapsUri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 ml-auto"
                >
                  Google Maps
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          </div>
        </InfoWindow>
      )}
    </>
  );
}

function MapViewportSync({
  center,
  zoom,
  selectedLead,
  onViewportMoved,
}: {
  center: { lat: number; lng: number };
  zoom: number;
  selectedLead: LeadRecord | null;
  onViewportMoved: () => void;
}) {
  const map = useMap();

  useEffect(() => {
    if (!map) return;
    map.panTo({ lat: center.lat, lng: center.lng });
    map.setZoom(zoom);
  }, [map, center.lat, center.lng, zoom]);

  useEffect(() => {
    if (!map || !selectedLead) return;
    map.panTo({ lat: selectedLead.lat, lng: selectedLead.lng });
  }, [map, selectedLead]);

  useEffect(() => {
    if (!map) return;
    const listener = map.addListener('dragend', () => {
      onViewportMoved();
    });
    return () => listener.remove();
  }, [map, onViewportMoved]);

  return null;
}

function SearchThisAreaOverlay({
  visible,
  isMining,
  onTrigger,
}: {
  visible: boolean;
  isMining: boolean;
  onTrigger: (bounds: google.maps.LatLngBoundsLiteral, center: { lat: number; lng: number }) => void;
}) {
  const map = useMap();

  const handleClick = useCallback(() => {
    if (!map) return;
    const bounds = map.getBounds();
    const c = map.getCenter();
    if (!bounds || !c) return;
    onTrigger(bounds.toJSON(), { lat: c.lat(), lng: c.lng() });
  }, [map, onTrigger]);

  if (!visible) return null;

  return (
    <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10">
      <button
        type="button"
        onClick={handleClick}
        disabled={isMining}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-slate-300 text-xs font-semibold text-slate-900 shadow-md hover:bg-slate-50 hover:border-emerald-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
      >
        <Search className="w-3.5 h-3.5 text-emerald-600" />
        {isMining ? 'A pesquisar área...' : 'Pesquisar nesta área'}
      </button>
    </div>
  );
}

export function MozambiqueRadarMap({
  center,
  zoom,
  leads,
  selectedLeadId,
  onSelectLead,
  onSearchBounds,
  isMining,
}: MozambiqueRadarMapProps) {
  const [hasPanned, setHasPanned] = useState(false);

  useEffect(() => {
    setHasPanned(false);
  }, [center.lat, center.lng]);

  const selectedLead = leads.find((l) => l.placeId === selectedLeadId) ?? null;

  return (
    <div className="relative w-full h-[360px] lg:h-[580px] rounded-xl overflow-hidden border border-slate-200 bg-white shadow-xs">
      <GoogleMap
        defaultCenter={center}
        defaultZoom={zoom}
        mapId="DEMO_MAP_ID"
        colorScheme="LIGHT"
        gestureHandling="greedy"
        disableDefaultUI={false}
        streetViewControl={false}
        mapTypeControl={false}
        clickableIcons={false}
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        className="w-full h-full"
        onClick={() => onSelectLead(null)}
      >
        <MapViewportSync
          center={center}
          zoom={zoom}
          selectedLead={selectedLead}
          onViewportMoved={() => setHasPanned(true)}
        />

        <SearchThisAreaOverlay
          visible={hasPanned}
          isMining={isMining}
          onTrigger={(bounds, c) => {
            setHasPanned(false);
            onSearchBounds(bounds, c);
          }}
        />

        {leads.map((lead) => (
          <LeadMarkerItem
            key={lead.placeId}
            lead={lead}
            isSelected={lead.placeId === selectedLeadId}
            onSelect={(id) => onSelectLead(id)}
            onCloseInfo={() => onSelectLead(null)}
          />
        ))}
      </GoogleMap>

      {/* Clean light legend anchored at bottom-left */}
      <div className="absolute bottom-3 left-3 z-10 flex flex-wrap items-center gap-3 px-3 py-1.5 rounded-lg bg-white/95 border border-slate-200 shadow-xs text-xs text-slate-700 pointer-events-none">
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" />
          Sem website + móvel +258
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-600 inline-block" />
          Sem website
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-500 inline-block" />
          Com website
        </span>
      </div>

      {!hasPanned && leads.length === 0 && (
        <div className="hidden sm:inline-flex absolute bottom-3 right-3 z-10 items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/95 border border-slate-200 text-xs text-slate-600 pointer-events-none">
          <Compass className="w-3.5 h-3.5 text-emerald-600" />
          Moçambique
        </div>
      )}
    </div>
  );
}
