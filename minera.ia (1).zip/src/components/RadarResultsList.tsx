import {
  BookmarkCheck,
  BookmarkPlus,
  ChevronRight,
  ExternalLink,
  Globe,
  MapPin,
  MessageCircle,
  Phone,
  Search,
} from 'lucide-react';
import type { LeadRecord } from '../types/leads.ts';

interface RadarResultsListProps {
  leads: LeadRecord[];
  totalUnfilteredCount: number;
  selectedLeadId: string | null;
  onSelectLead: (placeId: string) => void;
  onSaveLead: (lead: LeadRecord) => Promise<void>;
  isLoading: boolean;
  cityName: string;
  hasSearchedOnce?: boolean;
  onQuickSearch: () => void;
  onResetFilters: () => void;
}

export function RadarResultsList({
  leads,
  totalUnfilteredCount,
  selectedLeadId,
  onSelectLead,
  onSaveLead,
  isLoading,
  cityName,
  hasSearchedOnce = false,
  onQuickSearch,
  onResetFilters,
}: RadarResultsListProps) {
  if (isLoading) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200 overflow-hidden shadow-xs lg:h-[580px]">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200">
          <div className="h-4 w-44 bg-slate-200 rounded animate-pulse" />
        </div>
        {Array.from({ length: 5 }).map((_, idx) => (
          <div key={idx} className="p-4 space-y-2.5">
            <div className="h-4 w-2/3 bg-slate-200 rounded animate-pulse" />
            <div className="h-3.5 w-1/2 bg-slate-100 rounded animate-pulse" />
            <div className="h-3.5 w-3/4 bg-slate-100 rounded animate-pulse" />
          </div>
        ))}
      </div>
    );
  }

  if (leads.length === 0) {
    const hasHiddenResults = totalUnfilteredCount > 0;
    const isEmptyAfterSearch = hasSearchedOnce && totalUnfilteredCount === 0;
    return (
      <div className="bg-white border border-slate-200 rounded-xl px-6 py-12 text-center shadow-xs lg:h-[580px] flex flex-col items-center justify-center">
        <div className="w-11 h-11 rounded-full bg-slate-100 flex items-center justify-center mb-3">
          <Search className="w-5 h-5 text-slate-500" />
        </div>
        <h3 className="text-base font-semibold text-slate-900">
          {hasHiddenResults
            ? 'Nenhum resultado com os filtros atuais'
            : isEmptyAfterSearch
            ? `Nenhum negócio encontrado em ${cityName}`
            : `Pesquise negócios em ${cityName}`}
        </h3>
        <p className="text-sm text-slate-600 max-w-sm mx-auto mt-1.5 leading-relaxed">
          {hasHiddenResults
            ? `Existem ${totalUnfilteredCount} negócios carregados nesta área, mas os filtros selecionados ocultaram todos.`
            : isEmptyAfterSearch
            ? 'Tente pesquisar com outro termo de actividade, alargar o zoom no mapa ou selecionar outra cidade de Moçambique.'
            : 'Escolha um nicho ou digite uma actividade e clique em Pesquisar no mapa para localizar negócios.'}
        </p>
        <button
          type="button"
          onClick={hasHiddenResults ? onResetFilters : onQuickSearch}
          className="mt-5 inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 text-sm font-semibold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          {hasHiddenResults
            ? 'Limpar filtros'
            : isEmptyAfterSearch
            ? `Pesquisar novamente em ${cityName}`
            : `Pesquisar em ${cityName}`}
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl flex flex-col overflow-hidden shadow-xs lg:h-[580px]">
      <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-2 shrink-0">
        <h2 className="text-sm font-semibold text-slate-900">
          Resultados ({leads.length})
        </h2>
        <span className="text-xs text-slate-600 tabular-nums">
          Ordenados por oportunidade
        </span>
      </div>

      <div className="divide-y divide-slate-200 overflow-y-auto flex-1">
        {leads.map((lead) => {
          const isSelected = lead.placeId === selectedLeadId;
          const websiteText =
            lead.websiteStatus === 'none'
              ? 'Sem website registado'
              : lead.websiteStatus === 'social_only'
              ? 'Apenas rede social'
              : 'Website registado';

          const phoneStatusText = lead.hasMobileWhatsApp
            ? `Móvel ${lead.carrier} · elegível WhatsApp`
            : lead.carrier === 'Fixo'
            ? 'Telefone fixo'
            : lead.phoneRaw
            ? 'Telefone publicado'
            : 'Sem telefone publicado';

          return (
            <article
              key={lead.placeId}
              onClick={() => onSelectLead(lead.placeId)}
              className={`p-4 transition-colors cursor-pointer ${
                isSelected ? 'bg-emerald-50/60' : 'hover:bg-slate-50'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="text-sm font-semibold text-slate-900 leading-snug">
                    {lead.name}
                  </h3>
                  <p className="text-xs text-slate-600 mt-0.5 truncate">
                    {lead.primaryType || lead.niche}
                  </p>
                </div>

                {lead.opportunityScore !== null && (
                  <span
                    className={`font-mono tabular-nums text-xs font-semibold shrink-0 ${
                      lead.opportunityScore >= 75
                        ? 'text-emerald-700'
                        : lead.opportunityScore >= 50
                        ? 'text-amber-700'
                        : 'text-slate-600'
                    }`}
                  >
                    Score {lead.opportunityScore}
                  </span>
                )}
              </div>

              <div className="mt-2.5 space-y-1.5 text-xs">
                <div className="flex items-start gap-2 text-slate-600">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                  <span className="line-clamp-1">{lead.address}</span>
                </div>

                <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span className="inline-flex items-center gap-1.5 text-slate-800 font-mono tabular-nums">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    {lead.whatsappNumber || lead.phoneRaw || 'Sem telefone'}
                  </span>
                  <span className="text-slate-500">· {phoneStatusText}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span
                    className={
                      lead.websiteStatus === 'has_website'
                        ? 'text-slate-600'
                        : lead.websiteStatus === 'social_only'
                        ? 'text-amber-700 font-medium'
                        : 'text-emerald-700 font-medium'
                    }
                  >
                    {websiteText}
                  </span>
                </div>
              </div>

              <div
                className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  type="button"
                  onClick={() => void onSaveLead(lead)}
                  disabled={lead.isSaved}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    lead.isSaved
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-700 cursor-default'
                      : 'border-slate-300 bg-white hover:bg-slate-50 text-slate-800 cursor-pointer'
                  }`}
                >
                  {lead.isSaved ? (
                    <>
                      <BookmarkCheck className="w-3.5 h-3.5" />
                      Guardado
                    </>
                  ) : (
                    <>
                      <BookmarkPlus className="w-3.5 h-3.5 text-emerald-600" />
                      Guardar
                    </>
                  )}
                </button>

                {lead.waDigits ? (
                  <a
                    href={`https://wa.me/${lead.waDigits}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    Abrir WhatsApp
                  </a>
                ) : lead.phoneRaw ? (
                  <a
                    href={`tel:${lead.phoneRaw.replace(/\s+/g, '')}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-800 transition-colors whitespace-nowrap shrink-0"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    Ligar
                  </a>
                ) : null}

                {lead.googleMapsUri && (
                  <a
                    href={lead.googleMapsUri}
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Abrir no Google Maps"
                    aria-label={`Abrir ${lead.name} no Google Maps`}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors ml-auto whitespace-nowrap shrink-0"
                  >
                    Maps
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}

                <button
                  type="button"
                  onClick={() => onSelectLead(lead.placeId)}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Detalhes
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
