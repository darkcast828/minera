import type { User } from 'firebase/auth';
import { Download, Search, Sparkles } from 'lucide-react';
import { useMemo, useState } from 'react';
import { MOZAMBIQUE_CITIES, PIPELINE_STATUS_LABELS } from '../data/mozambique.ts';
import type {
  GoogleSheetsConfig,
  GoogleSheetTabInfo,
  LeadRecord,
  PipelineStatus,
} from '../types/leads.ts';
import { GoogleSheetsSyncPanel } from './GoogleSheetsSyncPanel.tsx';
import { LeadDetailDrawer } from './LeadDetailDrawer.tsx';
import { LeadsTable } from './LeadsTable.tsx';

interface SavedLeadsViewProps {
  leads: LeadRecord[];
  isLoading: boolean;
  isScoring: boolean;
  onUpdateLead: (
    placeId: string,
    updates: { pipelineStatus?: PipelineStatus; notes?: string }
  ) => Promise<void>;
  onDeleteLead: (placeId: string) => Promise<void>;
  onScoreLeads: (leads: LeadRecord[]) => Promise<void>;
  onRefreshFromMaps: (placeId: string) => Promise<void>;
  onSwitchToRadar: () => void;
  isRefreshingId: string | null;
  googleSheetsProps: {
    googleUser: User | null;
    needsAuth: boolean;
    isLoggingIn: boolean;
    authError: string | null;
    config: GoogleSheetsConfig | null;
    availableTabs: GoogleSheetTabInfo[];
    realtimeSessionConfirmed: boolean;
    isSyncing: boolean;
    isConnectingSheet: boolean;
    syncError: string | null;
    onGoogleLogin: () => Promise<void>;
    onGoogleLogout: () => Promise<void>;
    onCreateSpreadsheet: (title: string) => Promise<boolean>;
    onConnectExistingSpreadsheet: (spreadsheetId: string) => Promise<boolean>;
    onRefreshTabs: () => Promise<void>;
    onChangeTab: (sheetName: string) => Promise<void>;
    onDisconnectSpreadsheet: () => Promise<void>;
    onConfirmSyncNow: () => Promise<void>;
    onConfirmEnableRealtime: () => Promise<void>;
    onDisableRealtime: () => Promise<void>;
  };
  gmailOutreachProps?: {
    senderEmail: string;
    googleUser: User | null;
    needsGoogleAuth: boolean;
    isGoogleLoggingIn: boolean;
    onGoogleLogin: (loginHint?: string) => Promise<void>;
    onSendGmail: (params: { to: string; subject: string; bodyText: string }) => Promise<void>;
  };
}

export function SavedLeadsView({
  leads,
  isLoading,
  isScoring,
  onUpdateLead,
  onDeleteLead,
  onScoreLeads,
  onRefreshFromMaps,
  onSwitchToRadar,
  isRefreshingId,
  googleSheetsProps,
  gmailOutreachProps,
}: SavedLeadsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [cityFilter, setCityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | PipelineStatus>('all');
  const [qualifiedOnly, setQualifiedOnly] = useState(false);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);

  const filteredLeads = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return leads.filter((lead) => {
      if (cityFilter !== 'all' && lead.city !== cityFilter) return false;
      if (statusFilter !== 'all' && lead.pipelineStatus !== statusFilter) return false;
      if (qualifiedOnly && !lead.isQualifiedTarget) return false;
      if (q) {
        const hay = `${lead.name} ${lead.niche} ${lead.address} ${lead.whatsappNumber ?? ''} ${lead.phoneRaw ?? ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [leads, searchQuery, cityFilter, statusFilter, qualifiedOnly]);

  const selectedLead =
    filteredLeads.find((l) => l.placeId === selectedLeadId) ??
    leads.find((l) => l.placeId === selectedLeadId) ??
    null;

  const unscoredVisible = filteredLeads.filter((l) => l.opportunityScore === null);

  const exportUrl = useMemo(() => {
    const params = new URLSearchParams();
    if (statusFilter !== 'all') params.set('status', statusFilter);
    if (cityFilter !== 'all') params.set('city', cityFilter);
    if (qualifiedOnly) params.set('qualifiedOnly', 'true');
    if (searchQuery.trim()) params.set('search', searchQuery.trim());
    return `/api/leads/export?${params.toString()}`;
  }, [statusFilter, cityFilter, qualifiedOnly, searchQuery]);

  return (
    <div className="space-y-4">
      <GoogleSheetsSyncPanel
        {...googleSheetsProps}
        savedLeadsCount={leads.length}
      />

      {/* Filter Toolbar */}
      <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-xs flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filtrar por empresa, nicho, endereço ou telefone..."
            className="w-full rounded-lg bg-white border border-slate-300 pl-9 pr-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
          />
        </div>

        <select
          aria-label="Filtrar por cidade"
          value={cityFilter}
          onChange={(e) => setCityFilter(e.target.value)}
          className="rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
        >
          <option value="all">Todas as cidades</option>
          {MOZAMBIQUE_CITIES.map((c) => (
            <option key={c.id} value={c.name}>
              {c.name} ({c.province})
            </option>
          ))}
        </select>

        <select
          aria-label="Filtrar por estado no funil"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as 'all' | PipelineStatus)}
          className="rounded-lg bg-white border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
        >
          <option value="all">Todos os estados</option>
          {(Object.keys(PIPELINE_STATUS_LABELS) as PipelineStatus[]).map((key) => (
            <option key={key} value={key}>
              {PIPELINE_STATUS_LABELS[key]}
            </option>
          ))}
        </select>

        <button
          type="button"
          onClick={() => setQualifiedOnly((prev) => !prev)}
          className={`px-3.5 py-2 rounded-lg border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            qualifiedOnly
              ? 'bg-emerald-50 border-emerald-600 text-emerald-800'
              : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
          }`}
        >
          Sem website + móvel +258
        </button>

        {unscoredVisible.length > 0 && (
          <button
            type="button"
            onClick={() => void onScoreLeads(unscoredVisible.slice(0, 20))}
            disabled={isScoring}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            {isScoring ? 'A pontuar...' : `Pontuar ${Math.min(20, unscoredVisible.length)} com IA`}
          </button>
        )}

        {filteredLeads.length === 0 ? (
          <button
            type="button"
            disabled
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-200 text-xs font-semibold text-slate-500 cursor-not-allowed whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            Exportar CSV (0)
          </button>
        ) : (
          <a
            href={exportUrl}
            download="minera-ia-leads-mocambique.csv"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            Exportar CSV ({filteredLeads.length})
          </a>
        )}
      </div>

      {/* Main Grid + Detail Drawer */}
      <div className="flex flex-col lg:flex-row gap-5 items-start">
        <div className="flex-1 min-w-0 w-full">
          <LeadsTable
            leads={filteredLeads}
            selectedLeadId={selectedLeadId}
            onSelectLead={(id) => setSelectedLeadId(id)}
            isLoading={isLoading}
            showPipelineColumn
            emptyTitle="Sem leads guardados nesta seleção"
            emptyDescription="Pesquise empresas no separador Explorar e guarde os contactos para acompanhar o seu funil comercial."
            onEmptyAction={onSwitchToRadar}
            emptyActionLabel="Ir para Explorar"
          />
        </div>

        {selectedLead && (
          <div className="w-full lg:w-[400px] shrink-0">
            <LeadDetailDrawer
              lead={selectedLead}
              onClose={() => setSelectedLeadId(null)}
              onSaveLead={async () => {}}
              onUpdateLead={onUpdateLead}
              onDeleteLead={async (placeId) => {
                await onDeleteLead(placeId);
                setSelectedLeadId(null);
              }}
              onRefreshFromMaps={onRefreshFromMaps}
              onScoreSingleLead={(lead) => onScoreLeads([lead])}
              isScoring={isScoring}
              isRefreshing={isRefreshingId === selectedLead.placeId}
              senderEmail={gmailOutreachProps?.senderEmail}
              googleUser={gmailOutreachProps?.googleUser}
              needsGoogleAuth={gmailOutreachProps?.needsGoogleAuth}
              isGoogleLoggingIn={gmailOutreachProps?.isGoogleLoggingIn}
              onGoogleLogin={gmailOutreachProps?.onGoogleLogin}
              onSendGmail={gmailOutreachProps?.onSendGmail}
            />
          </div>
        )}
      </div>
    </div>
  );
}
