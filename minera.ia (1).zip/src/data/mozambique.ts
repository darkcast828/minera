export interface MozambiqueCity {
  id: string;
  name: string;
  province: string;
  lat: number;
  lng: number;
  zoom: number;
}

export interface NichePreset {
  id: string;
  label: string;
  query: string;
  includedType?: string;
}

export const MOZAMBIQUE_CITIES: MozambiqueCity[] = [
  { id: 'maputo', name: 'Maputo', province: 'Cidade de Maputo', lat: -25.9692, lng: 32.5732, zoom: 13 },
  { id: 'matola', name: 'Matola', province: 'Maputo Província', lat: -25.9622, lng: 32.4589, zoom: 13 },
  { id: 'beira', name: 'Beira', province: 'Sofala', lat: -19.8436, lng: 34.8389, zoom: 13 },
  { id: 'nampula', name: 'Nampula', province: 'Nampula', lat: -15.1165, lng: 39.2666, zoom: 13 },
  { id: 'nacala', name: 'Nacala', province: 'Nampula', lat: -14.5626, lng: 40.6854, zoom: 13 },
  { id: 'chimoio', name: 'Chimoio', province: 'Manica', lat: -19.1164, lng: 33.4833, zoom: 13 },
  { id: 'tete', name: 'Tete', province: 'Tete', lat: -16.1564, lng: 33.5867, zoom: 13 },
  { id: 'quelimane', name: 'Quelimane', province: 'Zambézia', lat: -17.8786, lng: 36.8883, zoom: 13 },
  { id: 'pemba', name: 'Pemba', province: 'Cabo Delgado', lat: -12.974, lng: 40.5178, zoom: 13 },
  { id: 'xai-xai', name: 'Xai-Xai', province: 'Gaza', lat: -25.0519, lng: 33.6442, zoom: 13 },
  { id: 'inhambane', name: 'Inhambane', province: 'Inhambane', lat: -23.865, lng: 35.3833, zoom: 13 },
  { id: 'lichinga', name: 'Lichinga', province: 'Niassa', lat: -13.3128, lng: 35.2406, zoom: 13 },
];

export const MOZAMBIQUE_PROVINCES: string[] = Array.from(
  new Set(MOZAMBIQUE_CITIES.map((c) => c.province))
);

export const NICHE_PRESETS: NichePreset[] = [
  { id: 'saude', label: 'Saúde', query: 'clínica médica saúde', includedType: 'medical_clinic' },
  { id: 'clinicas_farmacias', label: 'Clínicas e Farmácias', query: 'clínica dentária farmácia', includedType: 'pharmacy' },
  { id: 'restaurantes', label: 'Restaurantes', query: 'restaurante', includedType: 'restaurant' },
  { id: 'beleza', label: 'Beleza', query: 'salão de beleza barbearia', includedType: 'beauty_salon' },
  { id: 'oficinas', label: 'Oficinas', query: 'oficina mecânica auto', includedType: 'car_repair' },
  { id: 'hotelaria', label: 'Hotelaria', query: 'hotel pousada lodge', includedType: 'lodging' },
  { id: 'construcao', label: 'Construção', query: 'construção civil materiais', includedType: 'hardware_store' },
  { id: 'imobiliarias', label: 'Imobiliárias', query: 'imobiliária', includedType: 'real_estate_agency' },
  { id: 'educacao', label: 'Educação', query: 'escola centro de formação', includedType: 'school' },
];

export const PIPELINE_STATUS_LABELS: Record<
  'novo' | 'em_analise' | 'contactado' | 'convertido' | 'descartado',
  string
> = {
  novo: 'Novo',
  em_analise: 'Em Análise',
  contactado: 'Contactado',
  convertido: 'Convertido',
  descartado: 'Descartado',
};
