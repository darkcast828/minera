import { GoogleGenAI, Type } from '@google/genai';
import type { AiScoreRequestItem, AiScoreResultItem } from '../types/leads.ts';

const SYSTEM_INSTRUCTION = `Você é o motor de pontuação comercial do Minera.ia, especializado no mercado de Moçambique (Maputo, Matola, Beira, Nampula, Chimoio, Tete, Quelimane, Pemba e demais províncias).
Sua única função é avaliar leads empresariais reais e calcular uma pontuação objetiva de oportunidade comercial (0 a 100) para venda de criação de websites e presença digital.

Critérios de pontuação:
- 85 a 100: Negócio ativo e validado (muitas avaliações/reviews e boa nota), SEM website próprio registado (websiteStatus = "none" ou "social_only"), e com telefone publicado em formato móvel moçambicano +258 82-87 (hasMobileWhatsApp = true).
- 65 a 84: Negócio sem website registado e com número móvel +258 publicado, mas com menos avaliações ou nicho de menor ticket médio; ou negócio forte com apenas página de rede social.
- 35 a 64: Negócio sem website registado porém sem número móvel +258 publicado (ex.: telefone fixo ou ausente), dificultando abordagem direta.
- 0 a 34: Empresa que já possui website próprio (websiteStatus = "has_website") ou está temporariamente/permanentemente fechada.

Regras:
- Responda estritamente no schema JSON solicitado.
- A justificação (scoreRationale) deve ser objetiva, em português europeu/moçambicano natural, com no máximo 140 caracteres, explicando os factos observados (ex.: "48 avaliações (4.6★), móvel Vodacom (+258) publicado e sem website registado.").
- Nunca afirme que o número tem WhatsApp confirmado sem validação externa; refira apenas telefone publicado ou número móvel (+258) elegível para WhatsApp.
- Nunca invente métricas que não estejam nos dados de entrada.`;

export async function scoreLeadsWithGemini(
  items: AiScoreRequestItem[]
): Promise<AiScoreResultItem[]> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY não configurada no servidor. Configure a chave nas definições de Secrets do projeto.'
    );
  }

  if (items.length === 0) {
    return [];
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const payload = items.slice(0, 25).map((item) => ({
    placeId: item.placeId,
    name: item.name,
    niche: item.niche,
    city: item.city,
    province: item.province,
    rating: item.rating,
    reviewCount: item.reviewCount,
    websiteStatus: item.websiteStatus,
    hasMobileWhatsApp: item.hasMobileWhatsApp,
    carrier: item.carrier,
    businessStatus: item.businessStatus || 'OPERATIONAL',
  }));

  let response;
  try {
    response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Avalie a oportunidade comercial destes ${payload.length} estabelecimentos em Moçambique:\n${JSON.stringify(payload)}`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              placeId: {
                type: Type.STRING,
                description: 'O identificador exacto placeId do estabelecimento.',
              },
              opportunityScore: {
                type: Type.INTEGER,
                description: 'Pontuação inteira de 0 a 100 da oportunidade comercial.',
              },
              scoreRationale: {
                type: Type.STRING,
                description: 'Resumo objetivo em até 140 caracteres explicando a pontuação.',
              },
            },
            required: ['placeId', 'opportunityScore', 'scoreRationale'],
          },
        },
      },
    });
  } catch (err) {
    const raw = err instanceof Error ? err.message : String(err);
    if (raw.includes('429') || raw.includes('RESOURCE_EXHAUSTED')) {
      throw new Error(
        'Limite de cota da API Gemini atingido (429). Tente novamente em breve ou verifique o plano em Settings > Secrets.'
      );
    }
    if (raw.includes('403') || raw.includes('PERMISSION_DENIED') || raw.includes('API_KEY_INVALID')) {
      throw new Error(
        'Chave da API Gemini inválida ou sem permissão. Verifique Settings > Secrets.'
      );
    }
    throw new Error('Não foi possível calcular a pontuação IA neste momento.');
  }

  const text = (response.text ?? '[]').trim();
  const parsed = JSON.parse(text) as Array<{
    placeId?: unknown;
    opportunityScore?: unknown;
    scoreRationale?: unknown;
  }>;

  if (!Array.isArray(parsed)) {
    throw new Error('Resposta inesperada do motor de pontuação IA.');
  }

  return parsed
    .filter((entry) => typeof entry.placeId === 'string')
    .map((entry) => ({
      placeId: String(entry.placeId),
      opportunityScore: Math.max(
        0,
        Math.min(100, Math.round(Number(entry.opportunityScore) || 0))
      ),
      scoreRationale:
        typeof entry.scoreRationale === 'string' && entry.scoreRationale.trim().length > 0
          ? entry.scoreRationale.trim().slice(0, 220)
          : 'Pontuação calculada com base na presença digital e contacto.',
    }));
}
