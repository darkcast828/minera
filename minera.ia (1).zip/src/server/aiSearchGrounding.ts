import { GoogleGenAI } from '@google/genai';
import type { WebSearchGroundingResult, WebSearchSource } from '../types/leads.ts';

export interface WebSearchCheckInput {
  name: string;
  niche?: string;
  city: string;
  province?: string;
  address?: string;
  phoneRaw?: string | null;
  websiteStatus?: string;
  websiteUrl?: string | null;
}

const SEARCH_SYSTEM_INSTRUCTION = `Você é o analista de presença digital do Minera.ia para empresas em Moçambique.
Use a ferramenta de Pesquisa Google (Google Search) para verificar informações públicas recentes sobre a empresa indicada.
Regras estritas:
- Responda em português claro, objetivo e direto (máximo 120 palavras, em 3 tópicos curtos).
- Indique apenas factos observados nos resultados da Pesquisa Google:
  1. Presença web encontrada: indique se encontrou website próprio ativo (e qual o domínio), apenas redes sociais (Facebook, Instagram, LinkedIn), listagens em diretórios moçambicanos, ou nenhum website próprio indexado.
  2. Atividade e serviços: resumo breve dos serviços/produtos mencionados publicamente na web.
  3. Contactos públicos encontrados na web (se houver menção pública relevante).
- Nunca invente URLs, telefones ou afirmações que não constem nos resultados pesquisados.
- Não afirme que um número tem WhatsApp confirmado sem prova explícita na fonte pesquisada.`;

export async function verifyBusinessWebPresenceWithSearch(
  input: WebSearchCheckInput
): Promise<WebSearchGroundingResult> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY não configurada no servidor. Configure a chave nas definições de Secrets do projeto.'
    );
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const prompt = [
    `Pesquise no Google sobre a empresa "${input.name}" localizada em ${input.city}${
      input.province ? `, ${input.province}` : ''
    }, Moçambique.`,
    input.niche ? `Atividade / nicho: ${input.niche}.` : '',
    input.address ? `Endereço registado no mapa: ${input.address}.` : '',
    input.websiteUrl
      ? `URL registado no mapa: ${input.websiteUrl}.`
      : 'No Google Maps não consta website próprio registado.',
    'Verifique se a empresa tem website próprio indexado no Google, páginas sociais ou menções recentes relevantes para prospecção B2B.',
  ]
    .filter(Boolean)
    .join('\n');

  let response;
  try {
    response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: prompt,
      config: {
        systemInstruction: SEARCH_SYSTEM_INSTRUCTION,
        tools: [{ googleSearch: {} }],
      },
    });
  } catch (err) {
    const raw = err instanceof Error ? err.message : String(err);
    if (raw.includes('429') || raw.includes('RESOURCE_EXHAUSTED')) {
      throw new Error(
        'Limite de cota da API Gemini atingido (429). Tente novamente em breve ou selecione uma chave com faturação em Settings > Secrets.'
      );
    }
    if (raw.includes('403') || raw.includes('PERMISSION_DENIED') || raw.includes('API_KEY_INVALID')) {
      throw new Error(
        'Chave da API Gemini inválida ou sem permissão. Verifique a configuração em Settings > Secrets.'
      );
    }
    throw new Error('Não foi possível consultar a Pesquisa Google neste momento.');
  }

  const summary =
    (response.text ?? '').trim() ||
    'Não foi possível obter resumo da pesquisa Google para este estabelecimento.';

  const metadata = response.candidates?.[0]?.groundingMetadata;
  const rawChunks = metadata?.groundingChunks ?? [];

  const seenUris = new Set<string>();
  const sources: WebSearchSource[] = [];
  for (const chunk of rawChunks) {
    const uri = chunk.web?.uri;
    if (typeof uri === 'string' && /^https?:\/\//i.test(uri) && !seenUris.has(uri)) {
      seenUris.add(uri);
      sources.push({
        title: (chunk.web?.title || uri).trim(),
        uri,
      });
    }
  }

  const searchQueries = Array.isArray(metadata?.webSearchQueries)
    ? metadata.webSearchQueries.filter((q): q is string => typeof q === 'string' && q.trim().length > 0)
    : [];

  return {
    summary,
    sources: sources.slice(0, 8),
    searchQueries: searchQueries.slice(0, 5),
    checkedAt: new Date().toISOString(),
  };
}
