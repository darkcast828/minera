import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import type {
  AutoProspectDigest,
  AutoProspectDigestLead,
  AutoProspectFrequency,
  AutoProspectRule,
  CampaignRecord,
  CarrierName,
  GoogleSheetsConfig,
  LeadRecord,
  OutreachSettings,
  PipelineStatus,
  WebsiteStatus,
} from '../types/leads.ts';
import { sanitizeExternalHttpUrl } from '../utils/mozambiqueLeadParser.ts';

const VALID_PIPELINE_STATUSES: ReadonlyArray<PipelineStatus> = [
  'novo',
  'em_analise',
  'contactado',
  'convertido',
  'descartado',
];

const VALID_WEBSITE_STATUSES: ReadonlyArray<WebsiteStatus> = [
  'none',
  'social_only',
  'has_website',
];

const VALID_CARRIERS: ReadonlyArray<CarrierName> = [
  'Vodacom',
  'Movitel',
  'Tmcel',
  'Fixo',
  'Desconhecido',
];

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'minera.db');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS campaigns (
    id TEXT PRIMARY KEY,
    niche TEXT NOT NULL,
    city TEXT NOT NULL,
    province TEXT NOT NULL,
    total_found INTEGER NOT NULL DEFAULT 0,
    qualified_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    place_id TEXT UNIQUE NOT NULL,
    campaign_id TEXT,
    name TEXT NOT NULL,
    niche TEXT NOT NULL,
    primary_type TEXT,
    address TEXT NOT NULL,
    city TEXT NOT NULL,
    province TEXT NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    phone_raw TEXT,
    whatsapp_number TEXT,
    wa_digits TEXT,
    carrier TEXT NOT NULL DEFAULT 'Desconhecido',
    has_mobile_whatsapp INTEGER NOT NULL DEFAULT 0,
    website_url TEXT,
    website_status TEXT NOT NULL DEFAULT 'none',
    is_qualified_target INTEGER NOT NULL DEFAULT 0,
    rating REAL,
    review_count INTEGER NOT NULL DEFAULT 0,
    business_status TEXT,
    google_maps_uri TEXT,
    opportunity_score INTEGER,
    score_rationale TEXT,
    pipeline_status TEXT NOT NULL DEFAULT 'novo',
    notes TEXT NOT NULL DEFAULT '',
    cached_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE SET NULL
  );

  CREATE INDEX IF NOT EXISTS idx_leads_city ON leads(city);
  CREATE INDEX IF NOT EXISTS idx_leads_pipeline ON leads(pipeline_status);
  CREATE INDEX IF NOT EXISTS idx_leads_qualified ON leads(is_qualified_target);

  CREATE TABLE IF NOT EXISTS auto_prospect_rules (
    id TEXT PRIMARY KEY,
    query TEXT NOT NULL,
    city TEXT NOT NULL,
    province TEXT NOT NULL,
    frequency TEXT NOT NULL DEFAULT 'weekly',
    day_of_week INTEGER NOT NULL DEFAULT 1,
    recipient_email TEXT NOT NULL DEFAULT '',
    only_without_website INTEGER NOT NULL DEFAULT 1,
    is_active INTEGER NOT NULL DEFAULT 1,
    last_run_at TEXT,
    next_run_at TEXT NOT NULL,
    last_found_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS auto_prospect_seen_places (
    rule_id TEXT NOT NULL,
    place_id TEXT NOT NULL,
    first_seen_at TEXT NOT NULL,
    PRIMARY KEY (rule_id, place_id),
    FOREIGN KEY (rule_id) REFERENCES auto_prospect_rules(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS auto_prospect_digests (
    id TEXT PRIMARY KEY,
    rule_id TEXT NOT NULL,
    rule_label TEXT NOT NULL,
    recipient_email TEXT NOT NULL DEFAULT '',
    total_scanned INTEGER NOT NULL DEFAULT 0,
    new_without_website_count INTEGER NOT NULL DEFAULT 0,
    new_leads_json TEXT NOT NULL DEFAULT '[]',
    email_subject TEXT NOT NULL,
    email_body TEXT NOT NULL,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (rule_id) REFERENCES auto_prospect_rules(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS google_sheets_config (
    id TEXT PRIMARY KEY,
    spreadsheet_id TEXT NOT NULL,
    spreadsheet_title TEXT NOT NULL,
    spreadsheet_url TEXT NOT NULL,
    sheet_name TEXT NOT NULL,
    auto_sync_enabled INTEGER NOT NULL DEFAULT 0,
    last_synced_at TEXT,
    last_synced_count INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS outreach_settings (
    id TEXT PRIMARY KEY,
    sender_email TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
`);

export const DEFAULT_OUTREACH_SENDER_EMAIL = 'scottnaftal@gmail.com';

interface LeadRow {
  id: number;
  place_id: string;
  campaign_id: string | null;
  name: string;
  niche: string;
  primary_type: string | null;
  address: string;
  city: string;
  province: string;
  lat: number;
  lng: number;
  phone_raw: string | null;
  whatsapp_number: string | null;
  wa_digits: string | null;
  carrier: string;
  has_mobile_whatsapp: number;
  website_url: string | null;
  website_status: string;
  is_qualified_target: number;
  rating: number | null;
  review_count: number;
  business_status: string | null;
  google_maps_uri: string | null;
  opportunity_score: number | null;
  score_rationale: string | null;
  pipeline_status: string;
  notes: string;
  cached_at: string;
  updated_at: string;
}

interface CampaignRow {
  id: string;
  niche: string;
  city: string;
  province: string;
  total_found: number;
  qualified_count: number;
  created_at: string;
}

function mapRowToLead(row: LeadRow): LeadRecord {
  const carrier: CarrierName = VALID_CARRIERS.includes(row.carrier as CarrierName)
    ? (row.carrier as CarrierName)
    : 'Desconhecido';
  const websiteStatus: WebsiteStatus = VALID_WEBSITE_STATUSES.includes(
    row.website_status as WebsiteStatus
  )
    ? (row.website_status as WebsiteStatus)
    : 'none';
  const pipelineStatus: PipelineStatus = VALID_PIPELINE_STATUSES.includes(
    row.pipeline_status as PipelineStatus
  )
    ? (row.pipeline_status as PipelineStatus)
    : 'novo';

  return {
    id: row.id,
    placeId: row.place_id,
    campaignId: row.campaign_id,
    name: row.name,
    niche: row.niche,
    primaryType: row.primary_type,
    address: row.address,
    city: row.city,
    province: row.province,
    lat: row.lat,
    lng: row.lng,
    phoneRaw: row.phone_raw,
    whatsappNumber: row.whatsapp_number,
    waDigits: row.wa_digits,
    carrier,
    hasMobileWhatsApp: Boolean(row.has_mobile_whatsapp),
    websiteUrl: row.website_url,
    websiteStatus,
    isQualifiedTarget: Boolean(row.is_qualified_target),
    rating: row.rating,
    reviewCount: row.review_count,
    businessStatus: row.business_status,
    googleMapsUri: row.google_maps_uri,
    opportunityScore: row.opportunity_score,
    scoreRationale: row.score_rationale,
    pipelineStatus,
    notes: row.notes,
    isSaved: true,
    cachedAt: row.cached_at,
    updatedAt: row.updated_at,
  };
}

export function isValidPipelineStatus(value: unknown): value is PipelineStatus {
  return typeof value === 'string' && VALID_PIPELINE_STATUSES.includes(value as PipelineStatus);
}

export function listCampaigns(limit = 50): CampaignRecord[] {
  const safeLimit = Math.max(1, Math.min(100, Math.floor(limit)));
  const rows = db
    .prepare(
      `SELECT id, niche, city, province, total_found, qualified_count, created_at
       FROM campaigns
       ORDER BY created_at DESC
       LIMIT ?`
    )
    .all(safeLimit) as CampaignRow[];

  return rows.map((r) => ({
    id: r.id,
    niche: r.niche,
    city: r.city,
    province: r.province,
    totalFound: r.total_found,
    qualifiedCount: r.qualified_count,
    createdAt: r.created_at,
  }));
}

export function insertCampaign(campaign: CampaignRecord): CampaignRecord {
  const now = campaign.createdAt || new Date().toISOString();
  db.prepare(
    `INSERT INTO campaigns (id, niche, city, province, total_found, qualified_count, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET
       total_found = excluded.total_found,
       qualified_count = excluded.qualified_count`
  ).run(
    String(campaign.id).slice(0, 100),
    String(campaign.niche).slice(0, 140),
    String(campaign.city).slice(0, 100),
    String(campaign.province).slice(0, 100),
    Math.max(0, Math.floor(campaign.totalFound || 0)),
    Math.max(0, Math.floor(campaign.qualifiedCount || 0)),
    now
  );

  return { ...campaign, createdAt: now };
}

export interface LeadQueryFilters {
  status?: string;
  city?: string;
  qualifiedOnly?: boolean;
  search?: string;
}

export function queryLeads(filters: LeadQueryFilters): LeadRecord[] {
  const conditions: string[] = [];
  const params: Array<string | number> = [];

  if (filters.status && filters.status !== 'all' && isValidPipelineStatus(filters.status)) {
    conditions.push('pipeline_status = ?');
    params.push(filters.status);
  }

  if (filters.city && filters.city !== 'all') {
    conditions.push('city = ?');
    params.push(filters.city.trim());
  }

  if (filters.qualifiedOnly) {
    conditions.push('is_qualified_target = 1');
  }

  if (filters.search && filters.search.trim().length > 0) {
    const pattern = `%${filters.search.trim()}%`;
    conditions.push(
      '(name LIKE ? OR niche LIKE ? OR address LIKE ? OR whatsapp_number LIKE ? OR phone_raw LIKE ?)'
    );
    params.push(pattern, pattern, pattern, pattern, pattern);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
  const sql = `
    SELECT * FROM leads
    ${whereClause}
    ORDER BY
      COALESCE(opportunity_score, -1) DESC,
      updated_at DESC
    LIMIT 500
  `;

  const rows = db.prepare(sql).all(...params) as LeadRow[];
  return rows.map(mapRowToLead);
}

export function upsertLeadsBulk(leads: LeadRecord[]): LeadRecord[] {
  const now = new Date().toISOString();

  const stmt = db.prepare(`
    INSERT INTO leads (
      place_id, campaign_id, name, niche, primary_type, address, city, province,
      lat, lng, phone_raw, whatsapp_number, wa_digits, carrier, has_mobile_whatsapp,
      website_url, website_status, is_qualified_target, rating, review_count,
      business_status, google_maps_uri, opportunity_score, score_rationale,
      pipeline_status, notes, cached_at, updated_at
    ) VALUES (
      @placeId, @campaignId, @name, @niche, @primaryType, @address, @city, @province,
      @lat, @lng, @phoneRaw, @whatsappNumber, @waDigits, @carrier, @hasMobileWhatsApp,
      @websiteUrl, @websiteStatus, @isQualifiedTarget, @rating, @reviewCount,
      @businessStatus, @googleMapsUri, @opportunityScore, @scoreRationale,
      @pipelineStatus, @notes, @cachedAt, @updatedAt
    )
    ON CONFLICT(place_id) DO UPDATE SET
      campaign_id = COALESCE(excluded.campaign_id, leads.campaign_id),
      name = excluded.name,
      niche = excluded.niche,
      primary_type = excluded.primary_type,
      address = excluded.address,
      city = excluded.city,
      province = excluded.province,
      lat = excluded.lat,
      lng = excluded.lng,
      phone_raw = excluded.phone_raw,
      whatsapp_number = excluded.whatsapp_number,
      wa_digits = excluded.wa_digits,
      carrier = excluded.carrier,
      has_mobile_whatsapp = excluded.has_mobile_whatsapp,
      website_url = excluded.website_url,
      website_status = excluded.website_status,
      is_qualified_target = excluded.is_qualified_target,
      rating = excluded.rating,
      review_count = excluded.review_count,
      business_status = excluded.business_status,
      google_maps_uri = excluded.google_maps_uri,
      opportunity_score = COALESCE(excluded.opportunity_score, leads.opportunity_score),
      score_rationale = COALESCE(excluded.score_rationale, leads.score_rationale),
      cached_at = excluded.cached_at,
      updated_at = excluded.updated_at
  `);

  const runBatch = db.transaction((items: LeadRecord[]) => {
    for (const item of items) {
      const websiteStatus: WebsiteStatus = VALID_WEBSITE_STATUSES.includes(item.websiteStatus)
        ? item.websiteStatus
        : 'none';
      const carrier: CarrierName = VALID_CARRIERS.includes(item.carrier)
        ? item.carrier
        : 'Desconhecido';
      const pipelineStatus: PipelineStatus = isValidPipelineStatus(item.pipelineStatus)
        ? item.pipelineStatus
        : 'novo';

      const cleanScore =
        typeof item.opportunityScore === 'number' && Number.isFinite(item.opportunityScore)
          ? Math.max(0, Math.min(100, Math.round(item.opportunityScore)))
          : null;

      stmt.run({
        placeId: String(item.placeId).slice(0, 200),
        campaignId: item.campaignId ? String(item.campaignId).slice(0, 100) : null,
        name: String(item.name || 'Sem nome').slice(0, 200),
        niche: String(item.niche || 'Geral').slice(0, 120),
        primaryType: item.primaryType ? String(item.primaryType).slice(0, 120) : null,
        address: String(item.address || '').slice(0, 300),
        city: String(item.city || 'Maputo').slice(0, 100),
        province: String(item.province || 'Moçambique').slice(0, 100),
        lat: Number(item.lat) || 0,
        lng: Number(item.lng) || 0,
        phoneRaw: item.phoneRaw ? String(item.phoneRaw).slice(0, 60) : null,
        whatsappNumber: item.whatsappNumber ? String(item.whatsappNumber).slice(0, 60) : null,
        waDigits: item.waDigits ? String(item.waDigits).replace(/\D/g, '').slice(0, 20) : null,
        carrier,
        hasMobileWhatsApp: item.hasMobileWhatsApp ? 1 : 0,
        websiteUrl: sanitizeExternalHttpUrl(item.websiteUrl),
        websiteStatus,
        isQualifiedTarget: item.isQualifiedTarget ? 1 : 0,
        rating:
          typeof item.rating === 'number' && Number.isFinite(item.rating)
            ? Math.max(0, Math.min(5, item.rating))
            : null,
        reviewCount: Math.max(0, Math.floor(Number(item.reviewCount) || 0)),
        businessStatus: item.businessStatus ? String(item.businessStatus).slice(0, 60) : null,
        googleMapsUri: sanitizeExternalHttpUrl(item.googleMapsUri),
        opportunityScore: cleanScore,
        scoreRationale: item.scoreRationale ? String(item.scoreRationale).slice(0, 400) : null,
        pipelineStatus,
        notes: String(item.notes || '').slice(0, 1000),
        cachedAt: now,
        updatedAt: now,
      });
    }
  });

  runBatch(leads);
  const placeIds = leads.map((l) => l.placeId);
  if (placeIds.length === 0) return [];
  const placeholders = placeIds.map(() => '?').join(',');
  const rows = db
    .prepare(`SELECT * FROM leads WHERE place_id IN (${placeholders})`)
    .all(...placeIds) as LeadRow[];
  return rows.map(mapRowToLead);
}

export function updateLeadRecord(
  placeId: string,
  updates: {
    pipelineStatus?: PipelineStatus;
    notes?: string;
    opportunityScore?: number | null;
    scoreRationale?: string | null;
  }
): LeadRecord | null {
  const existing = db
    .prepare('SELECT * FROM leads WHERE place_id = ?')
    .get(placeId) as LeadRow | undefined;

  if (!existing) {
    return null;
  }

  const nextStatus =
    updates.pipelineStatus !== undefined && isValidPipelineStatus(updates.pipelineStatus)
      ? updates.pipelineStatus
      : existing.pipeline_status;

  const nextNotes =
    updates.notes !== undefined ? String(updates.notes).slice(0, 1000) : existing.notes;

  const nextScore =
    updates.opportunityScore !== undefined
      ? updates.opportunityScore === null
        ? null
        : Math.max(0, Math.min(100, Math.round(Number(updates.opportunityScore))))
      : existing.opportunity_score;

  const nextRationale =
    updates.scoreRationale !== undefined
      ? updates.scoreRationale === null
        ? null
        : String(updates.scoreRationale).slice(0, 400)
      : existing.score_rationale;

  const now = new Date().toISOString();

  db.prepare(
    `UPDATE leads
     SET pipeline_status = ?, notes = ?, opportunity_score = ?, score_rationale = ?, updated_at = ?
     WHERE place_id = ?`
  ).run(nextStatus, nextNotes, nextScore, nextRationale, now, placeId);

  const updated = db
    .prepare('SELECT * FROM leads WHERE place_id = ?')
    .get(placeId) as LeadRow;
  return mapRowToLead(updated);
}

export function updateLeadScoresInDb(
  scores: Array<{ placeId: string; opportunityScore: number; scoreRationale: string }>
): void {
  const now = new Date().toISOString();
  const stmt = db.prepare(
    `UPDATE leads
     SET opportunity_score = ?, score_rationale = ?, updated_at = ?
     WHERE place_id = ?`
  );

  const tx = db.transaction(
    (items: Array<{ placeId: string; opportunityScore: number; scoreRationale: string }>) => {
      for (const item of items) {
        stmt.run(
          Math.max(0, Math.min(100, Math.round(item.opportunityScore))),
          String(item.scoreRationale).slice(0, 400),
          now,
          item.placeId
        );
      }
    }
  );

  tx(scores);
}

export function deleteLeadRecord(placeId: string): boolean {
  const res = db.prepare('DELETE FROM leads WHERE place_id = ?').run(placeId);
  return res.changes > 0;
}

function escapeCsvCell(rawValue: string | number | null | undefined): string {
  if (rawValue === null || rawValue === undefined) {
    return '""';
  }
  let text = String(rawValue);
  // Neutralize spreadsheet formula injection characters
  if (/^[=+\-@\t\r]/.test(text)) {
    text = `'${text}`;
  }
  return `"${text.replace(/"/g, '""')}"`;
}

export function buildLeadsCsv(leads: LeadRecord[]): string {
  const headers = [
    'Empresa',
    'Nicho',
    'Cidade',
    'Provincia',
    'Endereco',
    'WhatsApp_Numero',
    'Operadora',
    'Website_Status',
    'Website_URL',
    'Avaliacao',
    'Avaliacoes_Qtd',
    'Score_Oportunidade_IA',
    'Justificacao_IA',
    'Estado_Funil',
    'Link_WhatsApp',
    'Google_Maps_URL',
    'Notas',
  ];

  const websiteLabelMap: Record<WebsiteStatus, string> = {
    none: 'Sem website',
    social_only: 'Apenas rede social',
    has_website: 'Possui website',
  };

  const rows = leads.map((lead) => [
    escapeCsvCell(lead.name),
    escapeCsvCell(lead.niche),
    escapeCsvCell(lead.city),
    escapeCsvCell(lead.province),
    escapeCsvCell(lead.address),
    escapeCsvCell(lead.waDigits || lead.whatsappNumber || lead.phoneRaw || ''),
    escapeCsvCell(lead.carrier),
    escapeCsvCell(websiteLabelMap[lead.websiteStatus]),
    escapeCsvCell(lead.websiteUrl || ''),
    escapeCsvCell(lead.rating !== null ? lead.rating.toFixed(1) : ''),
    escapeCsvCell(lead.reviewCount),
    escapeCsvCell(lead.opportunityScore !== null ? lead.opportunityScore : ''),
    escapeCsvCell(lead.scoreRationale || ''),
    escapeCsvCell(lead.pipelineStatus),
    escapeCsvCell(lead.waDigits ? `https://wa.me/${lead.waDigits}` : ''),
    escapeCsvCell(lead.googleMapsUri || ''),
    escapeCsvCell(lead.notes || ''),
  ]);

  return `\uFEFF${[headers.map(escapeCsvCell).join(','), ...rows.map((r) => r.join(','))].join('\r\n')}`;
}

interface AutoRuleRow {
  id: string;
  query: string;
  city: string;
  province: string;
  frequency: string;
  day_of_week: number;
  recipient_email: string;
  only_without_website: number;
  is_active: number;
  last_run_at: string | null;
  next_run_at: string;
  last_found_count: number;
  created_at: string;
}

interface AutoDigestRow {
  id: string;
  rule_id: string;
  rule_label: string;
  recipient_email: string;
  total_scanned: number;
  new_without_website_count: number;
  new_leads_json: string;
  email_subject: string;
  email_body: string;
  is_read: number;
  created_at: string;
}

function mapRuleRow(row: AutoRuleRow): AutoProspectRule {
  return {
    id: row.id,
    query: row.query,
    city: row.city,
    province: row.province,
    frequency: row.frequency === 'daily' ? 'daily' : 'weekly',
    dayOfWeek: Number.isFinite(row.day_of_week) ? Math.max(0, Math.min(6, row.day_of_week)) : 1,
    recipientEmail: row.recipient_email || '',
    onlyWithoutWebsite: Boolean(row.only_without_website),
    isActive: Boolean(row.is_active),
    lastRunAt: row.last_run_at,
    nextRunAt: row.next_run_at,
    lastFoundCount: row.last_found_count,
    createdAt: row.created_at,
  };
}

function mapDigestRow(row: AutoDigestRow): AutoProspectDigest {
  let leads: AutoProspectDigestLead[] = [];
  try {
    const parsed = JSON.parse(row.new_leads_json);
    if (Array.isArray(parsed)) {
      leads = parsed as AutoProspectDigestLead[];
    }
  } catch {
    leads = [];
  }
  return {
    id: row.id,
    ruleId: row.rule_id,
    ruleLabel: row.rule_label,
    recipientEmail: row.recipient_email || '',
    totalScanned: row.total_scanned,
    newWithoutWebsiteCount: row.new_without_website_count,
    leads,
    emailSubject: row.email_subject,
    emailBody: row.email_body,
    isRead: Boolean(row.is_read),
    createdAt: row.created_at,
  };
}

function computeNextRunAt(frequency: AutoProspectFrequency, dayOfWeek: number, fromDate = new Date()): string {
  const next = new Date(fromDate.getTime());
  if (frequency === 'daily') {
    next.setDate(next.getDate() + 1);
    next.setHours(8, 30, 0, 0);
    return next.toISOString();
  }
  const safeDay = Math.max(0, Math.min(6, Math.floor(dayOfWeek)));
  const currentDay = next.getDay();
  let daysUntil = (safeDay - currentDay + 7) % 7;
  if (daysUntil === 0) daysUntil = 7;
  next.setDate(next.getDate() + daysUntil);
  next.setHours(8, 30, 0, 0);
  return next.toISOString();
}

export function listAutoProspectRules(): AutoProspectRule[] {
  const rows = db
    .prepare(
      `SELECT * FROM auto_prospect_rules
       ORDER BY is_active DESC, created_at DESC`
    )
    .all() as AutoRuleRow[];
  return rows.map(mapRuleRow);
}

export function createAutoProspectRule(input: {
  query: string;
  city: string;
  province: string;
  frequency: AutoProspectFrequency;
  dayOfWeek: number;
  recipientEmail?: string;
  onlyWithoutWebsite?: boolean;
}): AutoProspectRule {
  const now = new Date();
  const id = `rule_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const frequency: AutoProspectFrequency = input.frequency === 'daily' ? 'daily' : 'weekly';
  const parsedDay = Number(input.dayOfWeek);
  const dayOfWeek = Math.max(
    0,
    Math.min(6, Math.floor(Number.isFinite(parsedDay) ? parsedDay : 1))
  );
  const nextRunAt = computeNextRunAt(frequency, dayOfWeek, now);
  const recipientEmail = String(input.recipientEmail || '').trim().slice(0, 160);
  const onlyWithoutWebsite = input.onlyWithoutWebsite !== false;

  db.prepare(
    `INSERT INTO auto_prospect_rules (
      id, query, city, province, frequency, day_of_week, recipient_email,
      only_without_website, is_active, last_run_at, next_run_at, last_found_count, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NULL, ?, 0, ?)`
  ).run(
    id,
    input.query.trim().slice(0, 120),
    input.city.trim().slice(0, 100),
    input.province.trim().slice(0, 100),
    frequency,
    dayOfWeek,
    recipientEmail,
    onlyWithoutWebsite ? 1 : 0,
    nextRunAt,
    now.toISOString()
  );

  const created = db
    .prepare('SELECT * FROM auto_prospect_rules WHERE id = ?')
    .get(id) as AutoRuleRow;
  return mapRuleRow(created);
}

export function updateAutoProspectRule(
  id: string,
  updates: {
    isActive?: boolean;
    frequency?: AutoProspectFrequency;
    dayOfWeek?: number;
    recipientEmail?: string;
  }
): AutoProspectRule | null {
  const existing = db
    .prepare('SELECT * FROM auto_prospect_rules WHERE id = ?')
    .get(id) as AutoRuleRow | undefined;
  if (!existing) return null;

  const nextActive = updates.isActive !== undefined ? (updates.isActive ? 1 : 0) : existing.is_active;
  const nextFrequency: AutoProspectFrequency =
    updates.frequency !== undefined
      ? updates.frequency === 'daily'
        ? 'daily'
        : 'weekly'
      : existing.frequency === 'daily'
      ? 'daily'
      : 'weekly';
  const nextDay =
    updates.dayOfWeek !== undefined
      ? Math.max(0, Math.min(6, Math.floor(updates.dayOfWeek)))
      : existing.day_of_week;
  const nextEmail =
    updates.recipientEmail !== undefined
      ? updates.recipientEmail.trim().slice(0, 160)
      : existing.recipient_email;
  const nextRunAt =
    updates.frequency !== undefined || updates.dayOfWeek !== undefined
      ? computeNextRunAt(nextFrequency, nextDay, new Date())
      : existing.next_run_at;

  db.prepare(
    `UPDATE auto_prospect_rules
     SET is_active = ?, frequency = ?, day_of_week = ?, recipient_email = ?, next_run_at = ?
     WHERE id = ?`
  ).run(nextActive, nextFrequency, nextDay, nextEmail, nextRunAt, id);

  const row = db
    .prepare('SELECT * FROM auto_prospect_rules WHERE id = ?')
    .get(id) as AutoRuleRow;
  return mapRuleRow(row);
}

export function deleteAutoProspectRule(id: string): boolean {
  const res = db.prepare('DELETE FROM auto_prospect_rules WHERE id = ?').run(id);
  return res.changes > 0;
}

export function listAutoProspectDigests(limit = 30): AutoProspectDigest[] {
  const safeLimit = Math.max(1, Math.min(100, Math.floor(limit)));
  const rows = db
    .prepare(
      `SELECT * FROM auto_prospect_digests
       ORDER BY created_at DESC
       LIMIT ?`
    )
    .all(safeLimit) as AutoDigestRow[];
  return rows.map(mapDigestRow);
}

export function markAutoProspectDigestRead(id: string): boolean {
  const res = db
    .prepare('UPDATE auto_prospect_digests SET is_read = 1 WHERE id = ?')
    .run(id);
  return res.changes > 0;
}

export function markAllAutoProspectDigestsRead(): void {
  db.prepare('UPDATE auto_prospect_digests SET is_read = 1 WHERE is_read = 0').run();
}

export function recordAutoProspectRun(
  ruleId: string,
  scannedLeads: LeadRecord[]
): { rule: AutoProspectRule; digest: AutoProspectDigest } | null {
  const ruleRow = db
    .prepare('SELECT * FROM auto_prospect_rules WHERE id = ?')
    .get(ruleId) as AutoRuleRow | undefined;
  if (!ruleRow) return null;

  const rule = mapRuleRow(ruleRow);
  const now = new Date();
  const nowIso = now.toISOString();

  const seenRows = db
    .prepare('SELECT place_id FROM auto_prospect_seen_places WHERE rule_id = ?')
    .all(ruleId) as Array<{ place_id: string }>;
  const seenSet = new Set(seenRows.map((r) => r.place_id));

  const savedRows = db.prepare('SELECT place_id FROM leads').all() as Array<{ place_id: string }>;
  const savedSet = new Set(savedRows.map((r) => r.place_id));

  const targetLeads = scannedLeads.filter((lead) =>
    rule.onlyWithoutWebsite ? lead.websiteStatus !== 'has_website' : true
  );

  const newlyFound = targetLeads.filter(
    (lead) => !seenSet.has(lead.placeId) && !savedSet.has(lead.placeId)
  );

  const digestLeads: AutoProspectDigestLead[] = newlyFound.slice(0, 25).map((l) => ({
    placeId: l.placeId,
    name: l.name,
    primaryType: l.primaryType ?? null,
    address: l.address,
    city: l.city,
    province: l.province,
    lat: l.lat,
    lng: l.lng,
    phoneRaw: l.phoneRaw,
    whatsappNumber: l.whatsappNumber,
    waDigits: l.waDigits,
    carrier: l.carrier,
    hasMobileWhatsApp: l.hasMobileWhatsApp,
    websiteUrl: l.websiteUrl,
    websiteStatus: l.websiteStatus,
    rating: l.rating,
    reviewCount: l.reviewCount,
    googleMapsUri: l.googleMapsUri,
  }));

  const ruleLabel = `${rule.query} em ${rule.city}`;
  const periodLabel = rule.frequency === 'daily' ? 'Resumo Diário' : 'Resumo Semanal';
  const emailSubject = `[Minera.ia · ${periodLabel}] ${newlyFound.length} novos negócios sem website — ${ruleLabel}`;

  const lines: string[] = [
    `Resumo de Auto-Prospecção Minera.ia (${periodLabel})`,
    `Pesquisa configurada: ${ruleLabel} (${rule.province}, Moçambique)`,
    `Data da verificação: ${now.toLocaleString('pt-MZ')}`,
    `Estabelecimentos analisados no mapa: ${scannedLeads.length}`,
    `Novos negócios sem website próprio encontrados: ${newlyFound.length}`,
    '',
  ];

  if (digestLeads.length > 0) {
    lines.push('Lista de novos negócios:');
    digestLeads.forEach((item, idx) => {
      const phoneLabel = item.whatsappNumber
        ? `${item.whatsappNumber} (${item.carrier} · móvel +258)`
        : item.phoneRaw || 'Sem telefone publicado';
      const webLabel =
        item.websiteStatus === 'social_only' ? 'Apenas rede social' : 'Sem website registado';
      lines.push(
        `${idx + 1}. ${item.name} — ${webLabel}\n   Tel: ${phoneLabel}\n   Morada: ${item.address}${
          item.googleMapsUri ? `\n   Maps: ${item.googleMapsUri}` : ''
        }`
      );
    });
  } else {
    lines.push(
      'Nenhum novo negócio sem website foi detetado em relação às execuções anteriores desta regra.'
    );
  }

  lines.push('', 'Nota: "Sem website" indica que não há website próprio registado no Google Maps.');
  const emailBody = lines.join('\n');

  const digestId = `dig_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const nextRunAt = computeNextRunAt(rule.frequency, rule.dayOfWeek, now);

  const tx = db.transaction(() => {
    const insertSeen = db.prepare(
      `INSERT OR IGNORE INTO auto_prospect_seen_places (rule_id, place_id, first_seen_at)
       VALUES (?, ?, ?)`
    );
    for (const lead of scannedLeads) {
      insertSeen.run(ruleId, lead.placeId, nowIso);
    }

    db.prepare(
      `INSERT INTO auto_prospect_digests (
        id, rule_id, rule_label, recipient_email, total_scanned,
        new_without_website_count, new_leads_json, email_subject, email_body,
        is_read, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
    ).run(
      digestId,
      ruleId,
      ruleLabel,
      rule.recipientEmail,
      scannedLeads.length,
      newlyFound.length,
      JSON.stringify(digestLeads),
      emailSubject,
      emailBody,
      nowIso
    );

    db.prepare(
      `UPDATE auto_prospect_rules
       SET last_run_at = ?, next_run_at = ?, last_found_count = ?
       WHERE id = ?`
    ).run(nowIso, nextRunAt, newlyFound.length, ruleId);
  });

  tx();

  const updatedRule = mapRuleRow(
    db.prepare('SELECT * FROM auto_prospect_rules WHERE id = ?').get(ruleId) as AutoRuleRow
  );
  const createdDigest = mapDigestRow(
    db.prepare('SELECT * FROM auto_prospect_digests WHERE id = ?').get(digestId) as AutoDigestRow
  );

  return { rule: updatedRule, digest: createdDigest };
}

interface GoogleSheetsConfigRow {
  id: string;
  spreadsheet_id: string;
  spreadsheet_title: string;
  spreadsheet_url: string;
  sheet_name: string;
  auto_sync_enabled: number;
  last_synced_at: string | null;
  last_synced_count: number;
  updated_at: string;
}

function mapSheetsConfigRow(row: GoogleSheetsConfigRow): GoogleSheetsConfig {
  return {
    spreadsheetId: row.spreadsheet_id,
    spreadsheetTitle: row.spreadsheet_title,
    spreadsheetUrl: row.spreadsheet_url,
    sheetName: row.sheet_name,
    autoSyncEnabled: Boolean(row.auto_sync_enabled),
    lastSyncedAt: row.last_synced_at,
    lastSyncedCount: row.last_synced_count,
    updatedAt: row.updated_at,
  };
}

export function getGoogleSheetsConfig(): GoogleSheetsConfig | null {
  const row = db
    .prepare('SELECT * FROM google_sheets_config WHERE id = ?')
    .get('default') as GoogleSheetsConfigRow | undefined;
  return row ? mapSheetsConfigRow(row) : null;
}

export function saveGoogleSheetsConfig(input: {
  spreadsheetId: string;
  spreadsheetTitle: string;
  spreadsheetUrl: string;
  sheetName: string;
  autoSyncEnabled?: boolean;
  lastSyncedAt?: string | null;
  lastSyncedCount?: number;
}): GoogleSheetsConfig {
  const existing = getGoogleSheetsConfig();
  const now = new Date().toISOString();

  const spreadsheetId = input.spreadsheetId.trim().slice(0, 200);
  const spreadsheetTitle = input.spreadsheetTitle.trim().slice(0, 200) || 'Planilha Minera.ia';
  const spreadsheetUrl =
    sanitizeExternalHttpUrl(input.spreadsheetUrl) ||
    `https://docs.google.com/spreadsheets/d/${encodeURIComponent(spreadsheetId)}/edit`;
  const sheetName = input.sheetName.trim().slice(0, 120) || 'Leads_MZ';
  const autoSyncEnabled =
    input.autoSyncEnabled !== undefined
      ? input.autoSyncEnabled
      : existing?.autoSyncEnabled ?? false;
  const lastSyncedAt =
    input.lastSyncedAt !== undefined ? input.lastSyncedAt : existing?.lastSyncedAt ?? null;
  const lastSyncedCount =
    input.lastSyncedCount !== undefined
      ? Math.max(0, Math.floor(Number(input.lastSyncedCount) || 0))
      : existing?.lastSyncedCount ?? 0;

  db.prepare(
    `INSERT INTO google_sheets_config (
      id, spreadsheet_id, spreadsheet_title, spreadsheet_url, sheet_name,
      auto_sync_enabled, last_synced_at, last_synced_count, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      spreadsheet_id = excluded.spreadsheet_id,
      spreadsheet_title = excluded.spreadsheet_title,
      spreadsheet_url = excluded.spreadsheet_url,
      sheet_name = excluded.sheet_name,
      auto_sync_enabled = excluded.auto_sync_enabled,
      last_synced_at = excluded.last_synced_at,
      last_synced_count = excluded.last_synced_count,
      updated_at = excluded.updated_at`
  ).run(
    'default',
    spreadsheetId,
    spreadsheetTitle,
    spreadsheetUrl,
    sheetName,
    autoSyncEnabled ? 1 : 0,
    lastSyncedAt,
    lastSyncedCount,
    now
  );

  return getGoogleSheetsConfig()!;
}

export function clearGoogleSheetsConfig(): void {
  db.prepare('DELETE FROM google_sheets_config WHERE id = ?').run('default');
}

export function getOutreachSettings(): OutreachSettings {
  const row = db
    .prepare('SELECT sender_email, updated_at FROM outreach_settings WHERE id = ?')
    .get('default') as { sender_email: string; updated_at: string } | undefined;

  if (row) {
    return {
      senderEmail: row.sender_email,
      updatedAt: row.updated_at,
    };
  }

  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO outreach_settings (id, sender_email, updated_at)
     VALUES ('default', ?, ?)`
  ).run(DEFAULT_OUTREACH_SENDER_EMAIL, now);

  return {
    senderEmail: DEFAULT_OUTREACH_SENDER_EMAIL,
    updatedAt: now,
  };
}

export function saveOutreachSettings(senderEmail: string): OutreachSettings {
  const cleanEmail = senderEmail.trim().slice(0, 160);
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO outreach_settings (id, sender_email, updated_at)
     VALUES ('default', ?, ?)
     ON CONFLICT(id) DO UPDATE SET
       sender_email = excluded.sender_email,
       updated_at = excluded.updated_at`
  ).run(cleanEmail, now);

  return {
    senderEmail: cleanEmail,
    updatedAt: now,
  };
}


