export type WebsiteStatus = 'none' | 'social_only' | 'has_website';

export type PipelineStatus =
  | 'novo'
  | 'em_analise'
  | 'contactado'
  | 'convertido'
  | 'descartado';

export type CarrierName = 'Vodacom' | 'Movitel' | 'Tmcel' | 'Fixo' | 'Desconhecido';

export interface LeadRecord {
  id?: number;
  placeId: string;
  campaignId?: string | null;
  name: string;
  niche: string;
  primaryType?: string | null;
  address: string;
  city: string;
  province: string;
  lat: number;
  lng: number;
  phoneRaw: string | null;
  whatsappNumber: string | null;
  waDigits: string | null;
  carrier: CarrierName;
  hasMobileWhatsApp: boolean;
  websiteUrl: string | null;
  websiteStatus: WebsiteStatus;
  isQualifiedTarget: boolean;
  rating: number | null;
  reviewCount: number;
  businessStatus?: string | null;
  googleMapsUri: string | null;
  opportunityScore: number | null;
  scoreRationale: string | null;
  pipelineStatus: PipelineStatus;
  notes: string;
  isSaved?: boolean;
  cachedAt?: string;
  updatedAt?: string;
}

export interface CampaignRecord {
  id: string;
  niche: string;
  city: string;
  province: string;
  totalFound: number;
  qualifiedCount: number;
  createdAt: string;
}

export interface AiScoreRequestItem {
  placeId: string;
  name: string;
  niche: string;
  city: string;
  province: string;
  rating: number | null;
  reviewCount: number;
  websiteStatus: WebsiteStatus;
  hasMobileWhatsApp: boolean;
  carrier: CarrierName;
  businessStatus?: string | null;
}

export interface AiScoreResultItem {
  placeId: string;
  opportunityScore: number;
  scoreRationale: string;
}

export interface WebSearchSource {
  title: string;
  uri: string;
}

export interface WebSearchGroundingResult {
  summary: string;
  sources: WebSearchSource[];
  searchQueries: string[];
  checkedAt: string;
}

export type AutoProspectFrequency = 'weekly' | 'daily';

export interface AutoProspectRule {
  id: string;
  query: string;
  city: string;
  province: string;
  frequency: AutoProspectFrequency;
  dayOfWeek: number; // 0 (Dom) - 6 (Sáb)
  recipientEmail: string;
  onlyWithoutWebsite: boolean;
  isActive: boolean;
  lastRunAt: string | null;
  nextRunAt: string;
  lastFoundCount: number;
  createdAt: string;
}

export interface AutoProspectDigestLead {
  placeId: string;
  name: string;
  primaryType?: string | null;
  address: string;
  city: string;
  province: string;
  lat: number;
  lng: number;
  phoneRaw: string | null;
  whatsappNumber: string | null;
  waDigits: string | null;
  carrier: CarrierName;
  hasMobileWhatsApp: boolean;
  websiteUrl: string | null;
  websiteStatus: WebsiteStatus;
  rating: number | null;
  reviewCount: number;
  googleMapsUri: string | null;
}

export interface AutoProspectDigest {
  id: string;
  ruleId: string;
  ruleLabel: string;
  recipientEmail: string;
  totalScanned: number;
  newWithoutWebsiteCount: number;
  leads: AutoProspectDigestLead[];
  emailSubject: string;
  emailBody: string;
  isRead: boolean;
  createdAt: string;
}

export interface GoogleSheetTabInfo {
  sheetId: number;
  title: string;
}

export interface GoogleSheetsConfig {
  spreadsheetId: string;
  spreadsheetTitle: string;
  spreadsheetUrl: string;
  sheetName: string;
  autoSyncEnabled: boolean;
  lastSyncedAt: string | null;
  lastSyncedCount: number;
  updatedAt: string;
}

export interface OutreachSettings {
  senderEmail: string;
  updatedAt: string;
}
