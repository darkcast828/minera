export class GoogleGmailAuthError extends Error {
  constructor(
    message = 'A autorização do Gmail expirou ou precisa da permissão de envio. Inicie sessão novamente.'
  ) {
    super(message);
    this.name = 'GoogleGmailAuthError';
  }
}

function bytesToBase64Url(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function encodeUtf8Base64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function encodeRfc2047Subject(subject: string): string {
  const clean = subject.replace(/[\r\n]+/g, ' ').trim();
  // Pure ASCII doesn't need MIME encoding
  if (/^[\x20-\x7E]*$/.test(clean)) {
    return clean;
  }
  return `=?UTF-8?B?${encodeUtf8Base64(clean)}?=`;
}

function sanitizeHeaderEmail(value: string): string {
  return value.replace(/[\r\n<>]/g, '').trim();
}

export interface SendGmailParams {
  to: string;
  subject: string;
  bodyText: string;
  replyToEmail?: string;
  accessToken: string;
}

export async function sendGmailMessage(
  params: SendGmailParams
): Promise<{ messageId: string; threadId?: string }> {
  const cleanTo = sanitizeHeaderEmail(params.to);
  if (!cleanTo || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanTo)) {
    throw new Error('Indique um endereço de e-mail de destino válido.');
  }

  const headers: string[] = [
    `To: ${cleanTo}`,
    `Subject: ${encodeRfc2047Subject(params.subject)}`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: 8bit',
  ];

  const cleanReplyTo = params.replyToEmail ? sanitizeHeaderEmail(params.replyToEmail) : '';
  if (cleanReplyTo && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanReplyTo)) {
    headers.push(`Reply-To: ${cleanReplyTo}`);
  }

  const rawMime = `${headers.join('\r\n')}\r\n\r\n${params.bodyText}`;
  const rawEncoded = bytesToBase64Url(new TextEncoder().encode(rawMime));

  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${params.accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw: rawEncoded }),
  });

  if (!res.ok) {
    if (res.status === 401) {
      throw new GoogleGmailAuthError();
    }
    try {
      const errData = (await res.json()) as { error?: { message?: string } };
      const msg = errData.error?.message || '';
      if (
        res.status === 403 &&
        (msg.toLowerCase().includes('insufficient') || msg.toLowerCase().includes('scope'))
      ) {
        throw new GoogleGmailAuthError(
          'Permissão do Gmail em falta. Clique em "Sign in with Google" para conceder acesso de envio.'
        );
      }
      throw new Error(msg || 'Falha ao enviar e-mail através do Gmail.');
    } catch (err) {
      if (err instanceof Error) throw err;
      throw new Error('Falha ao enviar e-mail através do Gmail.');
    }
  }

  const data = (await res.json()) as { id?: string; threadId?: string };
  return {
    messageId: data.id || '',
    threadId: data.threadId,
  };
}
