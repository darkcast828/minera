import { PIPELINE_STATUS_LABELS } from '../data/mozambique.ts';
import type { GoogleSheetTabInfo, LeadRecord } from '../types/leads.ts';

export class GoogleSheetsAuthError extends Error {
  constructor(message = 'A autorização com o Google Sheets expirou. Inicie sessão novamente.') {
    super(message);
    this.name = 'GoogleSheetsAuthError';
  }
}

export interface SpreadsheetMetadata {
  spreadsheetId: string;
  spreadsheetTitle: string;
  spreadsheetUrl: string;
  tabs: GoogleSheetTabInfo[];
}

const SHEETS_API_BASE = 'https://sheets.googleapis.com/v4/spreadsheets';

export function extractSpreadsheetId(rawInput: string): string | null {
  const trimmed = rawInput.trim();
  if (!trimmed) return null;
  const urlMatch = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (urlMatch?.[1]) return urlMatch[1];
  if (/^[a-zA-Z0-9-_]{20,}$/.test(trimmed)) return trimmed;
  return null;
}

function escapeSheetTitleForRange(title: string): string {
  return `'${title.replace(/'/g, "''")}'`;
}

function sanitizeSheetText(value: string | null | undefined): string {
  if (!value) return '';
  const text = String(value);
  if (/^[=+\-@\t\r]/.test(text)) {
    return `'${text}`;
  }
  return text;
}

async function parseSheetsError(res: Response, fallback: string): Promise<Error> {
  if (res.status === 401) {
    return new GoogleSheetsAuthError();
  }
  try {
    const data = (await res.json()) as { error?: { message?: string; status?: string } };
    const msg = data.error?.message;
    if (res.status === 403 && msg?.toLowerCase().includes('insufficient')) {
      return new GoogleSheetsAuthError(
        'Permissão insuficiente para editar Google Sheets. Clique em "Sign in with Google" para conceder acesso.'
      );
    }
    return new Error(msg || fallback);
  } catch {
    return new Error(fallback);
  }
}

export async function fetchSpreadsheetMetadata(
  spreadsheetId: string,
  accessToken: string
): Promise<SpreadsheetMetadata> {
  const url = `${SHEETS_API_BASE}/${encodeURIComponent(
    spreadsheetId
  )}?fields=spreadsheetId,properties.title,spreadsheetUrl,sheets(properties(sheetId,title))`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    throw await parseSheetsError(
      res,
      'Não foi possível abrir esta planilha. Verifique o URL/ID e as permissões.'
    );
  }

  const data = (await res.json()) as {
    spreadsheetId?: string;
    spreadsheetUrl?: string;
    properties?: { title?: string };
    sheets?: Array<{ properties?: { sheetId?: number; title?: string } }>;
  };

  const tabs: GoogleSheetTabInfo[] = (data.sheets ?? [])
    .map((s, idx) => ({
      sheetId: typeof s.properties?.sheetId === 'number' ? s.properties.sheetId : idx,
      title: s.properties?.title || `Folha ${idx + 1}`,
    }))
    .filter((t) => Boolean(t.title));

  return {
    spreadsheetId: data.spreadsheetId || spreadsheetId,
    spreadsheetTitle: data.properties?.title || 'Planilha Google Sheets',
    spreadsheetUrl:
      data.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
    tabs,
  };
}

export async function createLeadsSpreadsheet(
  title: string,
  accessToken: string
): Promise<SpreadsheetMetadata> {
  const initialTabTitle = 'Leads_MZ';
  const res = await fetch(SHEETS_API_BASE, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: title.trim() || 'Minera.ia — Leads Moçambique',
        locale: 'pt_PT',
      },
      sheets: [
        {
          properties: {
            title: initialTabTitle,
            gridProperties: {
              frozenRowCount: 1,
            },
          },
        },
      ],
    }),
  });

  if (!res.ok) {
    throw await parseSheetsError(res, 'Não foi possível criar a planilha no Google Sheets.');
  }

  const created = (await res.json()) as {
    spreadsheetId: string;
    spreadsheetUrl?: string;
    properties?: { title?: string };
    sheets?: Array<{ properties?: { sheetId?: number; title?: string } }>;
  };

  const tabs: GoogleSheetTabInfo[] = (created.sheets ?? []).map((s, idx) => ({
    sheetId: typeof s.properties?.sheetId === 'number' ? s.properties.sheetId : idx,
    title: s.properties?.title || initialTabTitle,
  }));

  const firstSheetId = tabs[0]?.sheetId ?? 0;
  // Format header row neatly (bold + subtle light header fill)
  void fetch(`${SHEETS_API_BASE}/${encodeURIComponent(created.spreadsheetId)}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      requests: [
        {
          repeatCell: {
            range: {
              sheetId: firstSheetId,
              startRowIndex: 0,
              endRowIndex: 1,
              startColumnIndex: 0,
              endColumnIndex: 18,
            },
            cell: {
              userEnteredFormat: {
                backgroundColor: { red: 0.93, green: 0.97, blue: 0.95 },
                textFormat: { bold: true },
              },
            },
            fields: 'userEnteredFormat(backgroundColor,textFormat)',
          },
        },
      ],
    }),
  }).catch(() => undefined);

  return {
    spreadsheetId: created.spreadsheetId,
    spreadsheetTitle: created.properties?.title || title,
    spreadsheetUrl:
      created.spreadsheetUrl ||
      `https://docs.google.com/spreadsheets/d/${created.spreadsheetId}/edit`,
    tabs: tabs.length > 0 ? tabs : [{ sheetId: 0, title: initialTabTitle }],
  };
}

export async function syncLeadsToGoogleSheet(params: {
  spreadsheetId: string;
  sheetName: string;
  leads: LeadRecord[];
  accessToken: string;
}): Promise<{ updatedRows: number; syncedAt: string }> {
  const { spreadsheetId, sheetName, leads, accessToken } = params;
  const quotedTab = escapeSheetTitleForRange(sheetName);
  const clearRange = encodeURIComponent(`${quotedTab}!A:R`);

  const clearRes = await fetch(
    `${SHEETS_API_BASE}/${encodeURIComponent(spreadsheetId)}/values/${clearRange}:clear`,
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  if (!clearRes.ok) {
    throw await parseSheetsError(
      clearRes,
      `Não foi possível limpar a aba "${sheetName}" antes de sincronizar.`
    );
  }

  const websiteLabelMap: Record<LeadRecord['websiteStatus'], string> = {
    none: 'Sem website registado',
    social_only: 'Apenas rede social',
    has_website: 'Website registado',
  };

  const headers: Array<string | number> = [
    'Empresa',
    'Nicho',
    'Cidade',
    'Província',
    'Endereço',
    'Telefone publicado',
    'Móvel +258 elegível WhatsApp',
    'Operadora',
    'Estado do website',
    'Website URL',
    'Avaliação',
    'Avaliações (Qtd)',
    'Score IA',
    'Justificação IA',
    'Estado no funil',
    'Link WhatsApp',
    'Google Maps URL',
    'Notas',
  ];

  const dataRows: Array<Array<string | number>> = leads.map((lead) => [
    sanitizeSheetText(lead.name),
    sanitizeSheetText(lead.primaryType || lead.niche),
    sanitizeSheetText(lead.city),
    sanitizeSheetText(lead.province),
    sanitizeSheetText(lead.address),
    sanitizeSheetText(lead.whatsappNumber || lead.phoneRaw || ''),
    lead.hasMobileWhatsApp ? 'Sim' : 'Não',
    sanitizeSheetText(lead.carrier),
    websiteLabelMap[lead.websiteStatus],
    lead.websiteUrl || '',
    lead.rating !== null ? Number(lead.rating.toFixed(1)) : '',
    lead.reviewCount,
    lead.opportunityScore !== null ? lead.opportunityScore : '',
    sanitizeSheetText(lead.scoreRationale || ''),
    PIPELINE_STATUS_LABELS[lead.pipelineStatus] || lead.pipelineStatus,
    lead.waDigits ? `https://wa.me/${lead.waDigits}` : '',
    lead.googleMapsUri || '',
    sanitizeSheetText(lead.notes || ''),
  ]);

  const values = [headers, ...dataRows];
  const writeRange = encodeURIComponent(`${quotedTab}!A1`);

  const updateRes = await fetch(
    `${SHEETS_API_BASE}/${encodeURIComponent(
      spreadsheetId
    )}/values/${writeRange}?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        range: `${quotedTab}!A1`,
        majorDimension: 'ROWS',
        values,
      }),
    }
  );

  if (!updateRes.ok) {
    throw await parseSheetsError(
      updateRes,
      'Falha ao gravar os leads na planilha do Google Sheets.'
    );
  }

  return {
    updatedRows: leads.length,
    syncedAt: new Date().toISOString(),
  };
}
