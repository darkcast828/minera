import { getApps, initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  type User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export const SCOPES = [
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/gmail.send',
] as const;

const app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
const auth = getAuth(app);

let isSigningIn = false;
// Strictly in-memory token cache (never stored in localStorage/sessionStorage)
let cachedAccessToken: string | null = null;

function createGoogleProvider(loginHint?: string): GoogleAuthProvider {
  const provider = new GoogleAuthProvider();
  for (const scope of SCOPES) {
    provider.addScope(scope);
  }
  const params: Record<string, string> = {
    prompt: 'select_account consent',
  };
  if (loginHint && loginHint.trim()) {
    params.login_hint = loginHint.trim();
  }
  provider.setCustomParameters(params);
  return provider;
}

export function initGoogleAuth(
  onAuthSuccess: (user: User, token: string) => void,
  onAuthFailure: (user: User | null) => void
): () => void {
  return onAuthStateChanged(auth, (user) => {
    if (user && cachedAccessToken) {
      onAuthSuccess(user, cachedAccessToken);
    } else if (!isSigningIn) {
      cachedAccessToken = null;
      onAuthFailure(user);
    }
  });
}

export async function googleSignIn(
  loginHint?: string
): Promise<{ user: User; accessToken: string }> {
  try {
    isSigningIn = true;
    const provider = createGoogleProvider(loginHint);
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error(
        'Não foi possível obter a autorização de acesso ao Google Workspace.'
      );
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } finally {
    isSigningIn = false;
  }
}

export function getAccessToken(): string | null {
  return cachedAccessToken;
}

export function invalidateAccessToken(): void {
  cachedAccessToken = null;
}

export async function googleLogout(): Promise<void> {
  cachedAccessToken = null;
  await auth.signOut();
}
