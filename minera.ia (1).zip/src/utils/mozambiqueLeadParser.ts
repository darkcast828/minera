import type { CarrierName, WebsiteStatus } from '../types/leads.ts';

const SOCIAL_AND_DIRECTORY_HOSTS = [
  'facebook.com',
  'fb.com',
  'm.facebook.com',
  'instagram.com',
  'wa.me',
  'whatsapp.com',
  'api.whatsapp.com',
  'tiktok.com',
  'linkedin.com',
  'linktr.ee',
  'youtube.com',
  'youtu.be',
  'twitter.com',
  'x.com',
  'business.site',
  'paginasamarelas.co.mz',
  'yellowpages',
];

export interface ParsedMozPhone {
  formattedE164: string | null;
  waDigits: string | null;
  isMobileWhatsApp: boolean;
  carrier: CarrierName;
}

/**
 * Normalizes Mozambique phone numbers (+258) and classifies mobile carriers
 * compatible with WhatsApp (82/83 Tmcel, 84/85 Vodacom, 86/87 Movitel).
 */
export function parseMozambiquePhone(raw: string | null | undefined): ParsedMozPhone {
  if (!raw) {
    return {
      formattedE164: null,
      waDigits: null,
      isMobileWhatsApp: false,
      carrier: 'Desconhecido',
    };
  }

  let digits = raw.replace(/\D/g, '');
  if (digits.startsWith('00258')) {
    digits = digits.slice(5);
  } else if (digits.startsWith('258') && digits.length >= 11) {
    digits = digits.slice(3);
  } else if (digits.length === 10 && digits.startsWith('08')) {
    digits = digits.slice(1);
  }

  // Mozambique standard numbers are 9 digits (or 8 digits for older landlines)
  if (digits.length === 9 && digits.startsWith('8')) {
    const prefix = digits.slice(0, 2);
    let carrier: CarrierName = 'Desconhecido';
    let isMobileWhatsApp = false;

    if (prefix === '82' || prefix === '83') {
      carrier = 'Tmcel';
      isMobileWhatsApp = true;
    } else if (prefix === '84' || prefix === '85') {
      carrier = 'Vodacom';
      isMobileWhatsApp = true;
    } else if (prefix === '86' || prefix === '87') {
      carrier = 'Movitel';
      isMobileWhatsApp = true;
    }

    const formattedE164 = `+258 ${digits.slice(0, 2)} ${digits.slice(2, 5)} ${digits.slice(5, 9)}`;
    const waDigits = `258${digits}`;

    return {
      formattedE164,
      waDigits: isMobileWhatsApp ? waDigits : null,
      isMobileWhatsApp,
      carrier,
    };
  }

  if ((digits.length === 8 || digits.length === 9) && digits.startsWith('2')) {
    return {
      formattedE164: `+258 ${digits}`,
      waDigits: null,
      isMobileWhatsApp: false,
      carrier: 'Fixo',
    };
  }

  return {
    formattedE164: raw.trim(),
    waDigits: null,
    isMobileWhatsApp: false,
    carrier: 'Desconhecido',
  };
}

export function sanitizeExternalHttpUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  const trimmed = url.trim();
  if (!trimmed) return null;
  try {
    const parsed = new URL(trimmed.startsWith('http') ? trimmed : `https://${trimmed}`);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

export function classifyWebsite(rawWebsiteUrl: string | null | undefined): {
  websiteUrl: string | null;
  websiteStatus: WebsiteStatus;
} {
  const safeUrl = sanitizeExternalHttpUrl(rawWebsiteUrl);
  if (!safeUrl) {
    return { websiteUrl: null, websiteStatus: 'none' };
  }

  try {
    const hostname = new URL(safeUrl).hostname.toLowerCase().replace(/^www\./, '');
    const isSocialOnly = SOCIAL_AND_DIRECTORY_HOSTS.some(
      (domain) => hostname === domain || hostname.endsWith(`.${domain}`)
    );

    return {
      websiteUrl: safeUrl,
      websiteStatus: isSocialOnly ? 'social_only' : 'has_website',
    };
  } catch {
    return { websiteUrl: null, websiteStatus: 'none' };
  }
}
