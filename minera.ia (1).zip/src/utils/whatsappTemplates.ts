import type { LeadRecord } from '../types/leads.ts';

interface NicheRule {
  keywords: string[];
  label: string;
  valueProp: string;
}

const NICHE_RULES: NicheRule[] = [
  {
    keywords: ['dent', 'clínica', 'clinica', 'saúde', 'saude', 'médic', 'medic', 'hospital', 'fisio'],
    label: 'Saúde e Clínicas',
    valueProp:
      'apresentar os vossos serviços clínicos, corpo médico e facilitar marcações de consultas diretamente pelo WhatsApp',
  },
  {
    keywords: ['restaurante', 'pastelaria', 'café', 'cafe', 'lanchonete', 'pizzaria', 'bar', 'takeaway'],
    label: 'Restauração e Cafetaria',
    valueProp:
      'disponibilizar o menu digital atualizado, localização exata e receber pedidos ou reservas de mesa num clique via WhatsApp',
  },
  {
    keywords: ['oficina', 'mecânic', 'mecanic', 'auto', 'pneu', 'peças', 'pecas', 'bate-chapa'],
    label: 'Oficinas e Automóvel',
    valueProp:
      'mostrar as especialidades de manutenção da oficina e permitir pedidos rápidos de orçamento com envio de fotos pelo WhatsApp',
  },
  {
    keywords: ['salão', 'salao', 'beleza', 'barbearia', 'estética', 'estetica', 'cabeleireir', 'spa'],
    label: 'Beleza e Estética',
    valueProp:
      'exibir o portfólio de trabalhos, tabela de preços e receber agendamentos de clientes sem depender apenas de redes sociais',
  },
  {
    keywords: ['hotel', 'pousada', 'lodge', 'resort', 'alojamento', 'guesthouse', 'hospedagem'],
    label: 'Hotelaria e Alojamento',
    valueProp:
      'apresentar os quartos com fotografias profissionais e captar reservas diretas sem comissões de intermediários',
  },
  {
    keywords: ['farmácia', 'farmacia', 'óptica', 'optica', 'laboratório', 'laboratorio'],
    label: 'Farmácia e Óptica',
    valueProp:
      'destacar horários de atendimento, especialidades e permitir verificação rápida de disponibilidade de produtos pelo WhatsApp',
  },
  {
    keywords: ['imobiliária', 'imobiliaria', 'imóveis', 'imoveis', 'construção', 'construcao', 'engenharia'],
    label: 'Imobiliário e Construção',
    valueProp:
      'publicar o catálogo de imóveis e projetos com filtros claros para captar compradores e arrendatários qualificados',
  },
  {
    keywords: ['escola', 'colégio', 'colegio', 'formação', 'formacao', 'instituto', 'academia', 'creche'],
    label: 'Educação e Formação',
    valueProp:
      'informar sobre cursos, propinas, calendário de inscrições e encaminhar dúvidas de encarregados e alunos para o vosso WhatsApp',
  },
  {
    keywords: ['ginásio', 'ginasio', 'fitness', 'crossfit', 'pilates'],
    label: 'Fitness e Desporto',
    valueProp:
      'divulgar os planos de mensalidade, horários das aulas e converter visitantes em aulas experimentais',
  },
  {
    keywords: ['contabilidade', 'advocacia', 'jurídic', 'juridic', 'consultoria', 'auditoria'],
    label: 'Serviços Corporativos',
    valueProp:
      'transmitir maior credibilidade institucional a clientes empresariais e centralizar pedidos de proposta comercial',
  },
  {
    keywords: ['loja', 'ferragens', 'materiais', 'comércio', 'comercio', 'supermercado', 'papelaria'],
    label: 'Comércio e Retalho',
    valueProp:
      'organizar as linhas de produtos em catálogo online e acelerar cotações rápidas de clientes locais',
  },
];

export function buildOutreachTemplateByNiche(lead: LeadRecord): {
  nicheLabel: string;
  message: string;
} {
  const haystack = `${lead.niche} ${lead.primaryType ?? ''}`.toLowerCase();
  const matched = NICHE_RULES.find((rule) =>
    rule.keywords.some((kw) => haystack.includes(kw))
  );

  const nicheLabel = matched?.label ?? (lead.primaryType || lead.niche || 'Negócio Local');
  const valueProp =
    matched?.valueProp ??
    'apresentar os vossos serviços de forma profissional e transformar pesquisas locais no Google em contactos diretos no WhatsApp';

  const presenceObservation =
    lead.websiteStatus === 'social_only'
      ? 'Notei que já têm presença nas redes sociais, mas ainda não contam com um website próprio ligado à ficha.'
      : 'Reparei que a ficha está bem posicionada no mapa, mas ainda não tem um website próprio associado.';

  const reputationLine =
    lead.reviewCount > 0 && lead.rating !== null
      ? ` Vi também as vossas ${lead.reviewCount} avaliações (${lead.rating.toFixed(1)}★), o que mostra ótima procura dos clientes.`
      : '';

  const message = [
    `Olá, equipa da ${lead.name}! Tudo bem?`,
    '',
    `Encontrei o vosso contacto no Google Maps aqui em ${lead.city}.${reputationLine} ${presenceObservation}`,
    '',
    `Trabalho no desenvolvimento de websites para empresas em Moçambique e posso preparar uma estrutura pensada especificamente para ${valueProp}.`,
    '',
    `Posso enviar uma breve demonstração de como ficaria para a ${lead.name} sem compromisso?`,
  ].join('\n');

  return { nicheLabel, message };
}

export function buildWebWhatsAppUrl(waDigits: string, message: string): string {
  const cleanDigits = waDigits.replace(/\D/g, '');
  return `https://web.whatsapp.com/send?phone=${cleanDigits}&text=${encodeURIComponent(message)}`;
}
